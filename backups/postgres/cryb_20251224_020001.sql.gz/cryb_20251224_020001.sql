--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: cryb_user
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO cryb_user;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: cryb_user
--

COMMENT ON SCHEMA public IS '';


--
-- Name: ActivityType; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."ActivityType" AS ENUM (
    'PLAYING',
    'STREAMING',
    'LISTENING',
    'WATCHING',
    'CUSTOM',
    'COMPETING'
);


ALTER TYPE public."ActivityType" OWNER TO cryb_user;

--
-- Name: BidStatus; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."BidStatus" AS ENUM (
    'ACTIVE',
    'OUTBID',
    'WINNING',
    'WON',
    'CANCELLED',
    'EXPIRED'
);


ALTER TYPE public."BidStatus" OWNER TO cryb_user;

--
-- Name: ChannelType; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."ChannelType" AS ENUM (
    'GUILD_TEXT',
    'DM',
    'GUILD_VOICE',
    'GROUP_DM',
    'GUILD_CATEGORY',
    'GUILD_ANNOUNCEMENT',
    'ANNOUNCEMENT_THREAD',
    'PUBLIC_THREAD',
    'PRIVATE_THREAD',
    'GUILD_STAGE_VOICE',
    'GUILD_DIRECTORY',
    'GUILD_FORUM',
    'GUILD_MEDIA',
    'TEXT',
    'VOICE',
    'VIDEO',
    'FORUM',
    'STAGE',
    'CATEGORY',
    'ANNOUNCEMENT'
);


ALTER TYPE public."ChannelType" OWNER TO cryb_user;

--
-- Name: CryptoTransactionType; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."CryptoTransactionType" AS ENUM (
    'DEPOSIT',
    'WITHDRAWAL',
    'TIP',
    'PURCHASE',
    'SALE',
    'STAKE',
    'UNSTAKE',
    'REWARD'
);


ALTER TYPE public."CryptoTransactionType" OWNER TO cryb_user;

--
-- Name: DeliveryStatus; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."DeliveryStatus" AS ENUM (
    'PENDING',
    'SENT',
    'DELIVERED',
    'FAILED',
    'CLICKED',
    'EXPIRED'
);


ALTER TYPE public."DeliveryStatus" OWNER TO cryb_user;

--
-- Name: DeviceType; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."DeviceType" AS ENUM (
    'IOS',
    'ANDROID',
    'WEB',
    'DESKTOP'
);


ALTER TYPE public."DeviceType" OWNER TO cryb_user;

--
-- Name: FriendshipStatus; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."FriendshipStatus" AS ENUM (
    'PENDING',
    'ACCEPTED',
    'BLOCKED'
);


ALTER TYPE public."FriendshipStatus" OWNER TO cryb_user;

--
-- Name: GDPRRequestStatus; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."GDPRRequestStatus" AS ENUM (
    'PENDING',
    'PROCESSING',
    'COMPLETED',
    'FAILED',
    'CANCELLED'
);


ALTER TYPE public."GDPRRequestStatus" OWNER TO cryb_user;

--
-- Name: GDPRRequestType; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."GDPRRequestType" AS ENUM (
    'DATA_EXPORT',
    'DATA_DELETION',
    'DATA_RECTIFICATION',
    'DATA_PORTABILITY'
);


ALTER TYPE public."GDPRRequestType" OWNER TO cryb_user;

--
-- Name: ListingStatus; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."ListingStatus" AS ENUM (
    'DRAFT',
    'ACTIVE',
    'SOLD',
    'CANCELLED',
    'EXPIRED'
);


ALTER TYPE public."ListingStatus" OWNER TO cryb_user;

--
-- Name: ListingType; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."ListingType" AS ENUM (
    'FIXED_PRICE',
    'AUCTION',
    'DUTCH_AUCTION',
    'BUNDLE'
);


ALTER TYPE public."ListingType" OWNER TO cryb_user;

--
-- Name: MediaType; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."MediaType" AS ENUM (
    'IMAGE',
    'VIDEO',
    'AUDIO',
    'GIF'
);


ALTER TYPE public."MediaType" OWNER TO cryb_user;

--
-- Name: NotificationPriority; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."NotificationPriority" AS ENUM (
    'LOW',
    'NORMAL',
    'HIGH',
    'CRITICAL'
);


ALTER TYPE public."NotificationPriority" OWNER TO cryb_user;

--
-- Name: NotificationType; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."NotificationType" AS ENUM (
    'MENTION',
    'REPLY',
    'FOLLOW',
    'LIKE',
    'COMMENT',
    'AWARD',
    'SYSTEM',
    'DM',
    'MESSAGE',
    'VOICE_CALL',
    'VIDEO_CALL',
    'SERVER_INVITE',
    'COMMUNITY_INVITE',
    'FRIEND_REQUEST',
    'POST_COMMENT',
    'POST_LIKE',
    'LIVE_STREAM',
    'NFT_TRANSFER',
    'CRYPTO_TIP',
    'COMMUNITY_POST',
    'MAINTENANCE',
    'SECURITY_ALERT',
    'POST_REPOST',
    'POST_QUOTE',
    'COMMENT_LIKE',
    'COMMENT_REPLY',
    'POLL_ENDED',
    'MESSAGE_REQUEST',
    'CALL_MISSED',
    'NFT_SOLD',
    'NFT_OFFER',
    'NFT_BID'
);


ALTER TYPE public."NotificationType" OWNER TO cryb_user;

--
-- Name: PaymentProvider; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."PaymentProvider" AS ENUM (
    'TRANSAK',
    'MOONPAY',
    'RAMP',
    'MANUAL',
    'ONCHAIN'
);


ALTER TYPE public."PaymentProvider" OWNER TO cryb_user;

--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'PENDING',
    'PROCESSING',
    'COMPLETED',
    'FAILED',
    'CANCELLED',
    'REFUNDED'
);


ALTER TYPE public."PaymentStatus" OWNER TO cryb_user;

--
-- Name: PostType; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."PostType" AS ENUM (
    'TEXT',
    'IMAGE',
    'VIDEO',
    'AUDIO',
    'POLL',
    'LINK',
    'QUOTE',
    'THREAD'
);


ALTER TYPE public."PostType" OWNER TO cryb_user;

--
-- Name: PremiumType; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."PremiumType" AS ENUM (
    'NONE',
    'NITRO_CLASSIC',
    'NITRO',
    'NITRO_BASIC'
);


ALTER TYPE public."PremiumType" OWNER TO cryb_user;

--
-- Name: PresenceStatus; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."PresenceStatus" AS ENUM (
    'ONLINE',
    'IDLE',
    'DND',
    'INVISIBLE',
    'OFFLINE'
);


ALTER TYPE public."PresenceStatus" OWNER TO cryb_user;

--
-- Name: ProposalCategory; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."ProposalCategory" AS ENUM (
    'GOVERNANCE',
    'TREASURY',
    'PROTOCOL',
    'COMMUNITY',
    'TECHNICAL',
    'OTHER'
);


ALTER TYPE public."ProposalCategory" OWNER TO cryb_user;

--
-- Name: ProposalStatus; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."ProposalStatus" AS ENUM (
    'DRAFT',
    'ACTIVE',
    'PASSED',
    'FAILED',
    'CANCELLED',
    'EXECUTED'
);


ALTER TYPE public."ProposalStatus" OWNER TO cryb_user;

--
-- Name: PushProvider; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."PushProvider" AS ENUM (
    'FCM',
    'APNS',
    'EXPO',
    'WEB_PUSH',
    'MOCK'
);


ALTER TYPE public."PushProvider" OWNER TO cryb_user;

--
-- Name: QueueStatus; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."QueueStatus" AS ENUM (
    'PENDING',
    'PROCESSING',
    'COMPLETED',
    'FAILED',
    'CANCELLED',
    'SCHEDULED'
);


ALTER TYPE public."QueueStatus" OWNER TO cryb_user;

--
-- Name: ReportStatus; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."ReportStatus" AS ENUM (
    'PENDING',
    'REVIEWING',
    'RESOLVED',
    'DISMISSED'
);


ALTER TYPE public."ReportStatus" OWNER TO cryb_user;

--
-- Name: RewardStatus; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."RewardStatus" AS ENUM (
    'PENDING',
    'CLAIMABLE',
    'CLAIMED',
    'EXPIRED'
);


ALTER TYPE public."RewardStatus" OWNER TO cryb_user;

--
-- Name: SaleStatus; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."SaleStatus" AS ENUM (
    'PENDING',
    'PROCESSING',
    'COMPLETED',
    'FAILED',
    'CANCELLED',
    'REFUNDED'
);


ALTER TYPE public."SaleStatus" OWNER TO cryb_user;

--
-- Name: StakeStatus; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."StakeStatus" AS ENUM (
    'ACTIVE',
    'UNSTAKING',
    'WITHDRAWN',
    'SLASHED'
);


ALTER TYPE public."StakeStatus" OWNER TO cryb_user;

--
-- Name: TipStatus; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."TipStatus" AS ENUM (
    'PENDING',
    'PROCESSING',
    'COMPLETED',
    'FAILED',
    'CANCELLED'
);


ALTER TYPE public."TipStatus" OWNER TO cryb_user;

--
-- Name: TokenGatingType; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."TokenGatingType" AS ENUM (
    'TOKEN_BALANCE',
    'NFT_OWNERSHIP',
    'COMBINED',
    'CUSTOM'
);


ALTER TYPE public."TokenGatingType" OWNER TO cryb_user;

--
-- Name: VoiceStateFlag; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."VoiceStateFlag" AS ENUM (
    'DEAF',
    'MUTE',
    'SELF_DEAF',
    'SELF_MUTE',
    'SELF_STREAM',
    'SELF_VIDEO',
    'SUPPRESS'
);


ALTER TYPE public."VoiceStateFlag" OWNER TO cryb_user;

--
-- Name: VoteType; Type: TYPE; Schema: public; Owner: cryb_user
--

CREATE TYPE public."VoteType" AS ENUM (
    'FOR',
    'AGAINST',
    'ABSTAIN'
);


ALTER TYPE public."VoteType" OWNER TO cryb_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "serverId" text NOT NULL,
    "userId" text,
    "targetId" text,
    "actionType" integer NOT NULL,
    options jsonb,
    reason text,
    changes jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AuditLog" OWNER TO cryb_user;

--
-- Name: Award; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Award" (
    id text NOT NULL,
    "postId" text,
    "commentId" text,
    type text NOT NULL,
    cost integer NOT NULL,
    message text,
    anonymous boolean DEFAULT false NOT NULL,
    "giverId" text NOT NULL,
    "receiverId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Award" OWNER TO cryb_user;

--
-- Name: Ban; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Ban" (
    id text NOT NULL,
    "serverId" text NOT NULL,
    "userId" text NOT NULL,
    reason text,
    "bannedBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Ban" OWNER TO cryb_user;

--
-- Name: Block; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Block" (
    id text NOT NULL,
    "blockerId" text NOT NULL,
    "blockedId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Block" OWNER TO cryb_user;

--
-- Name: Bookmark; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Bookmark" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "postId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Bookmark" OWNER TO cryb_user;

--
-- Name: Channel; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Channel" (
    id text NOT NULL,
    "serverId" text,
    name text NOT NULL,
    topic text,
    description text,
    type public."ChannelType" DEFAULT 'TEXT'::public."ChannelType" NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    "isPrivate" boolean DEFAULT false NOT NULL,
    "parentId" text,
    "slowMode" integer DEFAULT 0 NOT NULL,
    nsfw boolean DEFAULT false NOT NULL,
    bitrate integer,
    "userLimit" integer,
    "rtcRegion" text,
    "videoQualityMode" integer,
    "defaultAutoArchiveDuration" integer,
    flags integer DEFAULT 0 NOT NULL,
    "lastMessageId" text,
    "lastPinTimestamp" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Channel" OWNER TO cryb_user;

--
-- Name: ChannelPermission; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."ChannelPermission" (
    id text NOT NULL,
    "channelId" text NOT NULL,
    "roleId" text,
    "userId" text,
    allow bigint DEFAULT 0 NOT NULL,
    deny bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public."ChannelPermission" OWNER TO cryb_user;

--
-- Name: ChunkedUploadSession; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."ChunkedUploadSession" (
    id text NOT NULL,
    "userId" text NOT NULL,
    filename text NOT NULL,
    "mimeType" text NOT NULL,
    "totalSize" integer NOT NULL,
    "chunkSize" integer NOT NULL,
    "totalChunks" integer NOT NULL,
    "uploadedChunks" integer DEFAULT 0 NOT NULL,
    "tempPath" text,
    metadata jsonb,
    status text DEFAULT 'active'::text NOT NULL,
    completed boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "lastActivity" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ChunkedUploadSession" OWNER TO cryb_user;

--
-- Name: Comment; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Comment" (
    id text NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "editedAt" timestamp(3) without time zone,
    "parentId" text,
    "postId" text NOT NULL,
    score integer DEFAULT 0 NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "userId" text NOT NULL,
    depth integer DEFAULT 0 NOT NULL,
    "likeCount" integer DEFAULT 0 NOT NULL,
    "replyCount" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public."Comment" OWNER TO cryb_user;

--
-- Name: Community; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Community" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    banner text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "displayName" text NOT NULL,
    icon text,
    "isNsfw" boolean DEFAULT false NOT NULL,
    "isPublic" boolean DEFAULT true NOT NULL,
    "memberCount" integer DEFAULT 0 NOT NULL,
    rules jsonb,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Community" OWNER TO cryb_user;

--
-- Name: CommunityBadge; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."CommunityBadge" (
    id text NOT NULL,
    "serverId" text,
    "communityId" text,
    "collectionId" text NOT NULL,
    name text NOT NULL,
    description text,
    image text,
    requirements jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CommunityBadge" OWNER TO cryb_user;

--
-- Name: CommunityMember; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."CommunityMember" (
    id text NOT NULL,
    "communityId" text NOT NULL,
    "userId" text NOT NULL,
    karma integer DEFAULT 0 NOT NULL,
    "joinedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."CommunityMember" OWNER TO cryb_user;

--
-- Name: CryptoPayment; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."CryptoPayment" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "transactionType" public."CryptoTransactionType" NOT NULL,
    provider public."PaymentProvider" NOT NULL,
    "externalId" text,
    status public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    amount text NOT NULL,
    currency text NOT NULL,
    "usdAmount" text,
    "recipientAddress" text,
    "txHash" text,
    chain text DEFAULT 'ethereum'::text NOT NULL,
    metadata jsonb,
    "webhookData" jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "completedAt" timestamp(3) without time zone
);


ALTER TABLE public."CryptoPayment" OWNER TO cryb_user;

--
-- Name: CryptoTip; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."CryptoTip" (
    id text NOT NULL,
    "senderId" text NOT NULL,
    "recipientId" text NOT NULL,
    "paymentId" text,
    amount text NOT NULL,
    currency text NOT NULL,
    "usdAmount" text,
    message text,
    "isAnonymous" boolean DEFAULT false NOT NULL,
    status public."TipStatus" DEFAULT 'PENDING'::public."TipStatus" NOT NULL,
    "txHash" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "processedAt" timestamp(3) without time zone
);


ALTER TABLE public."CryptoTip" OWNER TO cryb_user;

--
-- Name: DirectMessageParticipant; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."DirectMessageParticipant" (
    id text NOT NULL,
    "channelId" text NOT NULL,
    "userId" text NOT NULL,
    "joinedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastReadMessageId" text
);


ALTER TABLE public."DirectMessageParticipant" OWNER TO cryb_user;

--
-- Name: FileAccessLog; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."FileAccessLog" (
    id text NOT NULL,
    "fileId" text NOT NULL,
    "userId" text,
    "accessType" text NOT NULL,
    "ipAddress" text,
    "userAgent" text,
    referrer text,
    country text,
    region text,
    city text,
    "responseTime" integer,
    "bytesServed" integer,
    "accessedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."FileAccessLog" OWNER TO cryb_user;

--
-- Name: FileAnalytics; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."FileAnalytics" (
    id text NOT NULL,
    "fileId" text NOT NULL,
    "viewCount" integer DEFAULT 0 NOT NULL,
    "uniqueViews" integer DEFAULT 0 NOT NULL,
    "downloadCount" integer DEFAULT 0 NOT NULL,
    "streamCount" integer DEFAULT 0 NOT NULL,
    "avgViewDuration" double precision,
    "bounceRate" double precision,
    "shareCount" integer DEFAULT 0 NOT NULL,
    "avgLoadTime" double precision,
    "bandwidthUsed" bigint DEFAULT 0 NOT NULL,
    "topCountries" jsonb,
    "topCities" jsonb,
    "hourlyStats" jsonb,
    "dailyStats" jsonb,
    "monthlyStats" jsonb,
    "deviceTypes" jsonb,
    browsers jsonb,
    "operatingSystems" jsonb,
    "lastCalculated" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."FileAnalytics" OWNER TO cryb_user;

--
-- Name: FilePermission; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."FilePermission" (
    id text NOT NULL,
    "fileId" text NOT NULL,
    "isPublic" boolean DEFAULT false NOT NULL,
    "allowHotlinking" boolean DEFAULT false NOT NULL,
    "requireAuth" boolean DEFAULT true NOT NULL,
    "allowedUsers" text[] DEFAULT ARRAY[]::text[],
    "allowedRoles" text[] DEFAULT ARRAY[]::text[],
    "deniedUsers" text[] DEFAULT ARRAY[]::text[],
    "maxDownloads" integer,
    "downloadCount" integer DEFAULT 0 NOT NULL,
    "maxDownloadsPerUser" integer,
    "availableFrom" timestamp(3) without time zone,
    "availableUntil" timestamp(3) without time zone,
    "allowedCountries" text[] DEFAULT ARRAY[]::text[],
    "deniedCountries" text[] DEFAULT ARRAY[]::text[],
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."FilePermission" OWNER TO cryb_user;

--
-- Name: FileVariant; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."FileVariant" (
    id text NOT NULL,
    "fileId" text NOT NULL,
    type text NOT NULL,
    format text NOT NULL,
    filename text NOT NULL,
    url text NOT NULL,
    bucket text NOT NULL,
    size integer NOT NULL,
    width integer,
    height integer,
    quality integer,
    resolution text,
    bitrate text,
    duration double precision,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."FileVariant" OWNER TO cryb_user;

--
-- Name: Flair; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Flair" (
    id text NOT NULL,
    "communityId" text NOT NULL,
    text text NOT NULL,
    "backgroundColor" text,
    "textColor" text
);


ALTER TABLE public."Flair" OWNER TO cryb_user;

--
-- Name: Follow; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Follow" (
    id text NOT NULL,
    "followerId" text NOT NULL,
    "followingId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Follow" OWNER TO cryb_user;

--
-- Name: Friendship; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Friendship" (
    id text NOT NULL,
    "initiatorId" text NOT NULL,
    "receiverId" text NOT NULL,
    status public."FriendshipStatus" DEFAULT 'PENDING'::public."FriendshipStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Friendship" OWNER TO cryb_user;

--
-- Name: GovernanceProposal; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."GovernanceProposal" (
    id text NOT NULL,
    "proposerId" text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    category public."ProposalCategory" NOT NULL,
    status public."ProposalStatus" DEFAULT 'DRAFT'::public."ProposalStatus" NOT NULL,
    "votingStartTime" timestamp(3) without time zone,
    "votingEndTime" timestamp(3) without time zone,
    quorum text,
    "forVotes" text DEFAULT '0'::text NOT NULL,
    "againstVotes" text DEFAULT '0'::text NOT NULL,
    "abstainVotes" text DEFAULT '0'::text NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."GovernanceProposal" OWNER TO cryb_user;

--
-- Name: GovernanceVote; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."GovernanceVote" (
    id text NOT NULL,
    "proposalId" text NOT NULL,
    "voterId" text NOT NULL,
    "voteType" public."VoteType" NOT NULL,
    "votingPower" text NOT NULL,
    reason text,
    "txHash" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."GovernanceVote" OWNER TO cryb_user;

--
-- Name: HiddenWord; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."HiddenWord" (
    id text NOT NULL,
    "userId" text NOT NULL,
    word text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."HiddenWord" OWNER TO cryb_user;

--
-- Name: Invite; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Invite" (
    id text NOT NULL,
    code text NOT NULL,
    "serverId" text NOT NULL,
    "inviterId" text NOT NULL,
    uses integer DEFAULT 0 NOT NULL,
    "maxUses" integer,
    "maxAge" integer,
    temporary boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone
);


ALTER TABLE public."Invite" OWNER TO cryb_user;

--
-- Name: Like; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Like" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "postId" text,
    "commentId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Like" OWNER TO cryb_user;

--
-- Name: MarketplaceBid; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."MarketplaceBid" (
    id text NOT NULL,
    "listingId" text NOT NULL,
    "bidderId" text NOT NULL,
    amount text NOT NULL,
    currency text DEFAULT 'ETH'::text NOT NULL,
    "usdAmount" text,
    status public."BidStatus" DEFAULT 'ACTIVE'::public."BidStatus" NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."MarketplaceBid" OWNER TO cryb_user;

--
-- Name: MarketplaceListing; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."MarketplaceListing" (
    id text NOT NULL,
    "sellerId" text NOT NULL,
    "nftId" text NOT NULL,
    "collectionId" text NOT NULL,
    price text NOT NULL,
    currency text DEFAULT 'ETH'::text NOT NULL,
    "usdPrice" text,
    "listingType" public."ListingType" DEFAULT 'FIXED_PRICE'::public."ListingType" NOT NULL,
    status public."ListingStatus" DEFAULT 'ACTIVE'::public."ListingStatus" NOT NULL,
    "startTime" timestamp(3) without time zone,
    "endTime" timestamp(3) without time zone,
    "minBidIncrement" text,
    "reservePrice" text,
    metadata jsonb,
    views integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."MarketplaceListing" OWNER TO cryb_user;

--
-- Name: MarketplaceSale; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."MarketplaceSale" (
    id text NOT NULL,
    "listingId" text NOT NULL,
    "buyerId" text NOT NULL,
    "sellerId" text NOT NULL,
    "nftId" text NOT NULL,
    "salePrice" text NOT NULL,
    currency text DEFAULT 'ETH'::text NOT NULL,
    "usdPrice" text,
    "platformFee" text,
    "royaltyFee" text,
    "txHash" text,
    status public."SaleStatus" DEFAULT 'PENDING'::public."SaleStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone
);


ALTER TABLE public."MarketplaceSale" OWNER TO cryb_user;

--
-- Name: MemberRole; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."MemberRole" (
    id text NOT NULL,
    "serverId" text NOT NULL,
    "userId" text NOT NULL,
    "roleId" text NOT NULL
);


ALTER TABLE public."MemberRole" OWNER TO cryb_user;

--
-- Name: Message; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Message" (
    id text NOT NULL,
    "channelId" text NOT NULL,
    "userId" text NOT NULL,
    content text NOT NULL,
    nonce text,
    tts boolean DEFAULT false NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "editedTimestamp" timestamp(3) without time zone,
    flags integer DEFAULT 0 NOT NULL,
    "isPinned" boolean DEFAULT false NOT NULL,
    "mentionEveryone" boolean DEFAULT false NOT NULL,
    mentions jsonb,
    "mentionRoles" jsonb,
    "mentionChannels" jsonb,
    "replyToId" text,
    "threadId" text,
    "webhookId" text,
    type integer DEFAULT 0 NOT NULL,
    activity jsonb,
    application jsonb,
    "applicationId" text,
    "messageReference" jsonb,
    stickers jsonb,
    "referencedMessage" jsonb,
    interaction jsonb,
    components jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Message" OWNER TO cryb_user;

--
-- Name: MessageAnalytics; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."MessageAnalytics" (
    id text NOT NULL,
    "serverId" text,
    "channelId" text NOT NULL,
    "userId" text NOT NULL,
    "messageCount" integer DEFAULT 1 NOT NULL,
    "characterCount" integer DEFAULT 0 NOT NULL,
    "wordCount" integer DEFAULT 0 NOT NULL,
    "attachmentCount" integer DEFAULT 0 NOT NULL,
    "mentionCount" integer DEFAULT 0 NOT NULL,
    "reactionCount" integer DEFAULT 0 NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MessageAnalytics" OWNER TO cryb_user;

--
-- Name: MessageAttachment; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."MessageAttachment" (
    id text NOT NULL,
    "messageId" text NOT NULL,
    filename text NOT NULL,
    description text,
    "contentType" text NOT NULL,
    size integer NOT NULL,
    url text NOT NULL,
    "proxyUrl" text NOT NULL,
    height integer,
    width integer,
    ephemeral boolean DEFAULT false NOT NULL,
    duration double precision,
    waveform text,
    flags integer DEFAULT 0 NOT NULL
);


ALTER TABLE public."MessageAttachment" OWNER TO cryb_user;

--
-- Name: MessageEmbed; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."MessageEmbed" (
    id text NOT NULL,
    "messageId" text NOT NULL,
    title text,
    type text DEFAULT 'rich'::text NOT NULL,
    description text,
    url text,
    "timestamp" timestamp(3) without time zone,
    color integer,
    footer jsonb,
    image jsonb,
    thumbnail jsonb,
    video jsonb,
    provider jsonb,
    author jsonb,
    fields jsonb
);


ALTER TABLE public."MessageEmbed" OWNER TO cryb_user;

--
-- Name: MessageReference; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."MessageReference" (
    id text NOT NULL,
    "messageId" text NOT NULL,
    "channelId" text,
    "serverId" text,
    "referencedMessageId" text,
    type integer DEFAULT 0 NOT NULL,
    "failIfNotExists" boolean DEFAULT true NOT NULL
);


ALTER TABLE public."MessageReference" OWNER TO cryb_user;

--
-- Name: Moderator; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Moderator" (
    id text NOT NULL,
    "communityId" text NOT NULL,
    "userId" text NOT NULL,
    permissions jsonb NOT NULL,
    "addedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Moderator" OWNER TO cryb_user;

--
-- Name: Mute; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Mute" (
    id text NOT NULL,
    "muterId" text NOT NULL,
    "mutedId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Mute" OWNER TO cryb_user;

--
-- Name: NFT; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."NFT" (
    id text NOT NULL,
    "collectionId" text NOT NULL,
    "tokenId" text NOT NULL,
    name text NOT NULL,
    description text,
    image text,
    "animationUrl" text,
    attributes jsonb,
    metadata jsonb,
    "ownerAddress" text,
    rarity double precision,
    "lastSalePrice" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."NFT" OWNER TO cryb_user;

--
-- Name: NFTCollection; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."NFTCollection" (
    id text NOT NULL,
    "contractAddress" text NOT NULL,
    name text NOT NULL,
    symbol text NOT NULL,
    description text,
    image text,
    "bannerImage" text,
    chain text DEFAULT 'ethereum'::text NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    "floorPrice" text,
    "totalSupply" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."NFTCollection" OWNER TO cryb_user;

--
-- Name: NFTRequirement; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."NFTRequirement" (
    id text NOT NULL,
    "ruleId" text NOT NULL,
    "collectionId" text NOT NULL,
    "minTokens" integer DEFAULT 1 NOT NULL,
    "specificTokenIds" jsonb
);


ALTER TABLE public."NFTRequirement" OWNER TO cryb_user;

--
-- Name: Notification; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Notification" (
    id text NOT NULL,
    "userId" text NOT NULL,
    type public."NotificationType" NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    data jsonb,
    "isRead" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Notification" OWNER TO cryb_user;

--
-- Name: NotificationPreferences; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."NotificationPreferences" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "pushEnabled" boolean DEFAULT true NOT NULL,
    "emailEnabled" boolean DEFAULT true NOT NULL,
    "smsEnabled" boolean DEFAULT false NOT NULL,
    "newMessageEnabled" boolean DEFAULT true NOT NULL,
    "mentionEnabled" boolean DEFAULT true NOT NULL,
    "replyEnabled" boolean DEFAULT true NOT NULL,
    "followEnabled" boolean DEFAULT true NOT NULL,
    "likeEnabled" boolean DEFAULT true NOT NULL,
    "commentEnabled" boolean DEFAULT true NOT NULL,
    "awardEnabled" boolean DEFAULT true NOT NULL,
    "systemEnabled" boolean DEFAULT true NOT NULL,
    "dmEnabled" boolean DEFAULT true NOT NULL,
    "voiceCallEnabled" boolean DEFAULT true NOT NULL,
    "serverInviteEnabled" boolean DEFAULT true NOT NULL,
    "communityInviteEnabled" boolean DEFAULT true NOT NULL,
    "quietHoursEnabled" boolean DEFAULT false NOT NULL,
    "quietHoursStart" text,
    "quietHoursEnd" text,
    timezone text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."NotificationPreferences" OWNER TO cryb_user;

--
-- Name: NotificationQueue; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."NotificationQueue" (
    id text NOT NULL,
    "userId" text NOT NULL,
    type public."NotificationType" NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    data jsonb,
    priority public."NotificationPriority" DEFAULT 'NORMAL'::public."NotificationPriority" NOT NULL,
    "scheduledAt" timestamp(3) without time zone,
    status public."QueueStatus" DEFAULT 'PENDING'::public."QueueStatus" NOT NULL,
    "processedAt" timestamp(3) without time zone,
    error text,
    "retryCount" integer DEFAULT 0 NOT NULL,
    "maxRetries" integer DEFAULT 3 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."NotificationQueue" OWNER TO cryb_user;

--
-- Name: NotificationTemplate; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."NotificationTemplate" (
    id text NOT NULL,
    type public."NotificationType" NOT NULL,
    name text NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    data jsonb,
    priority public."NotificationPriority" DEFAULT 'NORMAL'::public."NotificationPriority" NOT NULL,
    sound text,
    badge boolean DEFAULT true NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."NotificationTemplate" OWNER TO cryb_user;

--
-- Name: Poll; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Poll" (
    id text NOT NULL,
    "postId" text NOT NULL,
    question text,
    duration integer NOT NULL,
    "endsAt" timestamp(3) without time zone NOT NULL,
    "totalVotes" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Poll" OWNER TO cryb_user;

--
-- Name: PollOption; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."PollOption" (
    id text NOT NULL,
    "pollId" text NOT NULL,
    option text NOT NULL,
    votes integer DEFAULT 0 NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PollOption" OWNER TO cryb_user;

--
-- Name: PollVote; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."PollVote" (
    id text NOT NULL,
    "pollId" text NOT NULL,
    "optionId" text NOT NULL,
    "userId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PollVote" OWNER TO cryb_user;

--
-- Name: Post; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Post" (
    id text NOT NULL,
    title text,
    content text NOT NULL,
    "commentCount" integer DEFAULT 0 NOT NULL,
    "communityId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "editedAt" timestamp(3) without time zone,
    flair text,
    "isLocked" boolean DEFAULT false NOT NULL,
    "isPinned" boolean DEFAULT false NOT NULL,
    "isRemoved" boolean DEFAULT false NOT NULL,
    nsfw boolean DEFAULT false NOT NULL,
    score integer DEFAULT 0 NOT NULL,
    thumbnail text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    url text,
    "userId" text NOT NULL,
    "viewCount" integer DEFAULT 0 NOT NULL,
    "bookmarkCount" integer DEFAULT 0 NOT NULL,
    "isThread" boolean DEFAULT false NOT NULL,
    "likeCount" integer DEFAULT 0 NOT NULL,
    metadata jsonb,
    "quoteCount" integer DEFAULT 0 NOT NULL,
    "quotedPostId" text,
    "replyCount" integer DEFAULT 0 NOT NULL,
    "repostCount" integer DEFAULT 0 NOT NULL,
    "repostOfId" text,
    "threadRootId" text,
    type public."PostType" DEFAULT 'TEXT'::public."PostType" NOT NULL
);


ALTER TABLE public."Post" OWNER TO cryb_user;

--
-- Name: PostMedia; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."PostMedia" (
    id text NOT NULL,
    "postId" text NOT NULL,
    type public."MediaType" NOT NULL,
    url text NOT NULL,
    thumbnail text,
    alt text,
    width integer,
    height integer,
    duration integer,
    "fileSize" integer,
    "mimeType" text,
    "position" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PostMedia" OWNER TO cryb_user;

--
-- Name: PushDevice; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."PushDevice" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "deviceToken" text NOT NULL,
    "deviceType" public."DeviceType" NOT NULL,
    "deviceModel" text,
    "osVersion" text,
    "appVersion" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastActiveAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PushDevice" OWNER TO cryb_user;

--
-- Name: PushNotificationDelivery; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."PushNotificationDelivery" (
    id text NOT NULL,
    "notificationId" text,
    "templateId" text,
    "deviceId" text NOT NULL,
    "userId" text NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    data jsonb,
    status public."DeliveryStatus" DEFAULT 'PENDING'::public."DeliveryStatus" NOT NULL,
    provider public."PushProvider" NOT NULL,
    "providerResponse" jsonb,
    error text,
    "sentAt" timestamp(3) without time zone,
    "deliveredAt" timestamp(3) without time zone,
    "clickedAt" timestamp(3) without time zone,
    "retryCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PushNotificationDelivery" OWNER TO cryb_user;

--
-- Name: Reaction; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Reaction" (
    id text NOT NULL,
    "messageId" text NOT NULL,
    "userId" text NOT NULL,
    emoji text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Reaction" OWNER TO cryb_user;

--
-- Name: Report; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Report" (
    id text NOT NULL,
    "reporterId" text NOT NULL,
    "postId" text,
    "commentId" text,
    reason text NOT NULL,
    details text,
    status public."ReportStatus" DEFAULT 'PENDING'::public."ReportStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "reviewedAt" timestamp(3) without time zone,
    "reviewedBy" text
);


ALTER TABLE public."Report" OWNER TO cryb_user;

--
-- Name: Repost; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Repost" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "postId" text NOT NULL,
    comment text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Repost" OWNER TO cryb_user;

--
-- Name: Role; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Role" (
    id text NOT NULL,
    "serverId" text NOT NULL,
    name text NOT NULL,
    color text,
    "position" integer DEFAULT 0 NOT NULL,
    permissions bigint DEFAULT 0 NOT NULL,
    mentionable boolean DEFAULT false NOT NULL,
    hoisted boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Role" OWNER TO cryb_user;

--
-- Name: SavedPost; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."SavedPost" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "postId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."SavedPost" OWNER TO cryb_user;

--
-- Name: SecurityLog; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."SecurityLog" (
    id text NOT NULL,
    type text NOT NULL,
    "userId" text,
    "ipAddress" text NOT NULL,
    "userAgent" text NOT NULL,
    details jsonb,
    "riskScore" integer NOT NULL,
    location text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."SecurityLog" OWNER TO cryb_user;

--
-- Name: Server; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Server" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    icon text,
    banner text,
    splash text,
    "discoverySplash" text,
    "ownerId" text NOT NULL,
    "isPublic" boolean DEFAULT true NOT NULL,
    "tokenGated" boolean DEFAULT false NOT NULL,
    "requiredTokens" jsonb,
    "maxMembers" integer DEFAULT 100000 NOT NULL,
    "maxPresences" integer,
    "maxVideoChannelUsers" integer,
    "approximateMemberCount" integer,
    "approximatePresenceCount" integer,
    permissions text,
    features jsonb DEFAULT '[]'::jsonb NOT NULL,
    "verificationLevel" integer DEFAULT 0 NOT NULL,
    "defaultMessageNotifications" integer DEFAULT 0 NOT NULL,
    "explicitContentFilter" integer DEFAULT 0 NOT NULL,
    "mfaLevel" integer DEFAULT 0 NOT NULL,
    "systemChannelId" text,
    "systemChannelFlags" integer DEFAULT 0 NOT NULL,
    "rulesChannelId" text,
    "maxPresences2" integer,
    "vanityUrlCode" text,
    "premiumTier" integer DEFAULT 0 NOT NULL,
    "premiumSubscriptionCount" integer,
    "preferredLocale" text DEFAULT 'en-US'::text NOT NULL,
    "publicUpdatesChannelId" text,
    nsfw boolean DEFAULT false NOT NULL,
    "nsfwLevel" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Server" OWNER TO cryb_user;

--
-- Name: ServerAnalytics; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."ServerAnalytics" (
    id text NOT NULL,
    "serverId" text NOT NULL,
    "memberCount" integer NOT NULL,
    "onlineCount" integer NOT NULL,
    "messageCount" integer NOT NULL,
    "voiceMinutes" integer NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ServerAnalytics" OWNER TO cryb_user;

--
-- Name: ServerEmoji; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."ServerEmoji" (
    id text NOT NULL,
    "serverId" text NOT NULL,
    name text NOT NULL,
    image text NOT NULL,
    "requireColons" boolean DEFAULT true NOT NULL,
    managed boolean DEFAULT false NOT NULL,
    animated boolean DEFAULT false NOT NULL,
    available boolean DEFAULT true NOT NULL,
    roles jsonb,
    "user" jsonb
);


ALTER TABLE public."ServerEmoji" OWNER TO cryb_user;

--
-- Name: ServerMember; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."ServerMember" (
    id text NOT NULL,
    "serverId" text NOT NULL,
    "userId" text NOT NULL,
    nickname text,
    avatar text,
    banner text,
    bio text,
    "joinedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "premiumSince" timestamp(3) without time zone,
    deaf boolean DEFAULT false NOT NULL,
    mute boolean DEFAULT false NOT NULL,
    flags integer DEFAULT 0 NOT NULL,
    pending boolean DEFAULT false NOT NULL,
    permissions text,
    "communicationDisabledUntil" timestamp(3) without time zone
);


ALTER TABLE public."ServerMember" OWNER TO cryb_user;

--
-- Name: ServerSticker; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."ServerSticker" (
    id text NOT NULL,
    "serverId" text,
    name text NOT NULL,
    description text,
    tags text NOT NULL,
    type integer DEFAULT 1 NOT NULL,
    "formatType" integer NOT NULL,
    available boolean DEFAULT true NOT NULL,
    "sortValue" integer
);


ALTER TABLE public."ServerSticker" OWNER TO cryb_user;

--
-- Name: Session; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    "refreshToken" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Session" OWNER TO cryb_user;

--
-- Name: StakingPool; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."StakingPool" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "tokenAddress" text NOT NULL,
    "tokenSymbol" text NOT NULL,
    "tokenName" text NOT NULL,
    chain text DEFAULT 'ethereum'::text NOT NULL,
    apr double precision NOT NULL,
    "lockPeriod" integer,
    "minStakeAmount" text NOT NULL,
    "maxStakeAmount" text,
    "totalStaked" text DEFAULT '0'::text NOT NULL,
    "totalRewards" text DEFAULT '0'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."StakingPool" OWNER TO cryb_user;

--
-- Name: StakingReward; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."StakingReward" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "poolId" text NOT NULL,
    "stakeId" text NOT NULL,
    amount text NOT NULL,
    currency text NOT NULL,
    status public."RewardStatus" DEFAULT 'PENDING'::public."RewardStatus" NOT NULL,
    "txHash" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "claimedAt" timestamp(3) without time zone
);


ALTER TABLE public."StakingReward" OWNER TO cryb_user;

--
-- Name: Thread; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Thread" (
    id text NOT NULL,
    "channelId" text NOT NULL,
    "userId" text NOT NULL,
    name text NOT NULL,
    archived boolean DEFAULT false NOT NULL,
    locked boolean DEFAULT false NOT NULL,
    "autoArchive" integer DEFAULT 10080 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Thread" OWNER TO cryb_user;

--
-- Name: Token; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Token" (
    id text NOT NULL,
    "userId" text NOT NULL,
    address text NOT NULL,
    symbol text NOT NULL,
    name text NOT NULL,
    decimals integer NOT NULL,
    balance text NOT NULL,
    chain text NOT NULL,
    verified boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Token" OWNER TO cryb_user;

--
-- Name: TokenGatingRule; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."TokenGatingRule" (
    id text NOT NULL,
    "serverId" text,
    "channelId" text,
    "communityId" text,
    name text NOT NULL,
    description text,
    "ruleType" public."TokenGatingType" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."TokenGatingRule" OWNER TO cryb_user;

--
-- Name: TokenRequirement; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."TokenRequirement" (
    id text NOT NULL,
    "ruleId" text NOT NULL,
    "tokenAddress" text NOT NULL,
    symbol text NOT NULL,
    name text NOT NULL,
    chain text DEFAULT 'ethereum'::text NOT NULL,
    "minAmount" text NOT NULL
);


ALTER TABLE public."TokenRequirement" OWNER TO cryb_user;

--
-- Name: TranscodingJob; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."TranscodingJob" (
    id text NOT NULL,
    "fileId" text NOT NULL,
    "userId" text NOT NULL,
    "jobType" text NOT NULL,
    "inputBucket" text NOT NULL,
    "inputFilename" text NOT NULL,
    "outputFormats" jsonb NOT NULL,
    priority integer DEFAULT 2 NOT NULL,
    status text DEFAULT 'queued'::text NOT NULL,
    progress double precision DEFAULT 0 NOT NULL,
    "startedAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    error text,
    outputs jsonb,
    thumbnails jsonb,
    preview jsonb,
    waveform jsonb,
    metadata jsonb,
    "processingLogs" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."TranscodingJob" OWNER TO cryb_user;

--
-- Name: UploadChunk; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."UploadChunk" (
    id text NOT NULL,
    "sessionId" text NOT NULL,
    "chunkIndex" integer NOT NULL,
    size integer NOT NULL,
    hash text,
    uploaded boolean DEFAULT false NOT NULL,
    "uploadedAt" timestamp(3) without time zone
);


ALTER TABLE public."UploadChunk" OWNER TO cryb_user;

--
-- Name: UploadedFile; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."UploadedFile" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "originalName" text NOT NULL,
    filename text NOT NULL,
    "mimeType" text NOT NULL,
    size integer NOT NULL,
    hash text NOT NULL,
    bucket text NOT NULL,
    url text NOT NULL,
    "cdnUrl" text,
    "thumbnailUrl" text,
    "previewUrl" text,
    width integer,
    height integer,
    duration double precision,
    bitrate integer,
    framerate double precision,
    channels integer,
    "sampleRate" integer,
    "uploadType" text DEFAULT 'single'::text NOT NULL,
    "channelId" text,
    "messageId" text,
    processed boolean DEFAULT false NOT NULL,
    "scanPassed" boolean DEFAULT false NOT NULL,
    "scanResult" jsonb,
    validated boolean DEFAULT false NOT NULL,
    "validationErrors" text[] DEFAULT ARRAY[]::text[],
    "securityFlags" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "lastAccessedAt" timestamp(3) without time zone
);


ALTER TABLE public."UploadedFile" OWNER TO cryb_user;

--
-- Name: User; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text,
    username text NOT NULL,
    avatar text,
    "bannedAt" timestamp(3) without time zone,
    banner text,
    bio text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    discord_id text,
    discriminator text DEFAULT '0001'::text NOT NULL,
    "displayName" text NOT NULL,
    flags integer DEFAULT 0 NOT NULL,
    github_id text,
    google_id text,
    "isBot" boolean DEFAULT false NOT NULL,
    "isSystem" boolean DEFAULT false NOT NULL,
    "isVerified" boolean DEFAULT false NOT NULL,
    "lastSeenAt" timestamp(3) without time zone,
    locale text DEFAULT 'en-US'::text NOT NULL,
    "mfaEnabled" boolean DEFAULT false NOT NULL,
    "passwordHash" text,
    "premiumUntil" timestamp(3) without time zone,
    pronouns text,
    "publicFlags" integer DEFAULT 0 NOT NULL,
    "twoFactorBackupCodes" text[] DEFAULT ARRAY[]::text[],
    "twoFactorEnabled" boolean DEFAULT false NOT NULL,
    "twoFactorEnabledAt" timestamp(3) without time zone,
    "twoFactorSecret" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "walletAddress" text,
    "premiumType" text DEFAULT 'NONE'::public."PremiumType",
    "followerCount" integer DEFAULT 0 NOT NULL,
    "followingCount" integer DEFAULT 0 NOT NULL,
    "isPrivate" boolean DEFAULT false NOT NULL,
    location text,
    "postCount" integer DEFAULT 0 NOT NULL,
    "showActivityStatus" boolean DEFAULT true NOT NULL,
    "showWalletHoldings" boolean DEFAULT true NOT NULL,
    "socialLinks" jsonb,
    website text
);


ALTER TABLE public."User" OWNER TO cryb_user;

--
-- Name: UserActivity; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."UserActivity" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "presenceId" text,
    type public."ActivityType" NOT NULL,
    name text NOT NULL,
    details text,
    state text,
    "applicationId" text,
    url text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    timestamps jsonb,
    assets jsonb,
    party jsonb,
    secrets jsonb,
    instance boolean DEFAULT false NOT NULL,
    flags integer DEFAULT 0 NOT NULL
);


ALTER TABLE public."UserActivity" OWNER TO cryb_user;

--
-- Name: UserBadge; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."UserBadge" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "badgeId" text NOT NULL,
    "earnedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isVisible" boolean DEFAULT true NOT NULL
);


ALTER TABLE public."UserBadge" OWNER TO cryb_user;

--
-- Name: UserNFT; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."UserNFT" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "nftId" text NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    "lastVerifiedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."UserNFT" OWNER TO cryb_user;

--
-- Name: UserPresence; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."UserPresence" (
    id text NOT NULL,
    "userId" text NOT NULL,
    status public."PresenceStatus" DEFAULT 'OFFLINE'::public."PresenceStatus" NOT NULL,
    "clientStatus" jsonb,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."UserPresence" OWNER TO cryb_user;

--
-- Name: UserProfilePicture; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."UserProfilePicture" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "nftId" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."UserProfilePicture" OWNER TO cryb_user;

--
-- Name: UserStake; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."UserStake" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "poolId" text NOT NULL,
    amount text NOT NULL,
    "lockedUntil" timestamp(3) without time zone,
    status public."StakeStatus" DEFAULT 'ACTIVE'::public."StakeStatus" NOT NULL,
    "txHash" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "withdrawnAt" timestamp(3) without time zone
);


ALTER TABLE public."UserStake" OWNER TO cryb_user;

--
-- Name: VoiceAnalytics; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."VoiceAnalytics" (
    id text NOT NULL,
    "serverId" text,
    "channelId" text NOT NULL,
    "userId" text NOT NULL,
    "sessionDuration" integer NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."VoiceAnalytics" OWNER TO cryb_user;

--
-- Name: VoiceState; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."VoiceState" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "serverId" text,
    "channelId" text,
    "sessionId" text NOT NULL,
    deaf boolean DEFAULT false NOT NULL,
    mute boolean DEFAULT false NOT NULL,
    "selfDeaf" boolean DEFAULT false NOT NULL,
    "selfMute" boolean DEFAULT false NOT NULL,
    "selfStream" boolean DEFAULT false NOT NULL,
    "selfVideo" boolean DEFAULT false NOT NULL,
    suppress boolean DEFAULT false NOT NULL,
    "requestToSpeakTimestamp" timestamp(3) without time zone,
    "connectedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."VoiceState" OWNER TO cryb_user;

--
-- Name: Vote; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public."Vote" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "postId" text,
    "commentId" text,
    value integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Vote" OWNER TO cryb_user;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO cryb_user;

--
-- Name: brad_waitlist; Type: TABLE; Schema: public; Owner: cryb_user
--

CREATE TABLE public.brad_waitlist (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    interest text NOT NULL,
    "submittedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.brad_waitlist OWNER TO cryb_user;

--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."AuditLog" (id, "serverId", "userId", "targetId", "actionType", options, reason, changes, "createdAt") FROM stdin;
\.


--
-- Data for Name: Award; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Award" (id, "postId", "commentId", type, cost, message, anonymous, "giverId", "receiverId", "createdAt") FROM stdin;
\.


--
-- Data for Name: Ban; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Ban" (id, "serverId", "userId", reason, "bannedBy", "createdAt") FROM stdin;
\.


--
-- Data for Name: Block; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Block" (id, "blockerId", "blockedId", "createdAt") FROM stdin;
\.


--
-- Data for Name: Bookmark; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Bookmark" (id, "userId", "postId", "createdAt") FROM stdin;
\.


--
-- Data for Name: Channel; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Channel" (id, "serverId", name, topic, description, type, "position", "isPrivate", "parentId", "slowMode", nsfw, bitrate, "userLimit", "rtcRegion", "videoQualityMode", "defaultAutoArchiveDuration", flags, "lastMessageId", "lastPinTimestamp", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ChannelPermission; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."ChannelPermission" (id, "channelId", "roleId", "userId", allow, deny) FROM stdin;
\.


--
-- Data for Name: ChunkedUploadSession; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."ChunkedUploadSession" (id, "userId", filename, "mimeType", "totalSize", "chunkSize", "totalChunks", "uploadedChunks", "tempPath", metadata, status, completed, "createdAt", "updatedAt", "lastActivity", "expiresAt") FROM stdin;
\.


--
-- Data for Name: Comment; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Comment" (id, content, "createdAt", "editedAt", "parentId", "postId", score, "updatedAt", "userId", depth, "likeCount", "replyCount") FROM stdin;
cmgu2gnme00arqlwc7xubvywu	Thanks for posting this! Very informative.	2025-10-08 19:59:41.404	\N	\N	cmgu2gnep0057qlwcxevt29ue	58	2025-10-16 23:44:09.111	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gnmj00atqlwc6h4yuj3j	Could you elaborate more on this point?	2025-09-27 00:16:21.252	\N	\N	cmgu2gnep0057qlwcxevt29ue	12	2025-10-16 23:44:09.115	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gnmm00avqlwc62qb1o8t	Following this thread. Great discussion!	2025-10-16 13:41:04.739	\N	\N	cmgu2gnep0057qlwcxevt29ue	27	2025-10-16 23:44:09.118	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gnmp00axqlwcqjovy1rg	What resources would you recommend for learning more?	2025-09-29 06:19:41.519	\N	\N	cmgu2gnep0057qlwcxevt29ue	6	2025-10-16 23:44:09.121	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gnms00azqlwct0acafyn	I disagree, but I respect your opinion.	2025-10-01 08:54:06.525	\N	\N	cmgu2gnep0057qlwcxevt29ue	0	2025-10-16 23:44:09.124	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gnmv00b1qlwc8xt3p5br	Update: I tried this and it worked perfectly!	2025-09-30 11:48:20.858	\N	\N	cmgu2gnep0057qlwcxevt29ue	83	2025-10-16 23:44:09.127	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gnn200b3qlwcbfxfdwt1	I've been doing this for years and can vouch for it.	2025-09-17 11:10:38.047	\N	\N	cmgu2gnev0059qlwcas2j7yrr	82	2025-10-16 23:44:09.134	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnn800b5qlwczm7hv54p	Update: I tried this and it worked perfectly!	2025-10-11 04:46:10.025	\N	\N	cmgu2gnev0059qlwcas2j7yrr	27	2025-10-16 23:44:09.14	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gnnb00b7qlwck2rbx6g7	What resources would you recommend for learning more?	2025-09-12 09:37:55.434	\N	\N	cmgu2gnev0059qlwcas2j7yrr	84	2025-10-16 23:44:09.143	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gnnd00b9qlwcqi9y0u7z	I had the same experience! Thanks for sharing.	2025-07-07 23:29:54.132	\N	\N	cmgu2gnev0059qlwcas2j7yrr	90	2025-10-16 23:44:09.146	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnng00bbqlwc62443rks	Temeritas claustrum deficio. Recusandae adversus blanditiis voluptatum verto velum abeo ipsum amplitudo cito. Reiciendis aspernatur sonitus demergo decens.	2025-10-01 10:06:45.726	\N	\N	cmgu2gnev0059qlwcas2j7yrr	11	2025-10-16 23:44:09.149	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gnnj00bdqlwcp56e9nag	Bellicus accusantium acquiro delectatio placeat sequi infit quam crustulum theologus. Auctor tero cenaculum demergo atrocitas patrocinor ver. Ver crepusculum sordeo acies aeger.	2025-09-04 17:44:07.641	\N	\N	cmgu2gnev0059qlwcas2j7yrr	65	2025-10-16 23:44:09.152	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gnnm00bfqlwc0a7w90gx	Bookmarking this for later. Excellent content!	2025-10-07 17:24:40.641	\N	\N	cmgu2gnev0059qlwcas2j7yrr	70	2025-10-16 23:44:09.154	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gnnr00bhqlwct6dshopx	I had the same experience! Thanks for sharing.	2025-05-10 00:26:11.928	\N	\N	cmgu2gney005bqlwc5wpupra3	61	2025-10-16 23:44:09.159	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gnnu00bjqlwcew9xxlpg	Following this thread. Great discussion!	2025-09-06 00:41:53.05	\N	\N	cmgu2gney005bqlwc5wpupra3	28	2025-10-16 23:44:09.162	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gnnw00blqlwcxxrdxjju	Thanks for posting this! Very informative.	2025-08-03 20:39:10.994	\N	\N	cmgu2gney005bqlwc5wpupra3	72	2025-10-16 23:44:09.164	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnny00bnqlwctlk8l119	Thanks for posting this! Very informative.	2025-07-16 15:45:20.075	\N	\N	cmgu2gney005bqlwc5wpupra3	67	2025-10-16 23:44:09.167	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gno400bpqlwc4jh4iz2y	This is a game changer. Thank you!	2025-08-13 19:28:42.31	\N	\N	cmgu2gney005bqlwc5wpupra3	87	2025-10-16 23:44:09.172	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gno600brqlwc197g2z2c	This is a game changer. Thank you!	2025-06-20 13:23:41.628	\N	\N	cmgu2gney005bqlwc5wpupra3	92	2025-10-16 23:44:09.175	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gnoe00btqlwc69xxe4jl	Can confirm, this is accurate.	2025-09-26 10:48:12.799	\N	\N	cmgu2gnf1005dqlwckgg33wwt	44	2025-10-16 23:44:09.182	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gnog00bvqlwca1lxnzyi	This deserves more upvotes!	2025-10-01 05:46:57.684	\N	\N	cmgu2gnf1005dqlwckgg33wwt	12	2025-10-16 23:44:09.184	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gnoi00bxqlwcsm0z6uuh	This deserves more upvotes!	2025-10-14 01:57:34.352	\N	\N	cmgu2gnf1005dqlwckgg33wwt	67	2025-10-16 23:44:09.187	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gnol00bzqlwcw8g6a8k0	Following this thread. Great discussion!	2025-10-14 23:35:23.564	\N	\N	cmgu2gnf1005dqlwckgg33wwt	94	2025-10-16 23:44:09.189	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gnon00c1qlwc1awan5wn	This is exactly what I needed. Saved!	2025-09-22 15:29:21.644	\N	\N	cmgu2gnf1005dqlwckgg33wwt	43	2025-10-16 23:44:09.192	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gnoq00c3qlwcafabtgdv	What resources would you recommend for learning more?	2025-10-07 05:04:57.184	\N	\N	cmgu2gnf1005dqlwckgg33wwt	45	2025-10-16 23:44:09.194	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnos00c5qlwcea5v2345	Following this thread. Great discussion!	2025-09-29 09:33:02.947	\N	\N	cmgu2gnf1005dqlwckgg33wwt	89	2025-10-16 23:44:09.197	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gnou00c7qlwcu9j4ibn1	Bookmarking this for later. Excellent content!	2025-10-03 18:09:37.44	\N	\N	cmgu2gnf1005dqlwckgg33wwt	39	2025-10-16 23:44:09.199	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gnoz00c9qlwcbchjpwce	This is exactly what I needed. Saved!	2025-06-22 01:29:47.84	\N	\N	cmgu2gnf5005fqlwcoglbuqud	79	2025-10-16 23:44:09.204	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gnp200cbqlwc9unyl7lc	What resources would you recommend for learning more?	2025-10-16 21:14:04.241	\N	\N	cmgu2gnf5005fqlwcoglbuqud	57	2025-10-16 23:44:09.206	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gnp400cdqlwc2wytxg8u	Bookmarking this for later. Excellent content!	2025-10-08 17:13:41.845	\N	\N	cmgu2gnf5005fqlwcoglbuqud	11	2025-10-16 23:44:09.208	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gnp700cfqlwcupkf8i0x	This is a game changer. Thank you!	2025-05-11 07:09:06.227	\N	\N	cmgu2gnf5005fqlwcoglbuqud	36	2025-10-16 23:44:09.211	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gnp900chqlwc8pqe411f	Can confirm, this is accurate.	2025-09-23 13:18:46.389	\N	\N	cmgu2gnf5005fqlwcoglbuqud	27	2025-10-16 23:44:09.213	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gnpb00cjqlwcb88tjdt4	I disagree, but I respect your opinion.	2025-05-21 17:58:20.866	\N	\N	cmgu2gnf5005fqlwcoglbuqud	100	2025-10-16 23:44:09.216	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gnpe00clqlwc2ylsbrku	I disagree, but I respect your opinion.	2025-08-01 15:09:27.171	\N	\N	cmgu2gnf5005fqlwcoglbuqud	21	2025-10-16 23:44:09.218	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gnpg00cnqlwcjpzwozhp	I had the same experience! Thanks for sharing.	2025-07-13 01:44:06.979	\N	\N	cmgu2gnf5005fqlwcoglbuqud	90	2025-10-16 23:44:09.22	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gnpm00cpqlwcj8gf7eyb	Interesting perspective. I never thought about it that way.	2025-09-07 19:40:49.445	\N	\N	cmgu2gnf8005hqlwc31vhv72o	39	2025-10-16 23:44:09.227	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gnpo00crqlwcjeqxhqdw	This is exactly what I needed. Saved!	2025-09-26 22:07:26.647	\N	\N	cmgu2gnf8005hqlwc31vhv72o	87	2025-10-16 23:44:09.229	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gnpr00ctqlwcszrmdmgg	I had the same experience! Thanks for sharing.	2025-08-08 05:48:48.985	\N	\N	cmgu2gnf8005hqlwc31vhv72o	98	2025-10-16 23:44:09.232	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnpu00cvqlwcu7eycy1n	Bookmarking this for later. Excellent content!	2025-05-30 02:00:10.685	\N	\N	cmgu2gnf8005hqlwc31vhv72o	71	2025-10-16 23:44:09.234	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gnpw00cxqlwcsm2ei5va	Can confirm, this is accurate.	2025-06-17 16:09:37.229	\N	\N	cmgu2gnf8005hqlwc31vhv72o	44	2025-10-16 23:44:09.236	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gnpy00czqlwcksuv4byo	I disagree, but I respect your opinion.	2025-08-21 01:35:25.317	\N	\N	cmgu2gnf8005hqlwc31vhv72o	43	2025-10-16 23:44:09.238	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gnq000d1qlwcbf9ieomx	This is a game changer. Thank you!	2025-04-10 22:19:48.791	\N	\N	cmgu2gnf8005hqlwc31vhv72o	65	2025-10-16 23:44:09.24	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gnq200d3qlwcn2q8dajf	I had the same experience! Thanks for sharing.	2025-06-19 21:54:01.466	\N	\N	cmgu2gnf8005hqlwc31vhv72o	96	2025-10-16 23:44:09.243	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gnq400d5qlwcybp1bnis	What resources would you recommend for learning more?	2025-06-21 15:01:04.464	\N	\N	cmgu2gnf8005hqlwc31vhv72o	32	2025-10-16 23:44:09.245	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gnq700d7qlwc55an9s2i	Update: I tried this and it worked perfectly!	2025-08-12 10:29:39.195	\N	\N	cmgu2gnf8005hqlwc31vhv72o	25	2025-10-16 23:44:09.247	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gnqc00d9qlwcrjjvrdtw	This is a game changer. Thank you!	2025-09-28 20:05:01.472	\N	\N	cmgu2gnfc005jqlwccmsu8ny1	10	2025-10-16 23:44:09.252	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gnqe00dbqlwce43zaz6y	This is exactly what I needed. Saved!	2025-09-30 14:19:34.293	\N	\N	cmgu2gnfc005jqlwccmsu8ny1	6	2025-10-16 23:44:09.254	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gnqh00ddqlwc3mtt2rpp	Update: I tried this and it worked perfectly!	2025-09-27 12:56:50.356	\N	\N	cmgu2gnfc005jqlwccmsu8ny1	33	2025-10-16 23:44:09.257	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gnqj00dfqlwc1y167962	Interesting perspective. I never thought about it that way.	2025-09-29 02:57:57.435	\N	\N	cmgu2gnfc005jqlwccmsu8ny1	34	2025-10-16 23:44:09.259	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gnqn00dhqlwcfr1y7cib	Thanks for posting this! Very informative.	2025-09-10 09:47:10.58	\N	\N	cmgu2gnfc005jqlwccmsu8ny1	28	2025-10-16 23:44:09.263	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gnqt00djqlwcwcghysou	Following this thread. Great discussion!	2025-09-30 20:34:44.184	\N	\N	cmgu2gnff005lqlwcea7weget	-1	2025-10-16 23:44:09.269	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gnqv00dlqlwcajg1vosw	I disagree, but I respect your opinion.	2025-10-15 16:29:30.896	\N	\N	cmgu2gnff005lqlwcea7weget	72	2025-10-16 23:44:09.272	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnqx00dnqlwcgdgdrbpa	This is exactly what I needed. Saved!	2025-09-29 10:51:26.532	\N	\N	cmgu2gnff005lqlwcea7weget	-1	2025-10-16 23:44:09.274	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gnr000dpqlwc4a0aalpu	Great post! Really helpful information.	2025-10-16 15:32:26.157	\N	\N	cmgu2gnff005lqlwcea7weget	93	2025-10-16 23:44:09.276	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnr200drqlwc3qqwursr	Can confirm, this is accurate.	2025-10-03 05:48:12.01	\N	\N	cmgu2gnff005lqlwcea7weget	51	2025-10-16 23:44:09.279	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gnr400dtqlwcw83l2n36	Bookmarking this for later. Excellent content!	2025-10-10 07:41:40.537	\N	\N	cmgu2gnff005lqlwcea7weget	80	2025-10-16 23:44:09.281	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gnr700dvqlwccbu5ckps	This is a game changer. Thank you!	2025-09-30 01:00:57.829	\N	\N	cmgu2gnff005lqlwcea7weget	82	2025-10-16 23:44:09.283	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gnrd00dxqlwcuk0t4tr5	This is a game changer. Thank you!	2025-07-10 23:07:55.595	\N	\N	cmgu2gnfi005nqlwcnzqeyknu	40	2025-10-16 23:44:09.29	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gnrg00dzqlwc5xng0uac	I disagree, but I respect your opinion.	2025-10-03 15:01:04.505	\N	\N	cmgu2gnfi005nqlwcnzqeyknu	4	2025-10-16 23:44:09.292	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gnri00e1qlwc8rwds9dx	I've been doing this for years and can vouch for it.	2025-06-26 07:12:44.607	\N	\N	cmgu2gnfi005nqlwcnzqeyknu	6	2025-10-16 23:44:09.294	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gnrk00e3qlwc64pmi71s	I had the same experience! Thanks for sharing.	2025-09-26 16:54:27.498	\N	\N	cmgu2gnfi005nqlwcnzqeyknu	61	2025-10-16 23:44:09.296	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gnrm00e5qlwc68t5mwvf	This deserves more upvotes!	2025-07-03 07:32:56.259	\N	\N	cmgu2gnfi005nqlwcnzqeyknu	32	2025-10-16 23:44:09.298	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gnrp00e7qlwcsysa4d54	Can confirm, this is accurate.	2025-09-25 11:05:19.12	\N	\N	cmgu2gnfi005nqlwcnzqeyknu	27	2025-10-16 23:44:09.301	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnrr00e9qlwcjwcabn2j	This deserves more upvotes!	2025-08-30 02:58:50.368	\N	\N	cmgu2gnfi005nqlwcnzqeyknu	38	2025-10-16 23:44:09.304	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gnru00ebqlwc07w4gr16	Coaegresco comes animus sulum defessus ait autem amitto. Sonitus sustineo via calculus trado suadeo. Arbitro antiquus earum.	2025-07-12 18:04:50.559	\N	\N	cmgu2gnfi005nqlwcnzqeyknu	30	2025-10-16 23:44:09.306	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gnrx00edqlwcrxhfmgig	What resources would you recommend for learning more?	2025-07-19 13:43:23.557	\N	\N	cmgu2gnfi005nqlwcnzqeyknu	82	2025-10-16 23:44:09.309	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gns300efqlwcpf2tv6zg	Interesting perspective. I never thought about it that way.	2025-08-14 01:33:25.226	\N	\N	cmgu2gnfl005pqlwccawv8ggk	-2	2025-10-16 23:44:09.315	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gns500ehqlwc5q44k4qk	What resources would you recommend for learning more?	2025-09-26 05:25:34.7	\N	\N	cmgu2gnfl005pqlwccawv8ggk	71	2025-10-16 23:44:09.317	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gns800ejqlwcos1l1krx	Could you elaborate more on this point?	2025-08-14 09:16:50.124	\N	\N	cmgu2gnfl005pqlwccawv8ggk	2	2025-10-16 23:44:09.321	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gnsb00elqlwc5m0gs4bz	Update: I tried this and it worked perfectly!	2025-09-17 07:32:09.358	\N	\N	cmgu2gnfl005pqlwccawv8ggk	94	2025-10-16 23:44:09.324	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnsd00enqlwc4895ldqv	I had the same experience! Thanks for sharing.	2025-08-12 18:37:01.289	\N	\N	cmgu2gnfl005pqlwccawv8ggk	27	2025-10-16 23:44:09.326	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gnsf00epqlwcp5ezs012	Thanks for posting this! Very informative.	2025-09-30 20:13:42.383	\N	\N	cmgu2gnfl005pqlwccawv8ggk	58	2025-10-16 23:44:09.328	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gnsh00erqlwcoh47iqbf	Could you elaborate more on this point?	2025-09-03 11:43:17.455	\N	\N	cmgu2gnfl005pqlwccawv8ggk	40	2025-10-16 23:44:09.33	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gnsk00etqlwcv32uxu7z	What resources would you recommend for learning more?	2025-08-27 13:12:57.092	\N	\N	cmgu2gnfl005pqlwccawv8ggk	43	2025-10-16 23:44:09.332	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gnsm00evqlwcxav8ptnp	This deserves more upvotes!	2025-08-18 01:30:06.385	\N	\N	cmgu2gnfl005pqlwccawv8ggk	31	2025-10-16 23:44:09.334	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gnsq00exqlwcjq5zw6ox	Update: I tried this and it worked perfectly!	2025-05-22 23:16:04.127	\N	\N	cmgu2gnfn005rqlwcc1mkauba	19	2025-10-16 23:44:09.338	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gnss00ezqlwcvxkanicq	I've been doing this for years and can vouch for it.	2025-02-20 02:54:06.735	\N	\N	cmgu2gnfn005rqlwcc1mkauba	68	2025-10-16 23:44:09.341	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gnsv00f1qlwc9udd8et4	Great post! Really helpful information.	2025-07-07 04:10:29.528	\N	\N	cmgu2gnfn005rqlwcc1mkauba	96	2025-10-16 23:44:09.343	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gnsy00f3qlwc29kqqj9u	Could you elaborate more on this point?	2025-09-21 08:49:25.408	\N	\N	cmgu2gnfn005rqlwcc1mkauba	57	2025-10-16 23:44:09.346	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gnt000f5qlwc9hb9xqaa	This is a game changer. Thank you!	2025-04-14 06:33:17.502	\N	\N	cmgu2gnfn005rqlwcc1mkauba	60	2025-10-16 23:44:09.348	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnt400f7qlwctld9118f	Interesting perspective. I never thought about it that way.	2025-02-03 21:35:33.63	\N	\N	cmgu2gnfn005rqlwcc1mkauba	77	2025-10-16 23:44:09.353	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gnt700f9qlwcs72f2uzt	This is a game changer. Thank you!	2025-02-11 06:41:06.617	\N	\N	cmgu2gnfn005rqlwcc1mkauba	58	2025-10-16 23:44:09.355	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gnt900fbqlwcjennc599	Venia viridis tricesimus adaugeo. Vomica caelum deficio aegrotatio cum accusantium tenax asperiores. Confero bis stultus deficio.	2025-06-25 15:07:39.917	\N	\N	cmgu2gnfn005rqlwcc1mkauba	6	2025-10-16 23:44:09.358	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gntc00fdqlwcmwwxowmi	Bookmarking this for later. Excellent content!	2025-01-13 06:29:57.741	\N	\N	cmgu2gnfn005rqlwcc1mkauba	36	2025-10-16 23:44:09.36	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gnth00ffqlwcbz2bwqnh	Antea coepi vilitas vivo. Bellum acidus cohibeo voluntarius itaque cresco viriliter bonus. Vallum trans coniuratio cupiditas autem bardus vergo venustas apostolus.	2025-10-16 22:27:49.551	\N	\N	cmgu2gnfq005tqlwc546jitoa	82	2025-10-16 23:44:09.365	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gntj00fhqlwcoyubcx40	Thanks for posting this! Very informative.	2025-10-13 07:59:13.372	\N	\N	cmgu2gnfq005tqlwc546jitoa	68	2025-10-16 23:44:09.367	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gntl00fjqlwclpdmc7fb	I had the same experience! Thanks for sharing.	2025-10-08 11:55:42.502	\N	\N	cmgu2gnfq005tqlwc546jitoa	94	2025-10-16 23:44:09.37	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gntn00flqlwcwoqza77y	Update: I tried this and it worked perfectly!	2025-10-07 18:20:57.935	\N	\N	cmgu2gnfq005tqlwc546jitoa	83	2025-10-16 23:44:09.372	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gntp00fnqlwcli32apmb	Bookmarking this for later. Excellent content!	2025-10-12 16:59:10.378	\N	\N	cmgu2gnfq005tqlwc546jitoa	2	2025-10-16 23:44:09.374	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gnts00fpqlwckbklu80g	This is exactly what I needed. Saved!	2025-10-15 07:41:34.336	\N	\N	cmgu2gnfq005tqlwc546jitoa	81	2025-10-16 23:44:09.376	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gntu00frqlwca7er4p2v	Can confirm, this is accurate.	2025-10-11 13:04:20.719	\N	\N	cmgu2gnfq005tqlwc546jitoa	84	2025-10-16 23:44:09.378	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gntx00ftqlwc5blq484x	What resources would you recommend for learning more?	2025-10-11 07:04:23.09	\N	\N	cmgu2gnfq005tqlwc546jitoa	60	2025-10-16 23:44:09.381	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gnu200fvqlwc445sys0d	Can confirm, this is accurate.	2025-10-07 10:26:28.224	\N	\N	cmgu2gnfq005tqlwc546jitoa	92	2025-10-16 23:44:09.386	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gnu700fxqlwc3lkpc2dn	Thanks for posting this! Very informative.	2025-10-09 04:09:31.253	\N	\N	cmgu2gnfq005tqlwc546jitoa	34	2025-10-16 23:44:09.391	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gnue00fzqlwcexvi81sn	Could you elaborate more on this point?	2025-10-09 18:16:45.68	\N	\N	cmgu2gnfs005vqlwclpefas5f	-5	2025-10-16 23:44:09.399	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gnuh00g1qlwcjggquoa4	This deserves more upvotes!	2025-01-27 15:59:32.872	\N	\N	cmgu2gnfs005vqlwclpefas5f	26	2025-10-16 23:44:09.401	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gnuk00g3qlwckb3nhohu	Could you elaborate more on this point?	2025-09-02 07:48:59.901	\N	\N	cmgu2gnfs005vqlwclpefas5f	50	2025-10-16 23:44:09.404	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gnum00g5qlwc84p21f6v	I disagree, but I respect your opinion.	2025-02-03 05:56:57.327	\N	\N	cmgu2gnfs005vqlwclpefas5f	39	2025-10-16 23:44:09.407	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gnup00g7qlwcf0x9enxa	Great post! Really helpful information.	2025-10-01 20:49:07.484	\N	\N	cmgu2gnfs005vqlwclpefas5f	64	2025-10-16 23:44:09.409	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gnur00g9qlwc1v1552ag	Thanks for posting this! Very informative.	2025-05-10 11:11:46.777	\N	\N	cmgu2gnfs005vqlwclpefas5f	60	2025-10-16 23:44:09.412	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnuu00gbqlwckmnfnvp6	This is exactly what I needed. Saved!	2025-04-15 01:46:15.168	\N	\N	cmgu2gnfs005vqlwclpefas5f	51	2025-10-16 23:44:09.414	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gnuw00gdqlwcuzy09cf8	Can confirm, this is accurate.	2025-02-09 00:52:34.096	\N	\N	cmgu2gnfs005vqlwclpefas5f	60	2025-10-16 23:44:09.417	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gnuz00gfqlwcjsy7fnph	Update: I tried this and it worked perfectly!	2025-09-22 16:53:25.16	\N	\N	cmgu2gnfs005vqlwclpefas5f	29	2025-10-16 23:44:09.419	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gnv300ghqlwca5bkosz6	I've been doing this for years and can vouch for it.	2025-10-09 17:47:26.684	\N	\N	cmgu2gnfv005xqlwcy9xwozs5	46	2025-10-16 23:44:09.424	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gnv600gjqlwckmfz7x86	I had the same experience! Thanks for sharing.	2025-10-10 04:10:44.384	\N	\N	cmgu2gnfv005xqlwcy9xwozs5	88	2025-10-16 23:44:09.426	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gnv900glqlwcioen4e9s	Great post! Really helpful information.	2025-09-16 02:34:13.137	\N	\N	cmgu2gnfv005xqlwcy9xwozs5	22	2025-10-16 23:44:09.429	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gnvb00gnqlwcium5e5cv	What resources would you recommend for learning more?	2025-09-04 20:43:32.88	\N	\N	cmgu2gnfv005xqlwcy9xwozs5	53	2025-10-16 23:44:09.432	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnve00gpqlwcg8ufo3pu	This is a game changer. Thank you!	2025-10-10 02:12:49.529	\N	\N	cmgu2gnfv005xqlwcy9xwozs5	60	2025-10-16 23:44:09.434	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gnvg00grqlwcx13hijoz	I had the same experience! Thanks for sharing.	2025-09-09 08:21:35.146	\N	\N	cmgu2gnfv005xqlwcy9xwozs5	86	2025-10-16 23:44:09.437	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gnvj00gtqlwcvr00rgoi	This is exactly what I needed. Saved!	2025-09-24 11:06:54.395	\N	\N	cmgu2gnfv005xqlwcy9xwozs5	72	2025-10-16 23:44:09.439	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gnvo00gvqlwcbn8exspb	I've been doing this for years and can vouch for it.	2025-04-05 22:56:41.578	\N	\N	cmgu2gnfx005zqlwcdtj10tam	9	2025-10-16 23:44:09.445	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gnvr00gxqlwcjd1c5c20	Ulciscor adamo libero curto placeat vilitas vomica voluptatibus. Vulgivagus demo conservo defendo alter. Quasi soluta voro coniuratio aeternus qui.	2025-05-01 06:14:38.219	\N	\N	cmgu2gnfx005zqlwcdtj10tam	59	2025-10-16 23:44:09.447	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gnvt00gzqlwcq5yivrf2	Can confirm, this is accurate.	2025-02-24 00:15:15.251	\N	\N	cmgu2gnfx005zqlwcdtj10tam	95	2025-10-16 23:44:09.45	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gnvw00h1qlwc81w8yx45	Interesting perspective. I never thought about it that way.	2025-03-22 23:27:23.986	\N	\N	cmgu2gnfx005zqlwcdtj10tam	41	2025-10-16 23:44:09.452	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gnvy00h3qlwckpdwlfzu	This deserves more upvotes!	2025-04-03 06:38:32.179	\N	\N	cmgu2gnfx005zqlwcdtj10tam	41	2025-10-16 23:44:09.454	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gnw100h5qlwcy0guobso	This is a game changer. Thank you!	2025-06-05 00:14:06.859	\N	\N	cmgu2gnfx005zqlwcdtj10tam	48	2025-10-16 23:44:09.457	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gnw300h7qlwcnrm82vcc	Update: I tried this and it worked perfectly!	2025-01-02 12:14:57.865	\N	\N	cmgu2gnfx005zqlwcdtj10tam	31	2025-10-16 23:44:09.459	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gnw600h9qlwctgnme5cl	Interesting perspective. I never thought about it that way.	2025-03-18 21:30:04.762	\N	\N	cmgu2gnfx005zqlwcdtj10tam	79	2025-10-16 23:44:09.462	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gnw800hbqlwc9vieg5xf	What resources would you recommend for learning more?	2025-03-27 13:57:10.286	\N	\N	cmgu2gnfx005zqlwcdtj10tam	47	2025-10-16 23:44:09.464	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gnwc00hdqlwcvuak7h71	Interesting perspective. I never thought about it that way.	2025-07-04 07:02:35.484	\N	\N	cmgu2gnfx005zqlwcdtj10tam	9	2025-10-16 23:44:09.468	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnwh00hfqlwcfgh8rxyc	Following this thread. Great discussion!	2025-06-23 15:31:55.939	\N	\N	cmgu2gng00061qlwcl70jll7j	91	2025-10-16 23:44:09.473	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gnwj00hhqlwcjnbq207y	Update: I tried this and it worked perfectly!	2025-02-24 02:51:18.82	\N	\N	cmgu2gng00061qlwcl70jll7j	8	2025-10-16 23:44:09.476	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gnwn00hjqlwcm0hc201b	Sum cunctatio taedium ager vulgivagus tamquam repellendus thesaurus corrigo. Pecto voluptate advoco cedo villa decens. Tener vitiosus aveho subiungo subvenio beatae.	2025-02-04 01:45:20.517	\N	\N	cmgu2gng00061qlwcl70jll7j	65	2025-10-16 23:44:09.479	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gnwp00hlqlwc3e6qyf2j	Could you elaborate more on this point?	2025-07-26 21:26:29.021	\N	\N	cmgu2gng00061qlwcl70jll7j	-4	2025-10-16 23:44:09.481	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gnws00hnqlwcpx026t9g	Interesting perspective. I never thought about it that way.	2025-03-01 18:59:41.425	\N	\N	cmgu2gng00061qlwcl70jll7j	95	2025-10-16 23:44:09.485	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gnwv00hpqlwcalxiig5e	Interesting perspective. I never thought about it that way.	2025-08-28 17:10:36.077	\N	\N	cmgu2gng00061qlwcl70jll7j	52	2025-10-16 23:44:09.487	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gnwx00hrqlwcm18cwv3w	Update: I tried this and it worked perfectly!	2025-01-24 06:56:27.916	\N	\N	cmgu2gng00061qlwcl70jll7j	85	2025-10-16 23:44:09.489	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gnwz00htqlwc0badz2ia	Could you elaborate more on this point?	2025-09-01 02:15:53.178	\N	\N	cmgu2gng00061qlwcl70jll7j	88	2025-10-16 23:44:09.492	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnx400hvqlwce6g6ywc7	I had the same experience! Thanks for sharing.	2025-07-09 23:07:30.798	\N	\N	cmgu2gng30063qlwc4kk643yf	7	2025-10-16 23:44:09.496	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gnx700hxqlwcmm0o4tx7	Thanks for posting this! Very informative.	2025-01-22 19:20:57.315	\N	\N	cmgu2gng30063qlwc4kk643yf	96	2025-10-16 23:44:09.499	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnx900hzqlwcs8osqm8k	This is exactly what I needed. Saved!	2025-05-10 19:59:45.884	\N	\N	cmgu2gng30063qlwc4kk643yf	76	2025-10-16 23:44:09.501	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gnxb00i1qlwcfn14yjld	I disagree, but I respect your opinion.	2024-12-10 07:01:49.078	\N	\N	cmgu2gng30063qlwc4kk643yf	93	2025-10-16 23:44:09.504	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gnxe00i3qlwcogdv3jir	Bookmarking this for later. Excellent content!	2025-08-26 23:07:05.81	\N	\N	cmgu2gng30063qlwc4kk643yf	18	2025-10-16 23:44:09.506	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gnxg00i5qlwcyt6fd5kv	I've been doing this for years and can vouch for it.	2025-04-28 08:20:12.405	\N	\N	cmgu2gng30063qlwc4kk643yf	-4	2025-10-16 23:44:09.508	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gnxi00i7qlwc73s354ch	What resources would you recommend for learning more?	2025-02-24 00:16:49.793	\N	\N	cmgu2gng30063qlwc4kk643yf	4	2025-10-16 23:44:09.511	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gnxl00i9qlwc7citnp2l	Could you elaborate more on this point?	2025-06-08 05:47:02.258	\N	\N	cmgu2gng30063qlwc4kk643yf	47	2025-10-16 23:44:09.514	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gnxs00ibqlwc9l09i03r	Thanks for posting this! Very informative.	2025-07-21 00:31:02.241	\N	\N	cmgu2gng50065qlwcpqngix97	99	2025-10-16 23:44:09.52	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gnxu00idqlwc40qrw8u2	Update: I tried this and it worked perfectly!	2025-09-01 16:25:10.984	\N	\N	cmgu2gng50065qlwcpqngix97	46	2025-10-16 23:44:09.523	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gnxx00ifqlwcsxjwrhjf	Update: I tried this and it worked perfectly!	2025-06-24 02:48:17.751	\N	\N	cmgu2gng50065qlwcpqngix97	55	2025-10-16 23:44:09.525	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gnxz00ihqlwcc88353t0	I had the same experience! Thanks for sharing.	2025-04-21 19:39:17.252	\N	\N	cmgu2gng50065qlwcpqngix97	27	2025-10-16 23:44:09.528	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gny100ijqlwcbu2p3vdj	I disagree, but I respect your opinion.	2025-08-04 17:48:08.005	\N	\N	cmgu2gng50065qlwcpqngix97	2	2025-10-16 23:44:09.53	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gny400ilqlwchugmsquk	Following this thread. Great discussion!	2025-08-04 12:19:00.913	\N	\N	cmgu2gng50065qlwcpqngix97	44	2025-10-16 23:44:09.532	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gny600inqlwc5k0bmtju	Interesting perspective. I never thought about it that way.	2025-07-08 15:10:22.428	\N	\N	cmgu2gng50065qlwcpqngix97	30	2025-10-16 23:44:09.535	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gny900ipqlwc0exxrlie	Great post! Really helpful information.	2025-06-20 21:02:54.904	\N	\N	cmgu2gng50065qlwcpqngix97	58	2025-10-16 23:44:09.537	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gnyb00irqlwc7d7l2fgg	Thanks for posting this! Very informative.	2025-04-05 03:14:11.009	\N	\N	cmgu2gng50065qlwcpqngix97	25	2025-10-16 23:44:09.539	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnyd00itqlwcyc89wrk4	I disagree, but I respect your opinion.	2025-08-16 20:11:32.638	\N	\N	cmgu2gng50065qlwcpqngix97	24	2025-10-16 23:44:09.542	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnyi00ivqlwcfv9jxesy	Can confirm, this is accurate.	2025-10-02 00:34:52.066	\N	\N	cmgu2gng80067qlwcmv5r819x	62	2025-10-16 23:44:09.547	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gnyl00ixqlwcj8o8hvpc	Cohors adicio antepono voluptate repellendus tamdiu molestiae cibo laborum. Color reprehenderit virtus cibo accusantium magni. Argentum suffragium fugiat textus vulticulus thorax.	2025-10-07 08:48:11.45	\N	\N	cmgu2gng80067qlwcmv5r819x	20	2025-10-16 23:44:09.549	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gnyn00izqlwcxo096cdw	Following this thread. Great discussion!	2025-10-10 19:13:51.19	\N	\N	cmgu2gng80067qlwcmv5r819x	28	2025-10-16 23:44:09.551	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnyr00j1qlwck2wcr40e	Interesting perspective. I never thought about it that way.	2025-09-30 18:11:02.683	\N	\N	cmgu2gng80067qlwcmv5r819x	47	2025-10-16 23:44:09.555	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gnyw00j3qlwc0q1c85fd	This deserves more upvotes!	2025-10-10 22:16:31.071	\N	\N	cmgu2gng80067qlwcmv5r819x	63	2025-10-16 23:44:09.56	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnyz00j5qlwc8p2jhta1	Thanks for posting this! Very informative.	2025-10-06 01:53:12.191	\N	\N	cmgu2gng80067qlwcmv5r819x	53	2025-10-16 23:44:09.563	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gnz200j7qlwc3p2vpe6j	Thanks for posting this! Very informative.	2025-09-24 06:11:22.598	\N	\N	cmgu2gng80067qlwcmv5r819x	11	2025-10-16 23:44:09.566	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gnz400j9qlwcfakk4tof	Update: I tried this and it worked perfectly!	2025-10-10 18:55:52.725	\N	\N	cmgu2gng80067qlwcmv5r819x	63	2025-10-16 23:44:09.569	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gnz700jbqlwcizu0rga6	This is a game changer. Thank you!	2025-09-27 05:02:08.094	\N	\N	cmgu2gng80067qlwcmv5r819x	54	2025-10-16 23:44:09.571	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gnze00jdqlwcqzv97x2o	This deserves more upvotes!	2025-09-10 07:10:23.065	\N	\N	cmgu2gnga0069qlwcv0z1ejjv	-3	2025-10-16 23:44:09.579	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gnzu00jnqlwci3tldh7q	This is a game changer. Thank you!	2025-10-11 20:54:03.754	\N	\N	cmgu2gngd006bqlwczd46xwge	11	2025-10-16 23:44:09.595	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gnzy00jpqlwcy3989nk1	I had the same experience! Thanks for sharing.	2025-10-14 03:55:53.102	\N	\N	cmgu2gngd006bqlwczd46xwge	20	2025-10-16 23:44:09.598	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2go0100jrqlwc9drbibm4	I had the same experience! Thanks for sharing.	2025-10-08 20:11:02.765	\N	\N	cmgu2gngd006bqlwczd46xwge	22	2025-10-16 23:44:09.601	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2go0300jtqlwclde3w484	I've been doing this for years and can vouch for it.	2025-10-09 13:07:08.41	\N	\N	cmgu2gngd006bqlwczd46xwge	20	2025-10-16 23:44:09.604	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2go0600jvqlwczwjh7mqk	This is exactly what I needed. Saved!	2025-10-12 03:56:55.829	\N	\N	cmgu2gngd006bqlwczd46xwge	-4	2025-10-16 23:44:09.607	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2go0900jxqlwcb4uj9s69	I had the same experience! Thanks for sharing.	2025-10-09 02:42:37.411	\N	\N	cmgu2gngd006bqlwczd46xwge	69	2025-10-16 23:44:09.609	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2go0c00jzqlwcv69jaxzh	Could you elaborate more on this point?	2025-10-12 16:30:02.838	\N	\N	cmgu2gngd006bqlwczd46xwge	-5	2025-10-16 23:44:09.612	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2go0g00k1qlwcxqarbsql	This is exactly what I needed. Saved!	2025-10-10 05:09:01.6	\N	\N	cmgu2gngd006bqlwczd46xwge	41	2025-10-16 23:44:09.617	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2go0j00k3qlwc09in6e5v	This deserves more upvotes!	2025-10-10 17:29:37.635	\N	\N	cmgu2gngd006bqlwczd46xwge	76	2025-10-16 23:44:09.62	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2go0p00k5qlwcahvqbkx9	Great post! Really helpful information.	2025-08-15 18:13:15.209	\N	\N	cmgu2gngg006dqlwcw0pinl5l	90	2025-10-16 23:44:09.625	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2go0s00k7qlwcaagms15t	Following this thread. Great discussion!	2025-08-09 23:38:33.643	\N	\N	cmgu2gngg006dqlwcw0pinl5l	27	2025-10-16 23:44:09.628	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnzh00jfqlwci1zr28kk	This is a game changer. Thank you!	2025-05-10 13:58:30.794	\N	\N	cmgu2gnga0069qlwcv0z1ejjv	53	2025-10-16 23:44:09.581	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gnzj00jhqlwcs5lf1ma0	I've been doing this for years and can vouch for it.	2025-04-13 00:26:36.69	\N	\N	cmgu2gnga0069qlwcv0z1ejjv	63	2025-10-16 23:44:09.584	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnzm00jjqlwcminc9s9y	Bookmarking this for later. Excellent content!	2025-08-20 07:59:39.546	\N	\N	cmgu2gnga0069qlwcv0z1ejjv	94	2025-10-16 23:44:09.586	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gnzp00jlqlwc2r4p87zq	This deserves more upvotes!	2025-09-21 19:48:41.869	\N	\N	cmgu2gnga0069qlwcv0z1ejjv	75	2025-10-16 23:44:09.589	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2go1h00knqlwccng7tc36	I've been doing this for years and can vouch for it.	2025-10-01 16:04:00.946	\N	\N	cmgu2gngj006fqlwc20qp2d27	49	2025-10-16 23:44:09.653	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2go1k00kpqlwc2enpv8rx	This deserves more upvotes!	2025-09-13 08:28:46.837	\N	\N	cmgu2gngj006fqlwc20qp2d27	56	2025-10-16 23:44:09.657	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2go1n00krqlwcurmmrw0d	I had the same experience! Thanks for sharing.	2025-10-11 01:14:41.297	\N	\N	cmgu2gngj006fqlwc20qp2d27	83	2025-10-16 23:44:09.66	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2go1q00ktqlwc4gg756ku	Bookmarking this for later. Excellent content!	2025-10-06 04:01:03.864	\N	\N	cmgu2gngj006fqlwc20qp2d27	63	2025-10-16 23:44:09.662	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2go1y00kvqlwccsl7tixm	Tui verus aspicio. Apud varius statim beatus clamo pax somniculosus architecto. Confero ubi comburo speculum tunc tenetur custodia.	2025-06-24 03:32:28.619	\N	\N	cmgu2gngm006hqlwcwtj3886t	25	2025-10-16 23:44:09.67	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2go2100kxqlwc7m67eb4q	Absconditus ascisco summisse asporto claustrum substantia. Alius votum collum adsidue defaeco facilis depereo clam aut amet. Corrupti confido convoco at comptus auctus alii casus solitudo.	2025-08-13 08:28:44.204	\N	\N	cmgu2gngm006hqlwcwtj3886t	67	2025-10-16 23:44:09.673	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2go2z00ldqlwcie6kwm6l	Update: I tried this and it worked perfectly!	2025-07-06 03:37:50.461	\N	\N	cmgu2gngp006jqlwce38mhknu	64	2025-10-16 23:44:09.708	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2go3200lfqlwc28gxsa8a	Great post! Really helpful information.	2025-03-15 21:10:28.957	\N	\N	cmgu2gngp006jqlwce38mhknu	73	2025-10-16 23:44:09.711	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2go3500lhqlwc101g0bdb	This deserves more upvotes!	2025-04-27 05:10:43.018	\N	\N	cmgu2gngp006jqlwce38mhknu	2	2025-10-16 23:44:09.713	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2go3700ljqlwcn1z1u3bp	Thanks for posting this! Very informative.	2025-08-22 04:07:53.595	\N	\N	cmgu2gngp006jqlwce38mhknu	1	2025-10-16 23:44:09.716	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2go3900llqlwczjbq2zyg	This deserves more upvotes!	2025-04-01 04:50:54.165	\N	\N	cmgu2gngp006jqlwce38mhknu	36	2025-10-16 23:44:09.718	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2go3c00lnqlwckqi06vra	Interesting perspective. I never thought about it that way.	2025-03-17 07:34:03.551	\N	\N	cmgu2gngp006jqlwce38mhknu	30	2025-10-16 23:44:09.72	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2go3g00lpqlwcur0n2rag	This is a game changer. Thank you!	2025-02-08 16:04:58.482	\N	\N	cmgu2gngs006lqlwcbc0g2wlw	75	2025-10-16 23:44:09.725	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2go3j00lrqlwcgapnd2bk	Can confirm, this is accurate.	2025-02-13 02:01:24.895	\N	\N	cmgu2gngs006lqlwcbc0g2wlw	54	2025-10-16 23:44:09.727	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2go3l00ltqlwcxnhwdwqw	This is exactly what I needed. Saved!	2025-03-22 11:51:23.038	\N	\N	cmgu2gngs006lqlwcbc0g2wlw	-2	2025-10-16 23:44:09.73	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2go3o00lvqlwcyrvq073x	Bookmarking this for later. Excellent content!	2025-01-01 11:14:02.363	\N	\N	cmgu2gngs006lqlwcbc0g2wlw	86	2025-10-16 23:44:09.732	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gobi00r3qlwcyqrvyu2z	What resources would you recommend for learning more?	2025-07-05 23:45:49.113	\N	\N	cmgu2gnhq007bqlwcxm79p2ok	97	2025-10-16 23:44:10.014	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gobl00r5qlwcf2baszeg	Interesting perspective. I never thought about it that way.	2025-08-05 09:59:30.41	\N	\N	cmgu2gnhq007bqlwcxm79p2ok	54	2025-10-16 23:44:10.017	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gobq00r7qlwci21gvg1w	This is exactly what I needed. Saved!	2025-03-12 03:12:54.236	\N	\N	cmgu2gnhs007dqlwc57g66cur	1	2025-10-16 23:44:10.022	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gobs00r9qlwckgaekyih	I've been doing this for years and can vouch for it.	2025-04-30 18:40:58.77	\N	\N	cmgu2gnhs007dqlwc57g66cur	90	2025-10-16 23:44:10.025	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gobv00rbqlwccceth873	Bookmarking this for later. Excellent content!	2025-02-25 18:39:33.513	\N	\N	cmgu2gnhs007dqlwc57g66cur	98	2025-10-16 23:44:10.027	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gobx00rdqlwczmdc0vee	Great post! Really helpful information.	2025-08-31 09:17:57.181	\N	\N	cmgu2gnhs007dqlwc57g66cur	53	2025-10-16 23:44:10.029	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gobz00rfqlwc4i0w3jmq	This deserves more upvotes!	2025-08-28 00:01:24.562	\N	\N	cmgu2gnhs007dqlwc57g66cur	55	2025-10-16 23:44:10.031	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2goc400rhqlwclyv3cfpk	Bookmarking this for later. Excellent content!	2025-02-12 01:32:43.159	\N	\N	cmgu2gnhv007fqlwcof2gdbb4	19	2025-10-16 23:44:10.036	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2goc600rjqlwc7eoyd1en	Can confirm, this is accurate.	2025-07-25 19:14:19.968	\N	\N	cmgu2gnhv007fqlwcof2gdbb4	11	2025-10-16 23:44:10.038	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2goc900rlqlwcvsez5vr4	Can confirm, this is accurate.	2025-01-12 00:20:10.215	\N	\N	cmgu2gnhv007fqlwcof2gdbb4	54	2025-10-16 23:44:10.041	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gocb00rnqlwc6mhmgfpi	Bookmarking this for later. Excellent content!	2025-04-22 16:17:04.838	\N	\N	cmgu2gnhv007fqlwcof2gdbb4	-3	2025-10-16 23:44:10.043	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gocd00rpqlwcrqj3sbiw	Bookmarking this for later. Excellent content!	2024-12-31 21:25:42.048	\N	\N	cmgu2gnhv007fqlwcof2gdbb4	46	2025-10-16 23:44:10.046	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2goch00rrqlwcqsuf4uw2	Following this thread. Great discussion!	2025-09-11 05:43:06.255	\N	\N	cmgu2gnhv007fqlwcof2gdbb4	80	2025-10-16 23:44:10.05	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gocj00rtqlwcddap8pj6	This is exactly what I needed. Saved!	2025-05-24 22:41:28.426	\N	\N	cmgu2gnhv007fqlwcof2gdbb4	4	2025-10-16 23:44:10.052	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gocm00rvqlwcfhwj9866	I've been doing this for years and can vouch for it.	2025-03-21 18:56:44.789	\N	\N	cmgu2gnhv007fqlwcof2gdbb4	56	2025-10-16 23:44:10.054	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2goco00rxqlwcnpt209vc	Thanks for posting this! Very informative.	2025-08-22 03:46:00.586	\N	\N	cmgu2gnhv007fqlwcof2gdbb4	61	2025-10-16 23:44:10.056	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gocq00rzqlwc5w3mofv2	Can confirm, this is accurate.	2025-03-03 12:00:19.619	\N	\N	cmgu2gnhv007fqlwcof2gdbb4	39	2025-10-16 23:44:10.059	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gocv00s1qlwciwl03k53	This is exactly what I needed. Saved!	2025-07-26 17:00:20.212	\N	\N	cmgu2gnhy007hqlwcoyumsrpn	88	2025-10-16 23:44:10.064	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gocx00s3qlwc5kxzzbag	Thanks for posting this! Very informative.	2025-09-30 10:09:26.197	\N	\N	cmgu2gnhy007hqlwcoyumsrpn	31	2025-10-16 23:44:10.066	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2god000s5qlwcwtubh2zl	What resources would you recommend for learning more?	2025-08-09 05:01:07.889	\N	\N	cmgu2gnhy007hqlwcoyumsrpn	53	2025-10-16 23:44:10.068	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2god200s7qlwc19ntnr9f	This is exactly what I needed. Saved!	2025-10-14 11:19:35.976	\N	\N	cmgu2gnhy007hqlwcoyumsrpn	33	2025-10-16 23:44:10.07	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2god400s9qlwccxjabtw8	Update: I tried this and it worked perfectly!	2025-10-12 11:20:43.035	\N	\N	cmgu2gnhy007hqlwcoyumsrpn	36	2025-10-16 23:44:10.073	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2go0u00k9qlwc5gugnh3y	This deserves more upvotes!	2025-07-16 01:08:33.185	\N	\N	cmgu2gngg006dqlwcw0pinl5l	-3	2025-10-16 23:44:09.631	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2go0x00kbqlwc93qxfkq3	Update: I tried this and it worked perfectly!	2025-10-11 22:44:42.797	\N	\N	cmgu2gngg006dqlwcw0pinl5l	92	2025-10-16 23:44:09.633	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2go1100kdqlwcswz86apl	Bookmarking this for later. Excellent content!	2025-05-29 21:02:25.397	\N	\N	cmgu2gngg006dqlwcw0pinl5l	52	2025-10-16 23:44:09.637	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2go1400kfqlwcqyw70tkj	This deserves more upvotes!	2025-07-25 21:50:58.002	\N	\N	cmgu2gngg006dqlwcw0pinl5l	61	2025-10-16 23:44:09.64	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2go1600khqlwcd9aeo09a	I've been doing this for years and can vouch for it.	2025-06-18 05:45:34.292	\N	\N	cmgu2gngg006dqlwcw0pinl5l	27	2025-10-16 23:44:09.643	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2go1c00kjqlwczvo9oym9	Update: I tried this and it worked perfectly!	2025-09-14 10:41:11.559	\N	\N	cmgu2gngj006fqlwc20qp2d27	67	2025-10-16 23:44:09.648	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2go1e00klqlwcqhimhzzq	This is exactly what I needed. Saved!	2025-09-27 22:30:50.103	\N	\N	cmgu2gngj006fqlwc20qp2d27	1	2025-10-16 23:44:09.651	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2go2600kzqlwcbuxln8cu	This deserves more upvotes!	2025-09-14 12:13:35.364	\N	\N	cmgu2gngm006hqlwcwtj3886t	62	2025-10-16 23:44:09.678	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2go2a00l1qlwcr33ewj8n	Great post! Really helpful information.	2025-07-18 18:41:43	\N	\N	cmgu2gngm006hqlwcwtj3886t	1	2025-10-16 23:44:09.683	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2go2h00l3qlwczqd4rxez	This is a game changer. Thank you!	2025-05-22 04:17:47.813	\N	\N	cmgu2gngm006hqlwcwtj3886t	-3	2025-10-16 23:44:09.689	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2go2k00l5qlwc4lb1lx77	Can confirm, this is accurate.	2025-05-14 10:26:46.903	\N	\N	cmgu2gngm006hqlwcwtj3886t	-2	2025-10-16 23:44:09.692	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2go2n00l7qlwct7r4jg4m	Abstergo amet coepi teneo pectus. Vado advoco delicate. Cresco thesaurus depopulo consequuntur conturbo coruscus sophismata voluntarius balbus.	2025-09-22 18:42:58.375	\N	\N	cmgu2gngm006hqlwcwtj3886t	55	2025-10-16 23:44:09.696	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2go2r00l9qlwcnvh3bdor	Could you elaborate more on this point?	2025-10-04 17:38:38.775	\N	\N	cmgu2gngm006hqlwcwtj3886t	22	2025-10-16 23:44:09.699	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2go2u00lbqlwcccvvfgro	Update: I tried this and it worked perfectly!	2025-06-19 22:34:03.724	\N	\N	cmgu2gngm006hqlwcwtj3886t	-5	2025-10-16 23:44:09.702	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2go3q00lxqlwc8bdj5q6f	Calco curatio ascisco cedo cumque calamitas cavus circumvenio culpa trado. Voluptate centum video consuasor. Ciminatio avarus at desino abeo enim valde aequus tenax.	2025-07-25 20:44:25.785	\N	\N	cmgu2gngs006lqlwcbc0g2wlw	98	2025-10-16 23:44:09.735	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2go3t00lzqlwccpd389rr	I've been doing this for years and can vouch for it.	2025-04-21 11:46:54.036	\N	\N	cmgu2gngs006lqlwcbc0g2wlw	71	2025-10-16 23:44:09.737	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2go3v00m1qlwc0hpb6egc	Interesting perspective. I never thought about it that way.	2025-02-02 08:11:58.698	\N	\N	cmgu2gngs006lqlwcbc0g2wlw	-1	2025-10-16 23:44:09.74	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2go4000m3qlwcupgjlkam	This deserves more upvotes!	2025-09-22 09:41:20.325	\N	\N	cmgu2gngu006nqlwcot6ujewu	55	2025-10-16 23:44:09.745	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2go4300m5qlwcub74raye	Could you elaborate more on this point?	2025-10-07 13:44:21.462	\N	\N	cmgu2gngu006nqlwcot6ujewu	54	2025-10-16 23:44:09.747	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2go4500m7qlwci51s6e3w	I disagree, but I respect your opinion.	2025-10-04 12:01:45.615	\N	\N	cmgu2gngu006nqlwcot6ujewu	75	2025-10-16 23:44:09.749	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2go4700m9qlwc8i629mqt	This is a game changer. Thank you!	2025-10-10 07:44:56.934	\N	\N	cmgu2gngu006nqlwcot6ujewu	32	2025-10-16 23:44:09.752	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2go4a00mbqlwck67g77ei	Could you elaborate more on this point?	2025-09-29 04:43:32.64	\N	\N	cmgu2gngu006nqlwcot6ujewu	47	2025-10-16 23:44:09.754	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2go4c00mdqlwc11bs52w9	I disagree, but I respect your opinion.	2025-10-09 14:55:08.466	\N	\N	cmgu2gngu006nqlwcot6ujewu	93	2025-10-16 23:44:09.757	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2go4h00mfqlwcwd3ds3or	I've been doing this for years and can vouch for it.	2025-10-06 13:30:06.809	\N	\N	cmgu2gngx006pqlwc65h899fc	58	2025-10-16 23:44:09.762	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2go4k00mhqlwcrjczpakt	Thanks for posting this! Very informative.	2025-10-14 04:16:50.059	\N	\N	cmgu2gngx006pqlwc65h899fc	85	2025-10-16 23:44:09.764	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2go4m00mjqlwcrvwkz24f	This deserves more upvotes!	2025-10-04 18:01:54.42	\N	\N	cmgu2gngx006pqlwc65h899fc	98	2025-10-16 23:44:09.767	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2go4p00mlqlwcsty7x12s	I disagree, but I respect your opinion.	2025-10-06 18:56:14.47	\N	\N	cmgu2gngx006pqlwc65h899fc	43	2025-10-16 23:44:09.769	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2go4s00mnqlwcwrzg45hk	This deserves more upvotes!	2025-10-09 15:45:55.054	\N	\N	cmgu2gngx006pqlwc65h899fc	17	2025-10-16 23:44:09.773	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2go4w00mpqlwcf1uvrsy2	I had the same experience! Thanks for sharing.	2025-10-10 19:08:14.736	\N	\N	cmgu2gngx006pqlwc65h899fc	45	2025-10-16 23:44:09.776	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2go4y00mrqlwcw1oc5tje	I've been doing this for years and can vouch for it.	2025-10-14 08:38:21.293	\N	\N	cmgu2gngx006pqlwc65h899fc	84	2025-10-16 23:44:09.779	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2go5100mtqlwcbdsd29kw	I disagree, but I respect your opinion.	2025-10-05 18:48:55.099	\N	\N	cmgu2gngx006pqlwc65h899fc	22	2025-10-16 23:44:09.781	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2go5300mvqlwc7pmizqvc	What resources would you recommend for learning more?	2025-10-06 17:05:33.137	\N	\N	cmgu2gngx006pqlwc65h899fc	-4	2025-10-16 23:44:09.784	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2go5800mxqlwcliy0j1sh	This deserves more upvotes!	2025-09-25 02:44:04.545	\N	\N	cmgu2gngz006rqlwckw33v4ks	13	2025-10-16 23:44:09.788	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2go5b00mzqlwc9uk4exfw	Can confirm, this is accurate.	2025-10-12 23:34:07.272	\N	\N	cmgu2gngz006rqlwckw33v4ks	88	2025-10-16 23:44:09.791	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2go5e00n1qlwc52foe474	Bookmarking this for later. Excellent content!	2025-08-26 06:08:55.542	\N	\N	cmgu2gngz006rqlwckw33v4ks	13	2025-10-16 23:44:09.794	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2go5g00n3qlwcsc2cpm12	I've been doing this for years and can vouch for it.	2025-09-11 13:39:31.517	\N	\N	cmgu2gngz006rqlwckw33v4ks	81	2025-10-16 23:44:09.796	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2go5i00n5qlwcco3lxi5o	I disagree, but I respect your opinion.	2025-09-19 16:18:17.879	\N	\N	cmgu2gngz006rqlwckw33v4ks	50	2025-10-16 23:44:09.798	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2go5k00n7qlwc7e26ydgl	This is exactly what I needed. Saved!	2025-09-16 00:03:42.396	\N	\N	cmgu2gngz006rqlwckw33v4ks	66	2025-10-16 23:44:09.801	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2go5n00n9qlwckne5q7lc	I had the same experience! Thanks for sharing.	2025-09-19 11:53:27.914	\N	\N	cmgu2gngz006rqlwckw33v4ks	43	2025-10-16 23:44:09.803	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2go5p00nbqlwcsvia9y3d	This deserves more upvotes!	2025-08-30 12:01:10.434	\N	\N	cmgu2gngz006rqlwckw33v4ks	47	2025-10-16 23:44:09.805	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2go5u00ndqlwcjajd2r5n	Virtus annus cui turpis cui. Auctus tamen crastinus patruus sublime illo combibo. Varietas tepesco defaeco ipsum.	2025-10-05 04:22:32.98	\N	\N	cmgu2gnh3006tqlwctujwg677	57	2025-10-16 23:44:09.81	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2go5w00nfqlwc0ms1yjc8	This deserves more upvotes!	2025-09-27 20:01:19.634	\N	\N	cmgu2gnh3006tqlwctujwg677	64	2025-10-16 23:44:09.812	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2go6100nhqlwcx36qoy2s	This is a game changer. Thank you!	2025-09-28 02:05:37.482	\N	\N	cmgu2gnh3006tqlwctujwg677	85	2025-10-16 23:44:09.817	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2go6300njqlwc0a7t7051	Following this thread. Great discussion!	2025-09-30 05:08:52.426	\N	\N	cmgu2gnh3006tqlwctujwg677	100	2025-10-16 23:44:09.82	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2go6800nlqlwcujxdysw8	Dapifer crapula calamitas benigne optio curriculum coniecto cubicularis desolo crebro. Valetudo suppono uter pecto aspicio acer arcus ocer. Communis cupio cilicium.	2025-09-29 21:25:55.187	\N	\N	cmgu2gnh3006tqlwctujwg677	67	2025-10-16 23:44:09.824	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2go6e00nnqlwc5krzjilw	Thanks for posting this! Very informative.	2025-09-22 09:20:21.233	\N	\N	cmgu2gnh3006tqlwctujwg677	2	2025-10-16 23:44:09.83	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2go6h00npqlwch54q6zvm	I disagree, but I respect your opinion.	2025-09-18 15:08:20.018	\N	\N	cmgu2gnh3006tqlwctujwg677	2	2025-10-16 23:44:09.833	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2go6j00nrqlwccujajaji	Update: I tried this and it worked perfectly!	2025-09-13 23:03:31.364	\N	\N	cmgu2gnh3006tqlwctujwg677	75	2025-10-16 23:44:09.836	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2go6m00ntqlwclywyez6u	Update: I tried this and it worked perfectly!	2025-09-28 01:32:08.498	\N	\N	cmgu2gnh3006tqlwctujwg677	0	2025-10-16 23:44:09.838	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2go6p00nvqlwcz5jr10gm	Thanks for posting this! Very informative.	2025-09-24 07:17:52.603	\N	\N	cmgu2gnh3006tqlwctujwg677	28	2025-10-16 23:44:09.841	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2go6u00nxqlwcedk76n3n	What resources would you recommend for learning more?	2025-06-07 22:55:01.794	\N	\N	cmgu2gnh5006vqlwcjzjtpsba	14	2025-10-16 23:44:09.846	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2go6x00nzqlwc30goyfcm	Could you elaborate more on this point?	2025-09-27 07:42:51.869	\N	\N	cmgu2gnh5006vqlwcjzjtpsba	49	2025-10-16 23:44:09.849	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2go7000o1qlwct3vvgzdy	Great post! Really helpful information.	2025-09-05 19:11:43.242	\N	\N	cmgu2gnh5006vqlwcjzjtpsba	69	2025-10-16 23:44:09.852	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2go7200o3qlwcieojdafl	Bookmarking this for later. Excellent content!	2025-05-08 11:13:55.482	\N	\N	cmgu2gnh5006vqlwcjzjtpsba	42	2025-10-16 23:44:09.854	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2go7500o5qlwcco1uoct5	Could you elaborate more on this point?	2025-10-03 05:36:50.398	\N	\N	cmgu2gnh5006vqlwcjzjtpsba	1	2025-10-16 23:44:09.857	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2go7a00o7qlwcrajrztlw	Bookmarking this for later. Excellent content!	2025-06-16 05:43:07.205	\N	\N	cmgu2gnh5006vqlwcjzjtpsba	37	2025-10-16 23:44:09.862	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2go7d00o9qlwcehqh0wgj	I disagree, but I respect your opinion.	2025-09-17 14:56:32.325	\N	\N	cmgu2gnh5006vqlwcjzjtpsba	54	2025-10-16 23:44:09.865	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2go7f00obqlwckxjzgszg	I've been doing this for years and can vouch for it.	2025-05-26 03:11:07.846	\N	\N	cmgu2gnh5006vqlwcjzjtpsba	44	2025-10-16 23:44:09.868	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2go7l00odqlwco0qjs6rf	Could you elaborate more on this point?	2025-04-08 08:12:56.778	\N	\N	cmgu2gnh8006xqlwcn5qke237	33	2025-10-16 23:44:09.874	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2go7o00ofqlwct9n1riw2	Following this thread. Great discussion!	2025-05-10 02:07:01.993	\N	\N	cmgu2gnh8006xqlwcn5qke237	7	2025-10-16 23:44:09.876	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2go7q00ohqlwcooslgq2h	I've been doing this for years and can vouch for it.	2025-07-19 01:52:19.473	\N	\N	cmgu2gnh8006xqlwcn5qke237	94	2025-10-16 23:44:09.878	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2go7s00ojqlwcip5uzszl	This is a game changer. Thank you!	2025-05-17 11:02:49.044	\N	\N	cmgu2gnh8006xqlwcn5qke237	38	2025-10-16 23:44:09.881	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2go7v00olqlwcmu5ck13z	Thanks for posting this! Very informative.	2025-10-13 23:51:53.884	\N	\N	cmgu2gnh8006xqlwcn5qke237	27	2025-10-16 23:44:09.883	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2go7x00onqlwc7hxgkmvt	Could you elaborate more on this point?	2025-05-27 00:19:51.403	\N	\N	cmgu2gnh8006xqlwcn5qke237	6	2025-10-16 23:44:09.885	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2go7z00opqlwc3zrvbg31	Great post! Really helpful information.	2025-07-01 18:10:54.693	\N	\N	cmgu2gnh8006xqlwcn5qke237	62	2025-10-16 23:44:09.888	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2go8200orqlwc8qyevgka	This is a game changer. Thank you!	2025-06-07 03:03:42.091	\N	\N	cmgu2gnh8006xqlwcn5qke237	63	2025-10-16 23:44:09.89	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2go8700otqlwct5j33j6p	Could you elaborate more on this point?	2025-10-10 02:26:49.497	\N	\N	cmgu2gnha006zqlwccxtsawgd	23	2025-10-16 23:44:09.895	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2go8900ovqlwcruq3jert	Bookmarking this for later. Excellent content!	2025-10-10 10:36:52.553	\N	\N	cmgu2gnha006zqlwccxtsawgd	46	2025-10-16 23:44:09.898	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2go8c00oxqlwcrtphk3e7	I've been doing this for years and can vouch for it.	2025-10-02 02:59:03.218	\N	\N	cmgu2gnha006zqlwccxtsawgd	67	2025-10-16 23:44:09.9	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2go8e00ozqlwcr225e5dw	I've been doing this for years and can vouch for it.	2025-08-19 10:57:34.572	\N	\N	cmgu2gnha006zqlwccxtsawgd	31	2025-10-16 23:44:09.902	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2go8g00p1qlwcjtau81br	I disagree, but I respect your opinion.	2025-09-05 14:29:52.639	\N	\N	cmgu2gnha006zqlwccxtsawgd	64	2025-10-16 23:44:09.904	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2go8j00p3qlwc04mz4p8i	Bookmarking this for later. Excellent content!	2025-09-02 15:13:49.747	\N	\N	cmgu2gnha006zqlwccxtsawgd	76	2025-10-16 23:44:09.907	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2go8m00p5qlwcixyftd6h	This is a game changer. Thank you!	2025-08-28 14:45:38.536	\N	\N	cmgu2gnha006zqlwccxtsawgd	5	2025-10-16 23:44:09.91	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2go8s00p7qlwcz6u562ye	This is a game changer. Thank you!	2025-09-17 23:59:20.08	\N	\N	cmgu2gnhd0071qlwc97sfr00k	64	2025-10-16 23:44:09.916	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2go8v00p9qlwc38z0i9kl	This is exactly what I needed. Saved!	2025-08-14 12:42:59.402	\N	\N	cmgu2gnhd0071qlwc97sfr00k	28	2025-10-16 23:44:09.919	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2go8x00pbqlwc3axmvy3m	Carbo conitor adulatio cerno capio arbustum vulpes vulnus usque adfero. Creber tunc colo videlicet blanditiis. Totam charisma eos eum vehemens.	2025-05-02 22:32:36.967	\N	\N	cmgu2gnhd0071qlwc97sfr00k	100	2025-10-16 23:44:09.922	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2go8z00pdqlwcyu87k8f2	Update: I tried this and it worked perfectly!	2025-06-15 05:30:24.817	\N	\N	cmgu2gnhd0071qlwc97sfr00k	74	2025-10-16 23:44:09.924	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2go9200pfqlwczgymq5up	Update: I tried this and it worked perfectly!	2025-04-27 23:07:38.498	\N	\N	cmgu2gnhd0071qlwc97sfr00k	22	2025-10-16 23:44:09.926	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2go9600phqlwccsr1xmc5	Interesting perspective. I never thought about it that way.	2025-05-04 01:01:18.734	\N	\N	cmgu2gnhf0073qlwcwuulorou	82	2025-10-16 23:44:09.931	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2go9900pjqlwc8uqb3r9t	I disagree, but I respect your opinion.	2025-06-12 15:30:57.702	\N	\N	cmgu2gnhf0073qlwcwuulorou	55	2025-10-16 23:44:09.933	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2go9b00plqlwcbt5sc6p8	Could you elaborate more on this point?	2025-06-09 06:53:46.508	\N	\N	cmgu2gnhf0073qlwcwuulorou	94	2025-10-16 23:44:09.935	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2go9e00pnqlwc3svnsn2s	Acerbitas decumbo ut vacuus demo. Magnam deduco sopor. Vulnero amaritudo turba strenuus demum.	2024-12-21 19:53:10.461	\N	\N	cmgu2gnhf0073qlwcwuulorou	43	2025-10-16 23:44:09.938	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2go9g00ppqlwch46sz885	I had the same experience! Thanks for sharing.	2025-04-13 22:57:59.54	\N	\N	cmgu2gnhf0073qlwcwuulorou	63	2025-10-16 23:44:09.94	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2go9j00prqlwc4t162hmz	Can confirm, this is accurate.	2024-12-26 09:53:05.979	\N	\N	cmgu2gnhf0073qlwcwuulorou	79	2025-10-16 23:44:09.943	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2go9n00ptqlwclcwbvaje	What resources would you recommend for learning more?	2025-05-06 01:29:31.608	\N	\N	cmgu2gnhh0075qlwc1j0bigi1	63	2025-10-16 23:44:09.948	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2go9q00pvqlwcotvx23ws	What resources would you recommend for learning more?	2025-06-26 07:13:14.028	\N	\N	cmgu2gnhh0075qlwc1j0bigi1	68	2025-10-16 23:44:09.95	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2go9s00pxqlwcdvbcgam4	Can confirm, this is accurate.	2025-07-15 22:57:23.267	\N	\N	cmgu2gnhh0075qlwc1j0bigi1	44	2025-10-16 23:44:09.952	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2go9v00pzqlwcvs8q17ml	Update: I tried this and it worked perfectly!	2025-05-16 19:07:17.847	\N	\N	cmgu2gnhh0075qlwc1j0bigi1	41	2025-10-16 23:44:09.956	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2go9y00q1qlwcohzntvsd	Could you elaborate more on this point?	2025-07-26 17:34:38.882	\N	\N	cmgu2gnhh0075qlwc1j0bigi1	69	2025-10-16 23:44:09.958	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2goa000q3qlwcxn1a9rvf	This deserves more upvotes!	2025-01-31 15:02:35.811	\N	\N	cmgu2gnhh0075qlwc1j0bigi1	75	2025-10-16 23:44:09.96	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2goa200q5qlwcns2bgijp	Great post! Really helpful information.	2025-03-15 23:26:45.177	\N	\N	cmgu2gnhh0075qlwc1j0bigi1	25	2025-10-16 23:44:09.962	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2goa400q7qlwcli6uebpw	This is exactly what I needed. Saved!	2025-10-01 00:04:37.555	\N	\N	cmgu2gnhh0075qlwc1j0bigi1	8	2025-10-16 23:44:09.965	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2goaa00q9qlwcwcxh22j9	What resources would you recommend for learning more?	2025-06-20 19:27:03.763	\N	\N	cmgu2gnhk0077qlwcda2i0b26	28	2025-10-16 23:44:09.97	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2goac00qbqlwcrrw9j1d0	This is a game changer. Thank you!	2025-10-08 06:29:04.575	\N	\N	cmgu2gnhk0077qlwcda2i0b26	83	2025-10-16 23:44:09.972	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2goae00qdqlwco3ikn187	Thanks for posting this! Very informative.	2025-09-01 08:43:37.847	\N	\N	cmgu2gnhk0077qlwcda2i0b26	88	2025-10-16 23:44:09.974	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2goag00qfqlwcmi0ttiuw	Bookmarking this for later. Excellent content!	2025-08-04 08:41:29.076	\N	\N	cmgu2gnhk0077qlwcda2i0b26	93	2025-10-16 23:44:09.977	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2goaj00qhqlwc6gmkpbqc	Solium subseco rerum summisse terreo constans aiunt bibo. Aptus theatrum urbanus coruscus tabesco. Similique comes dicta verbum velit ulterius.	2025-06-09 03:29:09.243	\N	\N	cmgu2gnhk0077qlwcda2i0b26	82	2025-10-16 23:44:09.979	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2goan00qjqlwcy5ap4zka	Could you elaborate more on this point?	2025-07-29 23:01:22.619	\N	\N	cmgu2gnhn0079qlwcpw5y5ivj	62	2025-10-16 23:44:09.984	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2goaq00qlqlwc7kpd93ir	This is a game changer. Thank you!	2025-10-12 13:29:49.732	\N	\N	cmgu2gnhn0079qlwcpw5y5ivj	12	2025-10-16 23:44:09.986	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2goas00qnqlwc22zyakfh	I disagree, but I respect your opinion.	2025-07-16 11:20:20.163	\N	\N	cmgu2gnhn0079qlwcpw5y5ivj	12	2025-10-16 23:44:09.989	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2goau00qpqlwczvupm5il	I had the same experience! Thanks for sharing.	2025-10-07 09:19:21.183	\N	\N	cmgu2gnhn0079qlwcpw5y5ivj	86	2025-10-16 23:44:09.991	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2goax00qrqlwc9ou27d4y	What resources would you recommend for learning more?	2025-07-12 11:42:20.098	\N	\N	cmgu2gnhn0079qlwcpw5y5ivj	1	2025-10-16 23:44:09.994	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gob000qtqlwc88uwlpb5	Tollo vulnus rem averto quibusdam sequi strues. Crepusculum accommodo certe. Tunc sublime curriculum tenus.	2025-05-16 15:33:22.648	\N	\N	cmgu2gnhn0079qlwcpw5y5ivj	24	2025-10-16 23:44:09.996	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gob200qvqlwcpzipd5k5	This deserves more upvotes!	2025-06-24 07:12:41.38	\N	\N	cmgu2gnhn0079qlwcpw5y5ivj	36	2025-10-16 23:44:09.998	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gob900qxqlwc7znmeih8	This is exactly what I needed. Saved!	2025-05-21 21:27:01.907	\N	\N	cmgu2gnhq007bqlwcxm79p2ok	64	2025-10-16 23:44:10.006	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gobc00qzqlwcqsbn89gs	I've been doing this for years and can vouch for it.	2025-04-27 18:59:16.825	\N	\N	cmgu2gnhq007bqlwcxm79p2ok	92	2025-10-16 23:44:10.008	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gobf00r1qlwck432lm2n	This is a game changer. Thank you!	2025-03-21 04:12:19.572	\N	\N	cmgu2gnhq007bqlwcxm79p2ok	16	2025-10-16 23:44:10.012	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gofh00tfqlwcqmob7mzl	This is exactly what I needed. Saved!	2025-08-15 01:58:42.505	\N	\N	cmgu2gni8007pqlwc4ha748o6	39	2025-10-16 23:44:10.157	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gofk00thqlwcuyvilc0o	Update: I tried this and it worked perfectly!	2025-09-02 10:29:24.025	\N	\N	cmgu2gni8007pqlwc4ha748o6	-1	2025-10-16 23:44:10.16	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gofo00tjqlwcjl2cuqcb	This deserves more upvotes!	2025-07-27 18:48:50.647	\N	\N	cmgu2gni8007pqlwc4ha748o6	15	2025-10-16 23:44:10.164	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gofq00tlqlwclos0nh4d	Following this thread. Great discussion!	2025-07-31 17:54:15.477	\N	\N	cmgu2gni8007pqlwc4ha748o6	23	2025-10-16 23:44:10.167	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2goft00tnqlwcw6449d8b	Following this thread. Great discussion!	2025-08-14 15:17:15.029	\N	\N	cmgu2gni8007pqlwc4ha748o6	58	2025-10-16 23:44:10.169	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gofw00tpqlwcuanr7w5z	I disagree, but I respect your opinion.	2025-08-02 03:14:31.858	\N	\N	cmgu2gni8007pqlwc4ha748o6	42	2025-10-16 23:44:10.172	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gofy00trqlwcnbz8r6a2	This is exactly what I needed. Saved!	2025-07-25 01:29:52.059	\N	\N	cmgu2gni8007pqlwc4ha748o6	21	2025-10-16 23:44:10.175	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gog100ttqlwcu777qi9y	I've been doing this for years and can vouch for it.	2025-07-30 14:55:24.889	\N	\N	cmgu2gni8007pqlwc4ha748o6	60	2025-10-16 23:44:10.177	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gog300tvqlwcchbkrfhv	I've been doing this for years and can vouch for it.	2025-09-02 11:04:28.393	\N	\N	cmgu2gni8007pqlwc4ha748o6	71	2025-10-16 23:44:10.18	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gog800txqlwcda9tnu5z	What resources would you recommend for learning more?	2025-09-02 03:53:42.909	\N	\N	cmgu2gni8007pqlwc4ha748o6	7	2025-10-16 23:44:10.184	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gogd00tzqlwcj08g9imr	Interesting perspective. I never thought about it that way.	2025-09-15 10:19:13.731	\N	\N	cmgu2gnia007rqlwc3vlzzprz	81	2025-10-16 23:44:10.189	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gogf00u1qlwcpjejj3hv	Update: I tried this and it worked perfectly!	2025-08-02 12:33:03.594	\N	\N	cmgu2gnia007rqlwc3vlzzprz	57	2025-10-16 23:44:10.192	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gogi00u3qlwcjy3aaof3	I disagree, but I respect your opinion.	2025-05-28 06:45:35.211	\N	\N	cmgu2gnia007rqlwc3vlzzprz	56	2025-10-16 23:44:10.194	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gogl00u5qlwc65j7sbub	What resources would you recommend for learning more?	2025-09-03 12:42:16.504	\N	\N	cmgu2gnia007rqlwc3vlzzprz	84	2025-10-16 23:44:10.197	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gogo00u7qlwcbagdex9w	I disagree, but I respect your opinion.	2025-09-02 00:08:41.041	\N	\N	cmgu2gnia007rqlwc3vlzzprz	37	2025-10-16 23:44:10.2	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gogq00u9qlwclkrwi6ez	What resources would you recommend for learning more?	2025-05-18 07:23:08.928	\N	\N	cmgu2gnia007rqlwc3vlzzprz	88	2025-10-16 23:44:10.203	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gogt00ubqlwcuuej9emq	This deserves more upvotes!	2025-07-31 19:02:26.91	\N	\N	cmgu2gnia007rqlwc3vlzzprz	0	2025-10-16 23:44:10.205	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gogv00udqlwcagtn4lhm	Great post! Really helpful information.	2025-10-10 22:08:00.395	\N	\N	cmgu2gnia007rqlwc3vlzzprz	29	2025-10-16 23:44:10.207	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2god700sbqlwcwiqs4dza	Can confirm, this is accurate.	2025-09-05 12:09:06.587	\N	\N	cmgu2gnhy007hqlwcoyumsrpn	52	2025-10-16 23:44:10.075	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2god900sdqlwcbgbbo7y3	This is exactly what I needed. Saved!	2025-08-25 09:28:29.031	\N	\N	cmgu2gnhy007hqlwcoyumsrpn	50	2025-10-16 23:44:10.077	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2godd00sfqlwcvd2noief	Great post! Really helpful information.	2025-08-24 19:38:16.507	\N	\N	cmgu2gni0007jqlwcrerqahm9	37	2025-10-16 23:44:10.082	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2godf00shqlwcucg0vti4	Thanks for posting this! Very informative.	2025-10-01 04:43:06.984	\N	\N	cmgu2gni0007jqlwcrerqahm9	22	2025-10-16 23:44:10.084	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2godh00sjqlwc7h3n9g6a	This is a game changer. Thank you!	2025-09-05 12:14:25.915	\N	\N	cmgu2gni0007jqlwcrerqahm9	25	2025-10-16 23:44:10.086	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2godk00slqlwc5dw6apcs	Can confirm, this is accurate.	2025-09-11 10:35:48.26	\N	\N	cmgu2gni0007jqlwcrerqahm9	12	2025-10-16 23:44:10.089	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2godn00snqlwcabf0rx0n	This is exactly what I needed. Saved!	2025-09-06 10:19:13.425	\N	\N	cmgu2gni0007jqlwcrerqahm9	52	2025-10-16 23:44:10.091	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2godp00spqlwc5423arl7	Following this thread. Great discussion!	2025-09-02 04:23:19.601	\N	\N	cmgu2gni0007jqlwcrerqahm9	65	2025-10-16 23:44:10.094	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2godu00srqlwcrcrklnxz	Corpus audio texo conventus temporibus. Coma aliquam vicissitudo repellat rem clamo. Abundans verto tamisium adsidue supellex validus arx theologus tertius.	2025-09-10 13:25:53.213	\N	\N	cmgu2gni3007lqlwcgb8ihf60	68	2025-10-16 23:44:10.099	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2godx00stqlwcpnspk8up	I disagree, but I respect your opinion.	2025-06-01 23:59:03.867	\N	\N	cmgu2gni3007lqlwcgb8ihf60	23	2025-10-16 23:44:10.101	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2godz00svqlwccw8efb6x	Can confirm, this is accurate.	2025-08-27 21:12:42.743	\N	\N	cmgu2gni3007lqlwcgb8ihf60	29	2025-10-16 23:44:10.104	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2goe200sxqlwcemi891ok	Claustrum cibus traho. Caritas conspergo testimonium laborum despecto deludo cervus acceptus. Combibo cervus sollers tamen debitis cotidie varietas condico.	2025-09-04 12:09:07.229	\N	\N	cmgu2gni3007lqlwcgb8ihf60	73	2025-10-16 23:44:10.106	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2goe500szqlwc8t9jlfqq	What resources would you recommend for learning more?	2025-03-14 08:29:52.326	\N	\N	cmgu2gni3007lqlwcgb8ihf60	95	2025-10-16 23:44:10.11	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2goea00t1qlwca3fmm7s2	Great post! Really helpful information.	2025-04-15 21:28:18.507	\N	\N	cmgu2gni3007lqlwcgb8ihf60	9	2025-10-16 23:44:10.114	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2goee00t3qlwc1ofpuyv4	What resources would you recommend for learning more?	2025-09-23 00:00:59.947	\N	\N	cmgu2gni3007lqlwcgb8ihf60	6	2025-10-16 23:44:10.119	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2goel00t5qlwcaswcjuxw	Infit beneficium dicta caelestis defero. Articulus conventus subseco suscipio laudantium. Dolore rem bene venustas debilito vilis expedita derideo vulnero ciminatio.	2024-11-13 01:40:43.493	\N	\N	cmgu2gni6007nqlwc431gp7q9	71	2025-10-16 23:44:10.126	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2goeq00t7qlwcjxlnzhfg	Can confirm, this is accurate.	2025-01-09 10:50:15.477	\N	\N	cmgu2gni6007nqlwc431gp7q9	6	2025-10-16 23:44:10.13	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2goet00t9qlwcwf03hfx4	Following this thread. Great discussion!	2025-01-26 15:33:42.739	\N	\N	cmgu2gni6007nqlwc431gp7q9	2	2025-10-16 23:44:10.133	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gof100tbqlwcvbahos8p	Bookmarking this for later. Excellent content!	2025-03-22 19:02:21.507	\N	\N	cmgu2gni6007nqlwc431gp7q9	68	2025-10-16 23:44:10.142	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gof900tdqlwct8tplh2u	Interesting perspective. I never thought about it that way.	2025-10-04 03:54:50.733	\N	\N	cmgu2gni6007nqlwc431gp7q9	31	2025-10-16 23:44:10.149	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gomt00ylqlwcr6pdu9sy	Following this thread. Great discussion!	2025-09-24 19:13:42.844	\N	\N	cmgu2gnj7008dqlwcyxyvgapx	36	2025-10-16 23:44:10.421	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gomw00ynqlwcksdaxwhs	Vallum conduco accusator. Tonsor tripudio auxilium consectetur blandior demulceo excepturi harum volutabrum solutio. Colo paens truculenter corroboro tutis.	2025-10-16 23:31:04.777	\N	\N	cmgu2gnj7008dqlwcyxyvgapx	68	2025-10-16 23:44:10.425	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gomz00ypqlwcpnm9oyjs	Following this thread. Great discussion!	2025-10-08 14:12:23.801	\N	\N	cmgu2gnj7008dqlwcyxyvgapx	36	2025-10-16 23:44:10.427	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gon100yrqlwczwe9j69v	I disagree, but I respect your opinion.	2025-10-04 09:31:50.699	\N	\N	cmgu2gnj7008dqlwcyxyvgapx	60	2025-10-16 23:44:10.43	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gon700ytqlwczosqsgjc	Bookmarking this for later. Excellent content!	2025-05-20 21:00:47.321	\N	\N	cmgu2gnja008fqlwcvkwxqr0e	-3	2025-10-16 23:44:10.435	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gon900yvqlwcfzxtl166	Causa studio adsum vulticulus natus cribro curia unde alveus. Absens cito angelus strenuus. Carus cupiditas sunt comedo acceptus sponte beatae subiungo tripudio.	2025-10-09 20:26:51.047	\N	\N	cmgu2gnja008fqlwcvkwxqr0e	38	2025-10-16 23:44:10.438	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gonc00yxqlwc8ow5cj9h	What resources would you recommend for learning more?	2025-07-18 22:59:55.118	\N	\N	cmgu2gnja008fqlwcvkwxqr0e	-2	2025-10-16 23:44:10.44	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gonf00yzqlwc4n6ujar5	I've been doing this for years and can vouch for it.	2025-08-22 09:34:03.357	\N	\N	cmgu2gnja008fqlwcvkwxqr0e	14	2025-10-16 23:44:10.443	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gonh00z1qlwce0bl8hvs	Following this thread. Great discussion!	2025-09-28 10:24:54.098	\N	\N	cmgu2gnja008fqlwcvkwxqr0e	78	2025-10-16 23:44:10.446	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gonk00z3qlwckkytov61	Following this thread. Great discussion!	2025-08-24 08:06:20.269	\N	\N	cmgu2gnja008fqlwcvkwxqr0e	-3	2025-10-16 23:44:10.448	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gonn00z5qlwc66atlii2	Can confirm, this is accurate.	2025-06-15 17:55:22.495	\N	\N	cmgu2gnja008fqlwcvkwxqr0e	1	2025-10-16 23:44:10.451	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gonq00z7qlwcb96o7xts	This is a game changer. Thank you!	2025-06-05 01:30:08.778	\N	\N	cmgu2gnja008fqlwcvkwxqr0e	48	2025-10-16 23:44:10.455	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gont00z9qlwcxjxu5a1v	Great post! Really helpful information.	2025-07-03 13:05:11.38	\N	\N	cmgu2gnja008fqlwcvkwxqr0e	0	2025-10-16 23:44:10.457	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gonz00zbqlwcef8pwjel	I had the same experience! Thanks for sharing.	2025-07-22 00:21:44.633	\N	\N	cmgu2gnjd008hqlwce9ko8bra	21	2025-10-16 23:44:10.463	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2goo200zdqlwcqd1i1qpm	Interesting perspective. I never thought about it that way.	2025-08-04 06:49:57.017	\N	\N	cmgu2gnjd008hqlwce9ko8bra	82	2025-10-16 23:44:10.466	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2goo500zfqlwcvewcs7n2	This is a game changer. Thank you!	2025-10-02 15:39:02.876	\N	\N	cmgu2gnjd008hqlwce9ko8bra	22	2025-10-16 23:44:10.469	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2goo700zhqlwcj5t919w2	What resources would you recommend for learning more?	2025-09-19 06:30:05.364	\N	\N	cmgu2gnjd008hqlwce9ko8bra	34	2025-10-16 23:44:10.472	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2goo900zjqlwc3mrqsgrf	Can confirm, this is accurate.	2025-09-09 22:55:05.947	\N	\N	cmgu2gnjd008hqlwce9ko8bra	51	2025-10-16 23:44:10.474	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gooc00zlqlwc89vc6dip	Bookmarking this for later. Excellent content!	2025-08-25 03:46:27.763	\N	\N	cmgu2gnjd008hqlwce9ko8bra	78	2025-10-16 23:44:10.476	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gooe00znqlwcb232fmzy	What resources would you recommend for learning more?	2025-09-21 20:01:08.61	\N	\N	cmgu2gnjd008hqlwce9ko8bra	55	2025-10-16 23:44:10.478	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gogx00ufqlwcl6wz1sdd	I disagree, but I respect your opinion.	2025-10-14 18:35:46.414	\N	\N	cmgu2gnia007rqlwc3vlzzprz	65	2025-10-16 23:44:10.209	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2goh000uhqlwcefpxo68q	Quidem alveus sponte somniculosus. Despecto dens theca dens colligo aeneus comprehendo cotidie modi. Conqueror arma causa unde.	2025-10-05 15:19:48.914	\N	\N	cmgu2gnia007rqlwc3vlzzprz	57	2025-10-16 23:44:10.212	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2goh500ujqlwcws1zkwc4	What resources would you recommend for learning more?	2025-03-23 16:19:09.914	\N	\N	cmgu2gnid007tqlwcaq97n5mw	12	2025-10-16 23:44:10.217	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2goh700ulqlwc2yb63tmm	Update: I tried this and it worked perfectly!	2025-03-24 04:39:24.37	\N	\N	cmgu2gnid007tqlwcaq97n5mw	45	2025-10-16 23:44:10.22	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2goha00unqlwcu6rzwhbl	This is exactly what I needed. Saved!	2025-07-27 07:34:17.973	\N	\N	cmgu2gnid007tqlwcaq97n5mw	28	2025-10-16 23:44:10.222	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gohc00upqlwcjm1een0b	I've been doing this for years and can vouch for it.	2025-04-04 17:10:35.968	\N	\N	cmgu2gnid007tqlwcaq97n5mw	20	2025-10-16 23:44:10.225	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gohf00urqlwc4bmfhe9o	Could you elaborate more on this point?	2025-09-10 00:36:11.737	\N	\N	cmgu2gnid007tqlwcaq97n5mw	99	2025-10-16 23:44:10.228	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gohi00utqlwcd5444awr	Aro deripio atqui cervus desparatus atque est cras tantum amplexus. Admiratio cogo vulgaris. Velociter cur dedico collum sit defluo thymbra.	2025-04-18 05:04:52.882	\N	\N	cmgu2gnid007tqlwcaq97n5mw	69	2025-10-16 23:44:10.23	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gohl00uvqlwchi0r64ih	I disagree, but I respect your opinion.	2025-09-20 11:36:02.768	\N	\N	cmgu2gnid007tqlwcaq97n5mw	11	2025-10-16 23:44:10.233	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gohp00uxqlwcdns0tz0d	This is a game changer. Thank you!	2025-09-07 13:01:09.154	\N	\N	cmgu2gnif007vqlwcm4n0dlnu	45	2025-10-16 23:44:10.238	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gohs00uzqlwcv40dpvsc	Great post! Really helpful information.	2025-09-05 18:56:06.914	\N	\N	cmgu2gnif007vqlwcm4n0dlnu	71	2025-10-16 23:44:10.24	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gohu00v1qlwca82cp8xc	Could you elaborate more on this point?	2025-07-05 07:10:54.961	\N	\N	cmgu2gnif007vqlwcm4n0dlnu	77	2025-10-16 23:44:10.242	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gohw00v3qlwczdmik9fp	Great post! Really helpful information.	2025-04-05 17:36:34.641	\N	\N	cmgu2gnif007vqlwcm4n0dlnu	13	2025-10-16 23:44:10.245	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2goi100v5qlwcj1h7rv35	I had the same experience! Thanks for sharing.	2025-04-28 20:21:43.018	\N	\N	cmgu2gnif007vqlwcm4n0dlnu	67	2025-10-16 23:44:10.249	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2goi300v7qlwc3iw33ihw	This is a game changer. Thank you!	2025-04-25 13:06:41.615	\N	\N	cmgu2gnif007vqlwcm4n0dlnu	32	2025-10-16 23:44:10.252	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2goi600v9qlwcwp02ejne	This is exactly what I needed. Saved!	2025-05-17 14:35:34.169	\N	\N	cmgu2gnif007vqlwcm4n0dlnu	42	2025-10-16 23:44:10.254	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2goib00vbqlwc8p43lg0w	Colo curatio teres uberrime totidem vulgus clibanus. Vigilo tergo bos tepidus placeat cruciamentum. Coerceo ventus vix paulatim campana defendo viscus.	2025-06-11 14:23:27.096	\N	\N	cmgu2gnii007xqlwcmmuc0h4z	57	2025-10-16 23:44:10.259	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2goid00vdqlwcr4tm3pc7	Thanks for posting this! Very informative.	2025-10-14 10:40:30.542	\N	\N	cmgu2gnii007xqlwcmmuc0h4z	79	2025-10-16 23:44:10.262	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2goif00vfqlwcpglq2b6h	Cupio maiores appositus fugit thesis torqueo caute virtus cetera consequuntur. Quas tantillus vilitas. Voluptatibus comis curtus sordeo quasi constans.	2025-07-09 08:59:54.526	\N	\N	cmgu2gnii007xqlwcmmuc0h4z	97	2025-10-16 23:44:10.264	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2goii00vhqlwcuci9w5v2	Following this thread. Great discussion!	2025-08-17 04:52:25.534	\N	\N	cmgu2gnii007xqlwcmmuc0h4z	31	2025-10-16 23:44:10.266	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2goik00vjqlwcli64v0dn	Update: I tried this and it worked perfectly!	2025-06-07 23:29:56.4	\N	\N	cmgu2gnii007xqlwcmmuc0h4z	29	2025-10-16 23:44:10.268	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2goim00vlqlwc1baaoiub	Great post! Really helpful information.	2025-06-30 23:20:15.205	\N	\N	cmgu2gnii007xqlwcmmuc0h4z	39	2025-10-16 23:44:10.271	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2goir00vnqlwc3mlpn2bh	Following this thread. Great discussion!	2025-06-22 07:07:05.155	\N	\N	cmgu2gnil007zqlwcu2ev4o64	25	2025-10-16 23:44:10.275	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2goit00vpqlwcwnn5cxm3	I disagree, but I respect your opinion.	2025-03-10 23:59:46.237	\N	\N	cmgu2gnil007zqlwcu2ev4o64	35	2025-10-16 23:44:10.277	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2goiv00vrqlwcmjru0m4s	Great post! Really helpful information.	2025-08-30 21:35:13.746	\N	\N	cmgu2gnil007zqlwcu2ev4o64	42	2025-10-16 23:44:10.279	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2goix00vtqlwcl89uh3zw	Sortitus templum versus capio ascisco deleniti supellex. Arbor coma argumentum attonbitus tempus veniam vulariter. Perspiciatis assentator cicuta sonitus.	2025-05-27 19:59:06.578	\N	\N	cmgu2gnil007zqlwcu2ev4o64	79	2025-10-16 23:44:10.282	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2goiz00vvqlwc02e0v6s8	Could you elaborate more on this point?	2025-06-12 22:33:53.531	\N	\N	cmgu2gnil007zqlwcu2ev4o64	65	2025-10-16 23:44:10.284	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2goj200vxqlwcs754gzsx	Interesting perspective. I never thought about it that way.	2025-08-31 09:58:39.796	\N	\N	cmgu2gnil007zqlwcu2ev4o64	17	2025-10-16 23:44:10.286	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2goj400vzqlwcfkfl51yz	Can confirm, this is accurate.	2025-08-31 20:18:17.245	\N	\N	cmgu2gnil007zqlwcu2ev4o64	1	2025-10-16 23:44:10.288	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2goja00w1qlwcgz55y523	Following this thread. Great discussion!	2025-09-04 11:13:38.053	\N	\N	cmgu2gnin0081qlwchuegw75e	81	2025-10-16 23:44:10.294	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gojd00w3qlwctzf5t0dm	I disagree, but I respect your opinion.	2025-08-28 21:57:44.229	\N	\N	cmgu2gnin0081qlwchuegw75e	39	2025-10-16 23:44:10.297	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gojf00w5qlwc2i3os2et	Thanks for posting this! Very informative.	2025-10-15 16:42:01.444	\N	\N	cmgu2gnin0081qlwchuegw75e	96	2025-10-16 23:44:10.3	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2goji00w7qlwca4bfhg8h	Great post! Really helpful information.	2025-08-20 15:56:25.217	\N	\N	cmgu2gnin0081qlwchuegw75e	1	2025-10-16 23:44:10.302	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gojk00w9qlwcg86wcfc2	Can confirm, this is accurate.	2025-10-10 18:33:29.8	\N	\N	cmgu2gnin0081qlwchuegw75e	19	2025-10-16 23:44:10.305	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gojn00wbqlwc6lxi63xw	I've been doing this for years and can vouch for it.	2025-09-21 22:55:44.479	\N	\N	cmgu2gnin0081qlwchuegw75e	38	2025-10-16 23:44:10.307	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gojr00wdqlwc6s19wpls	Following this thread. Great discussion!	2025-06-30 08:29:04.828	\N	\N	cmgu2gniq0083qlwcqs532ixz	98	2025-10-16 23:44:10.311	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gojt00wfqlwc2utomwhv	Could you elaborate more on this point?	2025-07-31 05:19:02.478	\N	\N	cmgu2gniq0083qlwcqs532ixz	37	2025-10-16 23:44:10.314	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gojv00whqlwc8se6r56j	Update: I tried this and it worked perfectly!	2025-09-01 21:47:38.983	\N	\N	cmgu2gniq0083qlwcqs532ixz	24	2025-10-16 23:44:10.316	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gojy00wjqlwcp1dgt53w	I had the same experience! Thanks for sharing.	2025-09-25 00:53:54.445	\N	\N	cmgu2gniq0083qlwcqs532ixz	1	2025-10-16 23:44:10.318	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gok000wlqlwcu8lbrmss	Update: I tried this and it worked perfectly!	2025-05-26 10:24:29.506	\N	\N	cmgu2gniq0083qlwcqs532ixz	17	2025-10-16 23:44:10.32	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gok500wnqlwca1l6flxd	Can confirm, this is accurate.	2025-09-17 14:17:08.737	\N	\N	cmgu2gnit0085qlwc1j8lc8nm	96	2025-10-16 23:44:10.325	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gok700wpqlwckjay5zc6	I had the same experience! Thanks for sharing.	2025-09-16 15:35:30.025	\N	\N	cmgu2gnit0085qlwc1j8lc8nm	54	2025-10-16 23:44:10.328	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2goka00wrqlwcb955c0h8	Thanks for posting this! Very informative.	2025-09-25 03:07:23.003	\N	\N	cmgu2gnit0085qlwc1j8lc8nm	77	2025-10-16 23:44:10.33	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gokc00wtqlwcfncld66y	Update: I tried this and it worked perfectly!	2025-09-16 14:17:51.436	\N	\N	cmgu2gnit0085qlwc1j8lc8nm	13	2025-10-16 23:44:10.333	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2goke00wvqlwcwcevvm9l	Great post! Really helpful information.	2025-09-22 06:32:06.894	\N	\N	cmgu2gnit0085qlwc1j8lc8nm	62	2025-10-16 23:44:10.335	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gokh00wxqlwce6uwvft4	Can confirm, this is accurate.	2025-10-03 19:18:57.606	\N	\N	cmgu2gnit0085qlwc1j8lc8nm	38	2025-10-16 23:44:10.337	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gokj00wzqlwccsokxc4v	Amita avaritia crux ascisco terga curriculum universe provident. Quisquam dolorem conturbo velit adduco condico suppellex. Umquam terga incidunt agnosco caute terminatio vinco ocer aequus.	2025-09-23 03:08:38.092	\N	\N	cmgu2gnit0085qlwc1j8lc8nm	3	2025-10-16 23:44:10.339	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gokl00x1qlwc1p8wfddx	This deserves more upvotes!	2025-09-20 18:33:01.605	\N	\N	cmgu2gnit0085qlwc1j8lc8nm	92	2025-10-16 23:44:10.341	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gokq00x3qlwcuxomy2zl	Following this thread. Great discussion!	2025-08-13 17:38:50.611	\N	\N	cmgu2gniw0087qlwc0hlk874k	0	2025-10-16 23:44:10.346	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2goks00x5qlwcjwxdg1rv	Claustrum decimus tempus degenero audentia subseco. Perspiciatis curia aveho voluptates virtus. Consectetur chirographum tersus dignissimos tersus curatio corona custodia tribuo approbo.	2025-09-13 12:28:35.664	\N	\N	cmgu2gniw0087qlwc0hlk874k	35	2025-10-16 23:44:10.349	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gokv00x7qlwc1c6thxqm	Could you elaborate more on this point?	2025-06-27 19:29:27.956	\N	\N	cmgu2gniw0087qlwc0hlk874k	-1	2025-10-16 23:44:10.351	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gokx00x9qlwcu6r6yr96	Can confirm, this is accurate.	2025-05-12 12:57:18.739	\N	\N	cmgu2gniw0087qlwc0hlk874k	23	2025-10-16 23:44:10.353	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gol000xbqlwcf1iymk3z	Update: I tried this and it worked perfectly!	2025-05-11 11:53:43.247	\N	\N	cmgu2gniw0087qlwc0hlk874k	60	2025-10-16 23:44:10.356	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gol200xdqlwc9dp229gv	Interesting perspective. I never thought about it that way.	2025-06-20 22:45:31.758	\N	\N	cmgu2gniw0087qlwc0hlk874k	52	2025-10-16 23:44:10.358	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gol400xfqlwclyvfhb39	This is a game changer. Thank you!	2025-06-18 13:00:35.167	\N	\N	cmgu2gniw0087qlwc0hlk874k	-1	2025-10-16 23:44:10.36	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gol600xhqlwcnleguhey	What resources would you recommend for learning more?	2025-05-09 11:22:43.279	\N	\N	cmgu2gniw0087qlwc0hlk874k	52	2025-10-16 23:44:10.363	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gol900xjqlwclynxhjw9	Following this thread. Great discussion!	2025-05-08 04:37:56.849	\N	\N	cmgu2gniw0087qlwc0hlk874k	72	2025-10-16 23:44:10.365	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2golb00xlqlwc7972cdkq	I disagree, but I respect your opinion.	2025-09-16 13:41:31.664	\N	\N	cmgu2gniw0087qlwc0hlk874k	48	2025-10-16 23:44:10.367	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2golf00xnqlwca44l1jx0	Great post! Really helpful information.	2025-09-23 05:04:34.918	\N	\N	cmgu2gniy0089qlwcsaw897wa	92	2025-10-16 23:44:10.372	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2golh00xpqlwcv6icmrtn	Ventito complectus fuga spero utilis. Curo desipio tres. Nulla demergo cohaero.	2025-10-12 16:27:56.296	\N	\N	cmgu2gniy0089qlwcsaw897wa	7	2025-10-16 23:44:10.374	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2golk00xrqlwcj91expjp	Verumtamen aperte caries coma dolorem. Administratio vinculum admoveo voluptas beatae trucido articulus. Demitto dedecor decens.	2025-07-16 16:55:16.521	\N	\N	cmgu2gniy0089qlwcsaw897wa	44	2025-10-16 23:44:10.376	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2golm00xtqlwckr7jykwv	Can confirm, this is accurate.	2025-08-09 05:43:50.642	\N	\N	cmgu2gniy0089qlwcsaw897wa	26	2025-10-16 23:44:10.378	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2golo00xvqlwcr5jus94f	This is a game changer. Thank you!	2025-07-18 09:23:07.967	\N	\N	cmgu2gniy0089qlwcsaw897wa	88	2025-10-16 23:44:10.38	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gols00xxqlwcs1wmwhum	I had the same experience! Thanks for sharing.	2025-06-01 17:31:14.107	\N	\N	cmgu2gnj4008bqlwcj0ktc4tm	24	2025-10-16 23:44:10.385	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2golv00xzqlwcidc35q5g	Interesting perspective. I never thought about it that way.	2025-06-07 17:09:59.417	\N	\N	cmgu2gnj4008bqlwcj0ktc4tm	88	2025-10-16 23:44:10.387	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2golx00y1qlwc04tqfl7n	Bookmarking this for later. Excellent content!	2025-08-26 17:33:45.936	\N	\N	cmgu2gnj4008bqlwcj0ktc4tm	15	2025-10-16 23:44:10.389	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2golz00y3qlwcr93jy96s	This is exactly what I needed. Saved!	2025-06-20 08:58:13.028	\N	\N	cmgu2gnj4008bqlwcj0ktc4tm	41	2025-10-16 23:44:10.391	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gom100y5qlwc7bm7t7s7	Following this thread. Great discussion!	2025-07-11 17:38:16.835	\N	\N	cmgu2gnj4008bqlwcj0ktc4tm	44	2025-10-16 23:44:10.393	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gom500y7qlwc5u5u27og	Soluta traho toties viriliter adsuesco. Porro crepusculum comedo qui suadeo sublime aptus cupressus. Defaeco in in.	2025-07-17 05:24:06.619	\N	\N	cmgu2gnj4008bqlwcj0ktc4tm	67	2025-10-16 23:44:10.397	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gom700y9qlwctzzovg9n	Following this thread. Great discussion!	2025-10-09 00:20:19.923	\N	\N	cmgu2gnj4008bqlwcj0ktc4tm	9	2025-10-16 23:44:10.399	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gomc00ybqlwcyc945trp	Sequi ipsam minus accedo concido vitiosus cras caecus. Asper capto valeo conitor officiis terga accommodo. Summopere traho vesica aurum decor socius clibanus tot caste vilis.	2025-10-09 21:22:50.123	\N	\N	cmgu2gnj7008dqlwcyxyvgapx	49	2025-10-16 23:44:10.404	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gome00ydqlwcufsn631w	This deserves more upvotes!	2025-09-30 06:53:46.936	\N	\N	cmgu2gnj7008dqlwcyxyvgapx	39	2025-10-16 23:44:10.407	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gomk00yfqlwcdaw3jdao	Thanks for posting this! Very informative.	2025-10-12 02:29:51.855	\N	\N	cmgu2gnj7008dqlwcyxyvgapx	62	2025-10-16 23:44:10.412	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gomn00yhqlwc10ymt06v	This is a game changer. Thank you!	2025-10-09 10:05:04.95	\N	\N	cmgu2gnj7008dqlwcyxyvgapx	93	2025-10-16 23:44:10.416	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gomq00yjqlwci74yb6s1	This is a game changer. Thank you!	2025-10-11 18:46:18.07	\N	\N	cmgu2gnj7008dqlwcyxyvgapx	28	2025-10-16 23:44:10.419	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gotj012lqlwcflbyf880	This is a game changer. Thank you!	2025-09-10 20:42:54.411	\N	\N	cmgu2gnjt008vqlwcawp7orur	84	2025-10-16 23:44:10.663	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2goxj0155qlwc4206v92t	What resources would you recommend for learning more?	2025-08-08 02:17:32.949	\N	\N	cmgu2gnk60095qlwcid6g7s9i	7	2025-10-16 23:44:10.807	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2goxl0157qlwch5f4vs4b	This is a game changer. Thank you!	2025-07-28 11:19:01.591	\N	\N	cmgu2gnk60095qlwcid6g7s9i	38	2025-10-16 23:44:10.81	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2goxq0159qlwcd2k8qk64	Following this thread. Great discussion!	2025-05-10 18:59:11.444	\N	\N	cmgu2gnk90097qlwc9nh7qwx4	-4	2025-10-16 23:44:10.814	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2goxs015bqlwcsyiu4tbh	Can confirm, this is accurate.	2025-05-04 18:23:59.823	\N	\N	cmgu2gnk90097qlwc9nh7qwx4	99	2025-10-16 23:44:10.817	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gooh00zpqlwciclb24u1	Great post! Really helpful information.	2025-08-05 15:51:23.059	\N	\N	cmgu2gnjd008hqlwce9ko8bra	-2	2025-10-16 23:44:10.481	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2goom00zrqlwcpawym36f	Can confirm, this is accurate.	2025-08-18 05:54:05.06	\N	\N	cmgu2gnjd008hqlwce9ko8bra	10	2025-10-16 23:44:10.485	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gooq00ztqlwcd3gw67po	Bookmarking this for later. Excellent content!	2025-07-13 00:38:00.03	\N	\N	cmgu2gnjd008hqlwce9ko8bra	71	2025-10-16 23:44:10.49	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2goov00zvqlwcll16i84r	Arceo conqueror canonicus cupressus admoneo accusamus cras natus tamdiu. Volup ubi temptatio debeo speciosus sum solutio umbra. Sed suffragium dolorum.	2025-08-24 11:02:12.289	\N	\N	cmgu2gnjf008jqlwcibobhafv	39	2025-10-16 23:44:10.495	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gooy00zxqlwc3ip17kpu	Update: I tried this and it worked perfectly!	2025-08-06 02:04:13.039	\N	\N	cmgu2gnjf008jqlwcibobhafv	75	2025-10-16 23:44:10.499	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gop100zzqlwcagk3iw2s	Great post! Really helpful information.	2025-08-05 18:08:11.752	\N	\N	cmgu2gnjf008jqlwcibobhafv	84	2025-10-16 23:44:10.501	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gop30101qlwc833lqs22	I've been doing this for years and can vouch for it.	2025-08-09 01:13:20.932	\N	\N	cmgu2gnjf008jqlwcibobhafv	-3	2025-10-16 23:44:10.504	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gop60103qlwcaghdgkld	This deserves more upvotes!	2025-09-11 05:28:34.793	\N	\N	cmgu2gnjf008jqlwcibobhafv	42	2025-10-16 23:44:10.507	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gop90105qlwcykpmuz0p	What resources would you recommend for learning more?	2025-09-16 19:48:56.328	\N	\N	cmgu2gnjf008jqlwcibobhafv	30	2025-10-16 23:44:10.509	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gopf0107qlwco6x7ir9q	I've been doing this for years and can vouch for it.	2025-09-11 05:07:59.969	\N	\N	cmgu2gnjh008lqlwcq5fykzfg	46	2025-10-16 23:44:10.515	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2goph0109qlwcx7haiw3n	Following this thread. Great discussion!	2025-01-27 12:20:39.431	\N	\N	cmgu2gnjh008lqlwcq5fykzfg	25	2025-10-16 23:44:10.517	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gopj010bqlwcoh9hzb1e	I've been doing this for years and can vouch for it.	2025-09-06 18:04:28.192	\N	\N	cmgu2gnjh008lqlwcq5fykzfg	42	2025-10-16 23:44:10.52	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gopl010dqlwcup45bras	This is exactly what I needed. Saved!	2025-07-27 13:14:24.991	\N	\N	cmgu2gnjh008lqlwcq5fykzfg	45	2025-10-16 23:44:10.522	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gopo010fqlwcg3ufmz3p	This is exactly what I needed. Saved!	2025-02-20 07:13:32.876	\N	\N	cmgu2gnjh008lqlwcq5fykzfg	39	2025-10-16 23:44:10.524	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gopq010hqlwc1mn0qyg2	What resources would you recommend for learning more?	2025-06-26 00:09:52.486	\N	\N	cmgu2gnjh008lqlwcq5fykzfg	27	2025-10-16 23:44:10.527	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gopt010jqlwcbjzrlu2h	Ullus sto coniecto super beneficium. Despecto atavus cogo color cogito careo cursus animi aqua dolorem. Corona avaritia vita adnuo.	2025-01-19 15:15:56.841	\N	\N	cmgu2gnjh008lqlwcq5fykzfg	15	2025-10-16 23:44:10.529	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gopv010lqlwc1fwamyd1	Update: I tried this and it worked perfectly!	2025-02-28 23:53:34.207	\N	\N	cmgu2gnjh008lqlwcq5fykzfg	17	2025-10-16 23:44:10.532	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gopy010nqlwcu0r8jjfa	I've been doing this for years and can vouch for it.	2025-08-28 08:31:55.043	\N	\N	cmgu2gnjh008lqlwcq5fykzfg	6	2025-10-16 23:44:10.534	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2goq4010pqlwc7jl3wm25	I had the same experience! Thanks for sharing.	2025-05-30 22:37:28.007	\N	\N	cmgu2gnjk008nqlwci580g2tw	46	2025-10-16 23:44:10.54	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2goq7010rqlwcrei4ccat	This is a game changer. Thank you!	2025-04-27 11:30:31.261	\N	\N	cmgu2gnjk008nqlwci580g2tw	68	2025-10-16 23:44:10.543	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2goqa010tqlwc4arxbb8x	This is exactly what I needed. Saved!	2025-10-10 17:30:18.353	\N	\N	cmgu2gnjk008nqlwci580g2tw	26	2025-10-16 23:44:10.546	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2goqe010vqlwcabkaq2lc	This is exactly what I needed. Saved!	2025-08-12 08:20:41.793	\N	\N	cmgu2gnjk008nqlwci580g2tw	33	2025-10-16 23:44:10.55	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2goqj010xqlwcdmtbush4	This is exactly what I needed. Saved!	2025-08-23 11:31:07.866	\N	\N	cmgu2gnjk008nqlwci580g2tw	99	2025-10-16 23:44:10.556	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2goqs010zqlwcwihyvmys	I had the same experience! Thanks for sharing.	2025-08-12 03:08:20.058	\N	\N	cmgu2gnjm008pqlwc8shv880s	90	2025-10-16 23:44:10.564	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2goqw0111qlwcxfznq0aa	Can confirm, this is accurate.	2025-07-03 18:46:29.138	\N	\N	cmgu2gnjm008pqlwc8shv880s	16	2025-10-16 23:44:10.568	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2goqy0113qlwc3y88w3l3	Interesting perspective. I never thought about it that way.	2025-07-08 10:45:31.854	\N	\N	cmgu2gnjm008pqlwc8shv880s	43	2025-10-16 23:44:10.57	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gor30115qlwc59e8ik79	Thanks for posting this! Very informative.	2025-09-13 22:50:53.539	\N	\N	cmgu2gnjm008pqlwc8shv880s	14	2025-10-16 23:44:10.575	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gor60117qlwc6cld4szx	What resources would you recommend for learning more?	2025-08-09 19:42:32.166	\N	\N	cmgu2gnjm008pqlwc8shv880s	94	2025-10-16 23:44:10.578	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gor90119qlwcnidmwfqe	Interesting perspective. I never thought about it that way.	2025-08-18 21:53:17.302	\N	\N	cmgu2gnjm008pqlwc8shv880s	76	2025-10-16 23:44:10.581	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gore011bqlwc5mf6a4rs	This is exactly what I needed. Saved!	2025-10-14 01:13:36.743	\N	\N	cmgu2gnjm008pqlwc8shv880s	19	2025-10-16 23:44:10.586	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gorh011dqlwcg7p70zx4	Can confirm, this is accurate.	2025-06-07 14:37:03.676	\N	\N	cmgu2gnjm008pqlwc8shv880s	25	2025-10-16 23:44:10.59	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gorl011fqlwczqu38ea1	This deserves more upvotes!	2025-06-02 14:49:39.636	\N	\N	cmgu2gnjm008pqlwc8shv880s	76	2025-10-16 23:44:10.593	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gory011hqlwcl8yasbbs	Ambulo theca cultellus casso carmen cohibeo catena curriculum itaque sapiente. Cimentarius tubineus sit cena asper quia strenuus beatus. Comitatus vinco causa teneo cras soluta taedium crebro ceno vulpes.	2025-08-26 19:24:09.961	\N	\N	cmgu2gnjo008rqlwcx4frguc9	23	2025-10-16 23:44:10.606	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gos0011jqlwc8ugim8jo	Could you elaborate more on this point?	2025-09-18 03:39:09.658	\N	\N	cmgu2gnjo008rqlwcx4frguc9	26	2025-10-16 23:44:10.609	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gos3011lqlwcj4ohkhaf	Bookmarking this for later. Excellent content!	2025-08-28 03:49:34.094	\N	\N	cmgu2gnjo008rqlwcx4frguc9	27	2025-10-16 23:44:10.611	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gos6011nqlwc0pmma2g1	Bookmarking this for later. Excellent content!	2025-08-11 02:24:16.29	\N	\N	cmgu2gnjo008rqlwcx4frguc9	11	2025-10-16 23:44:10.614	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gos8011pqlwczfobanur	Following this thread. Great discussion!	2025-10-02 00:13:18.057	\N	\N	cmgu2gnjo008rqlwcx4frguc9	1	2025-10-16 23:44:10.617	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gosb011rqlwcv7r4go35	Bookmarking this for later. Excellent content!	2025-09-20 09:48:39.528	\N	\N	cmgu2gnjo008rqlwcx4frguc9	29	2025-10-16 23:44:10.619	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gosd011tqlwcd250hqxr	I had the same experience! Thanks for sharing.	2025-10-11 04:33:55.5	\N	\N	cmgu2gnjo008rqlwcx4frguc9	80	2025-10-16 23:44:10.622	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gosf011vqlwclgf2lp38	Bookmarking this for later. Excellent content!	2025-10-02 23:39:44.517	\N	\N	cmgu2gnjo008rqlwcx4frguc9	9	2025-10-16 23:44:10.624	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gosi011xqlwc3ngf90sb	Interesting perspective. I never thought about it that way.	2025-09-26 23:04:44.23	\N	\N	cmgu2gnjo008rqlwcx4frguc9	23	2025-10-16 23:44:10.626	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gosk011zqlwcef3v7r7a	This deserves more upvotes!	2025-08-30 12:13:41.634	\N	\N	cmgu2gnjo008rqlwcx4frguc9	8	2025-10-16 23:44:10.628	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gosp0121qlwc6swbzicd	Bookmarking this for later. Excellent content!	2024-12-17 20:51:43.742	\N	\N	cmgu2gnjr008tqlwc2pb5jwav	87	2025-10-16 23:44:10.633	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gosr0123qlwczg0kfsdf	Can confirm, this is accurate.	2025-02-16 12:24:22.353	\N	\N	cmgu2gnjr008tqlwc2pb5jwav	39	2025-10-16 23:44:10.635	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gosu0125qlwco4zq2grx	This is a game changer. Thank you!	2025-06-23 03:59:09.878	\N	\N	cmgu2gnjr008tqlwc2pb5jwav	24	2025-10-16 23:44:10.638	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gosw0127qlwc83wjn8uf	I've been doing this for years and can vouch for it.	2025-03-27 01:37:16.527	\N	\N	cmgu2gnjr008tqlwc2pb5jwav	92	2025-10-16 23:44:10.641	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gosz0129qlwczp3vofx7	What resources would you recommend for learning more?	2025-02-15 05:09:50.879	\N	\N	cmgu2gnjr008tqlwc2pb5jwav	1	2025-10-16 23:44:10.643	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2got5012bqlwczvmzegdc	This is exactly what I needed. Saved!	2025-06-02 17:25:44.385	\N	\N	cmgu2gnjt008vqlwcawp7orur	48	2025-10-16 23:44:10.649	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2got8012dqlwchp04dr97	Could you elaborate more on this point?	2025-06-16 06:14:35.902	\N	\N	cmgu2gnjt008vqlwcawp7orur	72	2025-10-16 23:44:10.652	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gota012fqlwcsq3dzd3s	Great post! Really helpful information.	2025-10-12 13:58:11.192	\N	\N	cmgu2gnjt008vqlwcawp7orur	93	2025-10-16 23:44:10.655	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gotd012hqlwco8r6ju2w	Bookmarking this for later. Excellent content!	2025-06-10 22:52:50.768	\N	\N	cmgu2gnjt008vqlwcawp7orur	26	2025-10-16 23:44:10.658	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gotg012jqlwc0asuq2ij	Update: I tried this and it worked perfectly!	2025-04-21 06:53:37.972	\N	\N	cmgu2gnjt008vqlwcawp7orur	22	2025-10-16 23:44:10.66	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gotm012nqlwcmg0bezsy	I've been doing this for years and can vouch for it.	2025-05-08 08:55:51.668	\N	\N	cmgu2gnjt008vqlwcawp7orur	8	2025-10-16 23:44:10.666	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gotp012pqlwc5glk7sh3	Bookmarking this for later. Excellent content!	2025-07-28 16:58:12.994	\N	\N	cmgu2gnjt008vqlwcawp7orur	21	2025-10-16 23:44:10.669	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gotr012rqlwc8vpzcl3w	Can confirm, this is accurate.	2025-04-24 04:15:42.434	\N	\N	cmgu2gnjt008vqlwcawp7orur	6	2025-10-16 23:44:10.672	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gotu012tqlwc6bj706m5	Great post! Really helpful information.	2025-09-22 00:17:32.078	\N	\N	cmgu2gnjt008vqlwcawp7orur	45	2025-10-16 23:44:10.674	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gou0012vqlwc4gffdkjz	Update: I tried this and it worked perfectly!	2025-07-27 10:53:46.04	\N	\N	cmgu2gnjw008xqlwc4t87cugu	56	2025-10-16 23:44:10.68	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gou2012xqlwclks9wl20	Update: I tried this and it worked perfectly!	2025-07-23 14:49:30.784	\N	\N	cmgu2gnjw008xqlwc4t87cugu	25	2025-10-16 23:44:10.683	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gou5012zqlwck10kj9be	Can confirm, this is accurate.	2025-04-26 11:52:58.431	\N	\N	cmgu2gnjw008xqlwc4t87cugu	60	2025-10-16 23:44:10.685	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gou70131qlwcpnqcayo3	Bookmarking this for later. Excellent content!	2025-06-25 06:39:44.006	\N	\N	cmgu2gnjw008xqlwc4t87cugu	32	2025-10-16 23:44:10.688	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2goua0133qlwc8605m60l	Great post! Really helpful information.	2025-10-04 16:11:33.702	\N	\N	cmgu2gnjw008xqlwc4t87cugu	27	2025-10-16 23:44:10.69	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2goud0135qlwcvf1r2c6j	This is exactly what I needed. Saved!	2025-08-12 02:56:53.217	\N	\N	cmgu2gnjw008xqlwc4t87cugu	81	2025-10-16 23:44:10.693	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2goui0137qlwcydhzduws	Update: I tried this and it worked perfectly!	2025-10-13 20:35:35.503	\N	\N	cmgu2gnjy008zqlwcbic3v3ah	4	2025-10-16 23:44:10.698	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2goul0139qlwcidu9jdrc	Bookmarking this for later. Excellent content!	2025-10-09 04:57:27	\N	\N	cmgu2gnjy008zqlwcbic3v3ah	2	2025-10-16 23:44:10.701	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2goun013bqlwctviwgm8q	This is exactly what I needed. Saved!	2025-09-15 06:34:04.406	\N	\N	cmgu2gnjy008zqlwcbic3v3ah	72	2025-10-16 23:44:10.704	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gouq013dqlwcq8jx1l0m	Great post! Really helpful information.	2025-09-16 17:24:12.783	\N	\N	cmgu2gnjy008zqlwcbic3v3ah	40	2025-10-16 23:44:10.706	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gout013fqlwckwmfvcv4	Interesting perspective. I never thought about it that way.	2025-10-01 12:30:04.006	\N	\N	cmgu2gnjy008zqlwcbic3v3ah	41	2025-10-16 23:44:10.709	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gouv013hqlwcjca4ub45	Can confirm, this is accurate.	2025-09-24 06:26:19.615	\N	\N	cmgu2gnjy008zqlwcbic3v3ah	100	2025-10-16 23:44:10.711	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gov0013jqlwct2td8p09	This deserves more upvotes!	2025-10-03 09:33:10.009	\N	\N	cmgu2gnjy008zqlwcbic3v3ah	58	2025-10-16 23:44:10.716	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gov2013lqlwcjsv8ktgf	Bookmarking this for later. Excellent content!	2025-09-28 13:47:27.803	\N	\N	cmgu2gnjy008zqlwcbic3v3ah	73	2025-10-16 23:44:10.718	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gov4013nqlwcnksf8lzo	Could you elaborate more on this point?	2025-09-23 21:49:58.692	\N	\N	cmgu2gnjy008zqlwcbic3v3ah	41	2025-10-16 23:44:10.721	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gov9013pqlwcxrkxgraf	Could you elaborate more on this point?	2025-09-12 00:59:46.698	\N	\N	cmgu2gnjy008zqlwcbic3v3ah	16	2025-10-16 23:44:10.725	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gove013rqlwchpsxlurq	Can confirm, this is accurate.	2025-09-29 03:28:38.505	\N	\N	cmgu2gnk10091qlwczxozltln	34	2025-10-16 23:44:10.731	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2govh013tqlwcitxjb0l0	Bookmarking this for later. Excellent content!	2025-08-16 16:10:46.774	\N	\N	cmgu2gnk10091qlwczxozltln	100	2025-10-16 23:44:10.733	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2govn013vqlwc20iyn8xn	Update: I tried this and it worked perfectly!	2025-09-20 00:54:28.501	\N	\N	cmgu2gnk10091qlwczxozltln	40	2025-10-16 23:44:10.739	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2govq013xqlwcjz8kmwg5	Thanks for posting this! Very informative.	2025-07-12 22:09:03.64	\N	\N	cmgu2gnk10091qlwczxozltln	63	2025-10-16 23:44:10.742	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2govt013zqlwcrf029gui	Great post! Really helpful information.	2025-09-07 21:25:42.749	\N	\N	cmgu2gnk10091qlwczxozltln	12	2025-10-16 23:44:10.745	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2govv0141qlwcie491v9v	What resources would you recommend for learning more?	2025-06-25 20:39:51.486	\N	\N	cmgu2gnk10091qlwczxozltln	12	2025-10-16 23:44:10.748	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2govy0143qlwcefgtnrlq	What resources would you recommend for learning more?	2025-07-17 18:59:00.301	\N	\N	cmgu2gnk10091qlwczxozltln	100	2025-10-16 23:44:10.75	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gow10145qlwc4xzmv5i9	Could you elaborate more on this point?	2025-09-15 12:17:31.222	\N	\N	cmgu2gnk10091qlwczxozltln	2	2025-10-16 23:44:10.753	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gow40147qlwcq4g29z2e	Could you elaborate more on this point?	2025-09-26 12:08:29.169	\N	\N	cmgu2gnk10091qlwczxozltln	49	2025-10-16 23:44:10.756	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gow70149qlwccd41ihhl	Adicio valens cernuus adhuc defleo vester. Illum amissio adulatio decipio. Admiratio amor arbustum.	2025-08-20 01:50:01.808	\N	\N	cmgu2gnk10091qlwczxozltln	88	2025-10-16 23:44:10.759	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gowc014bqlwc7fy6wm2n	Following this thread. Great discussion!	2025-02-18 10:30:18.698	\N	\N	cmgu2gnk30093qlwc9recucdk	21	2025-10-16 23:44:10.764	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gowf014dqlwc527gswlo	This deserves more upvotes!	2025-07-24 01:29:15.669	\N	\N	cmgu2gnk30093qlwc9recucdk	-1	2025-10-16 23:44:10.768	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gowi014fqlwcnn1lxqew	Can confirm, this is accurate.	2025-04-17 15:33:56.384	\N	\N	cmgu2gnk30093qlwc9recucdk	11	2025-10-16 23:44:10.77	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gowl014hqlwcogz7qilv	Could you elaborate more on this point?	2025-06-13 04:15:09.924	\N	\N	cmgu2gnk30093qlwc9recucdk	71	2025-10-16 23:44:10.773	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gowo014jqlwcf55r2btx	I've been doing this for years and can vouch for it.	2025-04-17 00:31:21.85	\N	\N	cmgu2gnk30093qlwc9recucdk	81	2025-10-16 23:44:10.776	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gowq014lqlwc45bfzg78	I had the same experience! Thanks for sharing.	2025-02-21 11:19:02.693	\N	\N	cmgu2gnk30093qlwc9recucdk	85	2025-10-16 23:44:10.778	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gowt014nqlwcliw73ca8	This is a game changer. Thank you!	2025-08-29 02:35:59.647	\N	\N	cmgu2gnk30093qlwc9recucdk	58	2025-10-16 23:44:10.781	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gowx014pqlwcrcacuwk8	I disagree, but I respect your opinion.	2025-07-19 14:53:43.415	\N	\N	cmgu2gnk60095qlwcid6g7s9i	46	2025-10-16 23:44:10.786	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gox0014rqlwca5gbnko2	Thanks for posting this! Very informative.	2025-08-25 12:24:07.668	\N	\N	cmgu2gnk60095qlwcid6g7s9i	-3	2025-10-16 23:44:10.788	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gox3014tqlwcz2fvpvsa	Bookmarking this for later. Excellent content!	2025-08-04 17:14:00.728	\N	\N	cmgu2gnk60095qlwcid6g7s9i	71	2025-10-16 23:44:10.791	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gox6014vqlwcl6z1fzhy	Great post! Really helpful information.	2025-07-12 19:51:03.584	\N	\N	cmgu2gnk60095qlwcid6g7s9i	44	2025-10-16 23:44:10.794	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gox8014xqlwcau0hyeqe	Appositus taedium colligo tactus. Dedico ullam quisquam sto venustas congregatio usitas cotidie. Acervus despecto calculus.	2025-07-26 14:02:26.143	\N	\N	cmgu2gnk60095qlwcid6g7s9i	81	2025-10-16 23:44:10.797	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2goxb014zqlwcj0stmfy5	I had the same experience! Thanks for sharing.	2025-08-17 12:05:44.601	\N	\N	cmgu2gnk60095qlwcid6g7s9i	11	2025-10-16 23:44:10.8	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2goxe0151qlwcvk6vwvi7	Interesting perspective. I never thought about it that way.	2025-07-10 20:17:30.15	\N	\N	cmgu2gnk60095qlwcid6g7s9i	70	2025-10-16 23:44:10.802	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2goxg0153qlwc5kwd5s5r	Could you elaborate more on this point?	2025-07-23 07:26:02.818	\N	\N	cmgu2gnk60095qlwcid6g7s9i	90	2025-10-16 23:44:10.805	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2goyx0163qlwc1gwx6l4m	I disagree, but I respect your opinion.	2025-08-23 20:04:38.91	\N	\N	cmgu2gnkg009bqlwcb1bb9okj	53	2025-10-16 23:44:10.857	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2goyz0165qlwcpj8o0alv	Following this thread. Great discussion!	2025-07-31 01:43:04.342	\N	\N	cmgu2gnkg009bqlwcb1bb9okj	62	2025-10-16 23:44:10.86	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2goz30167qlwctn3srf0j	Great post! Really helpful information.	2025-09-22 07:20:18.84	\N	\N	cmgu2gnkg009bqlwcb1bb9okj	25	2025-10-16 23:44:10.863	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2goz50169qlwczhrph9me	I've been doing this for years and can vouch for it.	2025-10-07 06:29:10.923	\N	\N	cmgu2gnkg009bqlwcb1bb9okj	33	2025-10-16 23:44:10.865	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2goz7016bqlwc5kjstg5f	This deserves more upvotes!	2025-03-07 09:21:52.989	\N	\N	cmgu2gnkg009bqlwcb1bb9okj	11	2025-10-16 23:44:10.868	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2goz9016dqlwclo5wyu3u	Update: I tried this and it worked perfectly!	2025-05-20 07:46:02.381	\N	\N	cmgu2gnkg009bqlwcb1bb9okj	91	2025-10-16 23:44:10.87	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gozc016fqlwcbp8ut6o7	Update: I tried this and it worked perfectly!	2025-09-12 15:29:48.284	\N	\N	cmgu2gnkg009bqlwcb1bb9okj	1	2025-10-16 23:44:10.872	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2goze016hqlwc26txx4m1	Update: I tried this and it worked perfectly!	2025-09-30 22:17:57.562	\N	\N	cmgu2gnkg009bqlwcb1bb9okj	8	2025-10-16 23:44:10.874	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gozg016jqlwcjf0277r0	I've been doing this for years and can vouch for it.	2025-06-13 09:12:39.64	\N	\N	cmgu2gnkg009bqlwcb1bb9okj	58	2025-10-16 23:44:10.877	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gozj016lqlwcgfd9kov8	Following this thread. Great discussion!	2025-04-29 19:10:04.417	\N	\N	cmgu2gnkg009bqlwcb1bb9okj	83	2025-10-16 23:44:10.879	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gozo016nqlwc5s6cr66i	Bookmarking this for later. Excellent content!	2025-10-01 12:06:39.928	\N	\N	cmgu2gnkl009dqlwcr3niwh4z	95	2025-10-16 23:44:10.884	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gozr016pqlwcdtzis0c0	Following this thread. Great discussion!	2025-08-31 18:25:54.383	\N	\N	cmgu2gnkl009dqlwcr3niwh4z	58	2025-10-16 23:44:10.888	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gozu016rqlwctrvcup65	Update: I tried this and it worked perfectly!	2025-09-21 01:09:51.569	\N	\N	cmgu2gnkl009dqlwcr3niwh4z	80	2025-10-16 23:44:10.89	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gozw016tqlwcoumjnktk	Can confirm, this is accurate.	2025-09-11 09:20:01.076	\N	\N	cmgu2gnkl009dqlwcr3niwh4z	93	2025-10-16 23:44:10.893	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gozz016vqlwc6n8zkqu5	Bookmarking this for later. Excellent content!	2025-09-21 04:32:25.257	\N	\N	cmgu2gnkl009dqlwcr3niwh4z	48	2025-10-16 23:44:10.895	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gp01016xqlwcl0uu06kb	Interesting perspective. I never thought about it that way.	2025-10-15 01:27:43.67	\N	\N	cmgu2gnkl009dqlwcr3niwh4z	81	2025-10-16 23:44:10.898	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gp04016zqlwc2cxymvoz	I've been doing this for years and can vouch for it.	2025-08-26 18:10:48.383	\N	\N	cmgu2gnkl009dqlwcr3niwh4z	59	2025-10-16 23:44:10.9	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gp060171qlwcx04i4jy0	Great post! Really helpful information.	2025-10-02 22:15:20.03	\N	\N	cmgu2gnkl009dqlwcr3niwh4z	60	2025-10-16 23:44:10.903	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gp0b0173qlwclgekwzi4	This is exactly what I needed. Saved!	2025-08-05 10:20:50.266	\N	\N	cmgu2gnko009fqlwcajdqljn7	6	2025-10-16 23:44:10.907	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gp0d0175qlwcmtx4ixu0	Bookmarking this for later. Excellent content!	2025-09-03 23:16:45.275	\N	\N	cmgu2gnko009fqlwcajdqljn7	66	2025-10-16 23:44:10.909	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gp0f0177qlwcqdjnrotw	Following this thread. Great discussion!	2025-06-04 23:35:27.22	\N	\N	cmgu2gnko009fqlwcajdqljn7	44	2025-10-16 23:44:10.912	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gp0i0179qlwczi4cge4u	This deserves more upvotes!	2025-06-02 02:09:12.075	\N	\N	cmgu2gnko009fqlwcajdqljn7	72	2025-10-16 23:44:10.914	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gp0k017bqlwcav4f25v5	This deserves more upvotes!	2025-07-09 08:35:31.99	\N	\N	cmgu2gnko009fqlwcajdqljn7	6	2025-10-16 23:44:10.917	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gp0m017dqlwcmk2wpmfu	Following this thread. Great discussion!	2025-07-05 22:42:51.185	\N	\N	cmgu2gnko009fqlwcajdqljn7	95	2025-10-16 23:44:10.919	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gp0p017fqlwcruh8v2h7	Interesting perspective. I never thought about it that way.	2025-08-06 12:19:52.742	\N	\N	cmgu2gnko009fqlwcajdqljn7	91	2025-10-16 23:44:10.921	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gp0r017hqlwcq15qfne8	Bookmarking this for later. Excellent content!	2025-06-29 15:42:44.016	\N	\N	cmgu2gnko009fqlwcajdqljn7	10	2025-10-16 23:44:10.924	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gp0w017jqlwc2g52yj71	Conicio facere fuga ademptio quam ventito. Viriliter ustulo tonsor quisquam aestas tamisium absque attollo careo. Testimonium porro maxime peccatus pectus supplanto cur compono.	2025-09-08 13:19:31.078	\N	\N	cmgu2gnkr009hqlwce988449u	30	2025-10-16 23:44:10.928	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gp0y017lqlwciz6lr7yh	Thanks for posting this! Very informative.	2025-02-17 22:21:56.501	\N	\N	cmgu2gnkr009hqlwce988449u	20	2025-10-16 23:44:10.931	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2goxu015dqlwc5utxbxmm	Great post! Really helpful information.	2025-10-12 11:35:33.929	\N	\N	cmgu2gnk90097qlwc9nh7qwx4	25	2025-10-16 23:44:10.819	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2goxx015fqlwcujmljgxx	What resources would you recommend for learning more?	2025-09-10 20:30:15.617	\N	\N	cmgu2gnk90097qlwc9nh7qwx4	33	2025-10-16 23:44:10.821	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2goxz015hqlwc458zu3ll	Following this thread. Great discussion!	2025-04-21 16:20:19.314	\N	\N	cmgu2gnk90097qlwc9nh7qwx4	85	2025-10-16 23:44:10.823	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2goy1015jqlwcf37rtueq	This is a game changer. Thank you!	2025-06-29 17:43:24.073	\N	\N	cmgu2gnk90097qlwc9nh7qwx4	75	2025-10-16 23:44:10.825	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2goy3015lqlwc9pzomqmj	Thanks for posting this! Very informative.	2025-04-02 11:45:02.122	\N	\N	cmgu2gnk90097qlwc9nh7qwx4	37	2025-10-16 23:44:10.827	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2goy7015nqlwc6g6inrbr	Pax synagoga adipiscor ventosus. Accusantium venia teres corona vado cubo derideo verus nulla vacuus. Textilis colo animadverto abduco curto cuppedia doloribus.	2025-08-19 16:06:57.854	\N	\N	cmgu2gnkd0099qlwct5vp58ks	4	2025-10-16 23:44:10.832	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2goya015pqlwcv4f8zc84	Bookmarking this for later. Excellent content!	2025-08-28 06:30:33.306	\N	\N	cmgu2gnkd0099qlwct5vp58ks	69	2025-10-16 23:44:10.834	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2goyc015rqlwcjs2gn5c5	This deserves more upvotes!	2025-09-02 18:29:30.534	\N	\N	cmgu2gnkd0099qlwct5vp58ks	83	2025-10-16 23:44:10.836	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2goye015tqlwcyikl8p2j	I disagree, but I respect your opinion.	2025-07-07 13:02:32.475	\N	\N	cmgu2gnkd0099qlwct5vp58ks	15	2025-10-16 23:44:10.838	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2goyg015vqlwc62xsyiua	Facere confido crux atrox virga charisma. Beatae fuga carpo culpa turbo tumultus aegre sub. Aestas bestia careo cogo sit cohors paulatim quod.	2025-10-02 05:38:17.162	\N	\N	cmgu2gnkd0099qlwct5vp58ks	29	2025-10-16 23:44:10.84	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2goyj015xqlwc6fhxu02j	I disagree, but I respect your opinion.	2025-09-08 08:03:23.805	\N	\N	cmgu2gnkd0099qlwct5vp58ks	22	2025-10-16 23:44:10.843	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2goyl015zqlwcc7xht005	Can confirm, this is accurate.	2025-09-10 14:45:27.673	\N	\N	cmgu2gnkd0099qlwct5vp58ks	68	2025-10-16 23:44:10.845	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2goyo0161qlwc4s6xv1eo	Could you elaborate more on this point?	2025-08-31 08:04:49.17	\N	\N	cmgu2gnkd0099qlwct5vp58ks	14	2025-10-16 23:44:10.848	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gp6201bbqlwcvca7h6c9	Can confirm, this is accurate.	2025-08-20 22:19:44.985	\N	\N	cmgu2gnle009zqlwc8etodfqh	9	2025-10-16 23:44:11.115	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gp6501bdqlwcw3vrizmq	Following this thread. Great discussion!	2025-07-21 23:01:13.037	\N	\N	cmgu2gnle009zqlwc8etodfqh	61	2025-10-16 23:44:11.118	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gp6901bfqlwc6s0kcmy8	Curis sed vicinus ver vinitor thema corroboro. Creptio cupio tamisium cubo alienus decet crustulum contigo. Civitas utroque coma cometes spiculum fugiat vesco contego.	2025-09-18 18:24:19.384	\N	\N	cmgu2gnle009zqlwc8etodfqh	8	2025-10-16 23:44:11.122	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gp6c01bhqlwclja4usgv	Great post! Really helpful information.	2025-07-20 04:10:28.775	\N	\N	cmgu2gnle009zqlwc8etodfqh	48	2025-10-16 23:44:11.124	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gp6f01bjqlwc3edseja8	Thanks for posting this! Very informative.	2025-06-27 13:07:58.896	\N	\N	cmgu2gnle009zqlwc8etodfqh	14	2025-10-16 23:44:11.127	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gp6i01blqlwc69hpmbqw	Great post! Really helpful information.	2025-05-11 10:22:25.768	\N	\N	cmgu2gnle009zqlwc8etodfqh	74	2025-10-16 23:44:11.13	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gp6l01bnqlwcfvyu4w7c	I've been doing this for years and can vouch for it.	2025-10-14 05:37:04.019	\N	\N	cmgu2gnle009zqlwc8etodfqh	76	2025-10-16 23:44:11.134	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gp6p01bpqlwc1c2o1web	Could you elaborate more on this point?	2025-04-25 04:17:21.324	\N	\N	cmgu2gnle009zqlwc8etodfqh	72	2025-10-16 23:44:11.138	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gp6s01brqlwc8ejbohys	This is exactly what I needed. Saved!	2025-07-30 01:37:24.113	\N	\N	cmgu2gnle009zqlwc8etodfqh	12	2025-10-16 23:44:11.14	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gp6x01btqlwcd7irzqme	Interesting perspective. I never thought about it that way.	2025-08-30 10:38:33.502	\N	\N	cmgu2gnlj00a1qlwcxgx920iz	50	2025-10-16 23:44:11.145	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gp6z01bvqlwc5u6hj5u5	This is a game changer. Thank you!	2025-06-20 04:44:03.544	\N	\N	cmgu2gnlj00a1qlwcxgx920iz	68	2025-10-16 23:44:11.147	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gp7301bxqlwcvxavvwas	Interesting perspective. I never thought about it that way.	2025-10-08 13:24:47.315	\N	\N	cmgu2gnlj00a1qlwcxgx920iz	15	2025-10-16 23:44:11.151	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gp7501bzqlwcvd444koe	Interesting perspective. I never thought about it that way.	2025-09-09 16:42:25.828	\N	\N	cmgu2gnlj00a1qlwcxgx920iz	52	2025-10-16 23:44:11.154	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gp7901c1qlwc2wwkif3y	I had the same experience! Thanks for sharing.	2025-07-23 22:23:47.094	\N	\N	cmgu2gnlj00a1qlwcxgx920iz	0	2025-10-16 23:44:11.157	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gp7c01c3qlwcwn6zr7jh	What resources would you recommend for learning more?	2025-08-17 01:07:13.855	\N	\N	cmgu2gnlj00a1qlwcxgx920iz	4	2025-10-16 23:44:11.16	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gp7e01c5qlwcxemxz66h	This deserves more upvotes!	2025-10-14 18:15:26.017	\N	\N	cmgu2gnlj00a1qlwcxgx920iz	52	2025-10-16 23:44:11.162	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gp7i01c7qlwccem3ju4y	Bookmarking this for later. Excellent content!	2025-07-23 11:01:12.314	\N	\N	cmgu2gnlj00a1qlwcxgx920iz	57	2025-10-16 23:44:11.167	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gp7l01c9qlwc628y0qzg	Update: I tried this and it worked perfectly!	2025-07-24 21:24:51.24	\N	\N	cmgu2gnlj00a1qlwcxgx920iz	44	2025-10-16 23:44:11.169	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gp7q01cbqlwc4r768tk9	I've been doing this for years and can vouch for it.	2025-10-04 05:56:07.121	\N	\N	cmgu2gnll00a3qlwc9n91f457	-1	2025-10-16 23:44:11.174	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gp7s01cdqlwcgdwm7p4a	Following this thread. Great discussion!	2025-09-29 11:42:25.371	\N	\N	cmgu2gnll00a3qlwc9n91f457	58	2025-10-16 23:44:11.176	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gp7u01cfqlwcumh05b9u	This is a game changer. Thank you!	2025-07-31 00:26:04.268	\N	\N	cmgu2gnll00a3qlwc9n91f457	44	2025-10-16 23:44:11.179	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gp7x01chqlwccgmdar60	This deserves more upvotes!	2025-10-15 13:26:01.327	\N	\N	cmgu2gnll00a3qlwc9n91f457	35	2025-10-16 23:44:11.181	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gp7z01cjqlwcb2b63s5v	This is a game changer. Thank you!	2025-08-06 14:16:55.976	\N	\N	cmgu2gnll00a3qlwc9n91f457	40	2025-10-16 23:44:11.183	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gp8101clqlwc8y2nksxg	Can confirm, this is accurate.	2025-07-11 16:00:43.499	\N	\N	cmgu2gnll00a3qlwc9n91f457	68	2025-10-16 23:44:11.186	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gp8301cnqlwcad0uq5fl	Following this thread. Great discussion!	2025-07-10 20:48:35.294	\N	\N	cmgu2gnll00a3qlwc9n91f457	85	2025-10-16 23:44:11.188	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gp8901cpqlwcfub34k90	Bookmarking this for later. Excellent content!	2025-10-05 07:32:21.648	\N	\N	cmgu2gnln00a5qlwc8e6zxumw	46	2025-10-16 23:44:11.193	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gp8b01crqlwcsfhehibj	This deserves more upvotes!	2025-10-13 19:31:06.167	\N	\N	cmgu2gnln00a5qlwc8e6zxumw	71	2025-10-16 23:44:11.196	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gp8e01ctqlwc4t7ex4sc	Interesting perspective. I never thought about it that way.	2025-09-13 04:10:56.963	\N	\N	cmgu2gnln00a5qlwc8e6zxumw	42	2025-10-16 23:44:11.199	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gp11017nqlwczbrhx1z1	Following this thread. Great discussion!	2025-09-24 10:40:09.476	\N	\N	cmgu2gnkr009hqlwce988449u	-2	2025-10-16 23:44:10.933	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gp13017pqlwc7ob2htrg	This deserves more upvotes!	2025-03-27 04:59:32.761	\N	\N	cmgu2gnkr009hqlwce988449u	23	2025-10-16 23:44:10.935	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gp15017rqlwcrpq290nj	Great post! Really helpful information.	2025-07-24 23:30:56.566	\N	\N	cmgu2gnkr009hqlwce988449u	48	2025-10-16 23:44:10.937	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gp17017tqlwctizhs29q	Est vae desolo spero copiose terga caveo. Deludo deripio temporibus delinquo vox aestus patrocinor. Cogo tricesimus decor thalassinus commodo.	2025-06-09 19:15:07.54	\N	\N	cmgu2gnkr009hqlwce988449u	16	2025-10-16 23:44:10.94	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gp1a017vqlwcugyyd5aa	Tristis abeo dignissimos absorbeo censura appono nobis. Armarium arbitro volutabrum cavus cunae comptus consequuntur tremo. Alioqui temptatio bellicus valeo decretum alii.	2025-10-06 20:00:16.953	\N	\N	cmgu2gnkr009hqlwce988449u	90	2025-10-16 23:44:10.942	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gp1c017xqlwcvz2yhtc4	Great post! Really helpful information.	2025-03-18 23:45:10.226	\N	\N	cmgu2gnkr009hqlwce988449u	57	2025-10-16 23:44:10.944	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gp1g017zqlwcbi5w2f59	Great post! Really helpful information.	2025-07-03 01:35:28.878	\N	\N	cmgu2gnku009jqlwceysdpvay	60	2025-10-16 23:44:10.949	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gp1j0181qlwceqwirutn	Interesting perspective. I never thought about it that way.	2025-08-07 11:40:41.756	\N	\N	cmgu2gnku009jqlwceysdpvay	93	2025-10-16 23:44:10.951	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gp1l0183qlwcby3cdss5	Following this thread. Great discussion!	2025-07-06 07:01:53.373	\N	\N	cmgu2gnku009jqlwceysdpvay	50	2025-10-16 23:44:10.954	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gp1o0185qlwcelm1p34i	Could you elaborate more on this point?	2025-05-03 03:24:15.876	\N	\N	cmgu2gnku009jqlwceysdpvay	43	2025-10-16 23:44:10.956	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gp1q0187qlwclyp0vlnk	Thanks for posting this! Very informative.	2025-04-18 04:42:45.983	\N	\N	cmgu2gnku009jqlwceysdpvay	70	2025-10-16 23:44:10.958	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gp1s0189qlwcbibee3d3	Following this thread. Great discussion!	2025-09-11 20:31:19.821	\N	\N	cmgu2gnku009jqlwceysdpvay	40	2025-10-16 23:44:10.96	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gp1x018bqlwcbt2w032l	This deserves more upvotes!	2025-10-04 13:45:21.197	\N	\N	cmgu2gnkx009lqlwc3khkg597	17	2025-10-16 23:44:10.965	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gp1z018dqlwc1vyxzxsy	This deserves more upvotes!	2025-09-28 08:20:22.776	\N	\N	cmgu2gnkx009lqlwc3khkg597	32	2025-10-16 23:44:10.967	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gp21018fqlwct6qsao7v	Could you elaborate more on this point?	2025-09-13 15:59:51.609	\N	\N	cmgu2gnkx009lqlwc3khkg597	80	2025-10-16 23:44:10.969	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gp23018hqlwczhrt24wm	Bookmarking this for later. Excellent content!	2025-09-19 08:57:54.337	\N	\N	cmgu2gnkx009lqlwc3khkg597	54	2025-10-16 23:44:10.972	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gp27018jqlwcyugck5mq	Can confirm, this is accurate.	2025-10-07 21:49:12.976	\N	\N	cmgu2gnkx009lqlwc3khkg597	75	2025-10-16 23:44:10.976	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gp2a018lqlwcy2ft4o5i	Interesting perspective. I never thought about it that way.	2025-10-07 17:08:31.692	\N	\N	cmgu2gnkx009lqlwc3khkg597	12	2025-10-16 23:44:10.978	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gp2c018nqlwca8heexur	I've been doing this for years and can vouch for it.	2025-10-09 01:57:48.622	\N	\N	cmgu2gnkx009lqlwc3khkg597	99	2025-10-16 23:44:10.981	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gp2f018pqlwcaq4y5o8v	This deserves more upvotes!	2025-10-01 19:36:51.883	\N	\N	cmgu2gnkx009lqlwc3khkg597	33	2025-10-16 23:44:10.983	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gp2i018rqlwcvrykndus	Tolero eligendi calculus amor volubilis amo deripio quod deludo deporto. Peccatus tabernus quos denuncio capillus crudelis recusandae. Utrimque coepi tricesimus cuius ut cui vobis.	2025-09-19 08:09:52.116	\N	\N	cmgu2gnkx009lqlwc3khkg597	14	2025-10-16 23:44:10.986	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gp2k018tqlwcdw4gqxob	Following this thread. Great discussion!	2025-09-25 11:57:14.952	\N	\N	cmgu2gnkx009lqlwc3khkg597	1	2025-10-16 23:44:10.989	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gp2p018vqlwczt08kee3	Can confirm, this is accurate.	2025-07-01 03:09:39.849	\N	\N	cmgu2gnl0009nqlwck1qy5iwt	72	2025-10-16 23:44:10.993	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gp2r018xqlwco6ig9c2c	I've been doing this for years and can vouch for it.	2025-04-19 17:10:51.405	\N	\N	cmgu2gnl0009nqlwck1qy5iwt	35	2025-10-16 23:44:10.995	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gp2t018zqlwcohnc6ped	Interesting perspective. I never thought about it that way.	2025-02-28 08:43:17.986	\N	\N	cmgu2gnl0009nqlwck1qy5iwt	47	2025-10-16 23:44:10.998	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gp2v0191qlwcxzlkp6kl	Thanks for posting this! Very informative.	2025-02-14 18:30:10.584	\N	\N	cmgu2gnl0009nqlwck1qy5iwt	44	2025-10-16 23:44:11	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gp2y0193qlwcf1oeh8re	I disagree, but I respect your opinion.	2025-05-16 18:11:43.491	\N	\N	cmgu2gnl0009nqlwck1qy5iwt	34	2025-10-16 23:44:11.002	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gp330195qlwc9r5n47by	This deserves more upvotes!	2025-08-03 12:27:11.178	\N	\N	cmgu2gnl2009pqlwc9xzsxdar	86	2025-10-16 23:44:11.007	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gp350197qlwcca0z6uba	I had the same experience! Thanks for sharing.	2025-08-09 08:35:31.34	\N	\N	cmgu2gnl2009pqlwc9xzsxdar	83	2025-10-16 23:44:11.01	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gp370199qlwcc9qu0lt2	Dolor argentum pel. Facere peior bellum solum vitium commemoro vero amoveo. Adaugeo summopere spiritus ver occaecati vergo adduco odit aperiam.	2025-01-29 22:23:09.626	\N	\N	cmgu2gnl2009pqlwc9xzsxdar	8	2025-10-16 23:44:11.012	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gp3a019bqlwcl6n1iafq	Following this thread. Great discussion!	2025-07-25 23:01:28.782	\N	\N	cmgu2gnl2009pqlwc9xzsxdar	16	2025-10-16 23:44:11.014	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gp3c019dqlwcstn4sgtf	Following this thread. Great discussion!	2025-07-21 16:58:40.257	\N	\N	cmgu2gnl2009pqlwc9xzsxdar	74	2025-10-16 23:44:11.016	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gp3e019fqlwcgsdpnirz	This deserves more upvotes!	2025-01-27 23:09:01.591	\N	\N	cmgu2gnl2009pqlwc9xzsxdar	47	2025-10-16 23:44:11.019	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gp3j019hqlwct624gid2	Thanks for posting this! Very informative.	2025-05-22 07:59:12.17	\N	\N	cmgu2gnl5009rqlwcqumgu0s2	0	2025-10-16 23:44:11.023	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gp3l019jqlwclfydxkhn	Interesting perspective. I never thought about it that way.	2025-05-04 06:18:17.612	\N	\N	cmgu2gnl5009rqlwcqumgu0s2	18	2025-10-16 23:44:11.025	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gp3n019lqlwcuxopdwnm	I've been doing this for years and can vouch for it.	2025-07-05 08:01:38.506	\N	\N	cmgu2gnl5009rqlwcqumgu0s2	94	2025-10-16 23:44:11.028	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gp3q019nqlwcpyi2xldi	Interesting perspective. I never thought about it that way.	2025-07-10 17:06:49.801	\N	\N	cmgu2gnl5009rqlwcqumgu0s2	-5	2025-10-16 23:44:11.03	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gp3s019pqlwcvexeyf3k	This deserves more upvotes!	2025-07-03 04:42:05.78	\N	\N	cmgu2gnl5009rqlwcqumgu0s2	94	2025-10-16 23:44:11.032	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gp3u019rqlwccuo2o8t5	I had the same experience! Thanks for sharing.	2025-08-11 15:15:48.353	\N	\N	cmgu2gnl5009rqlwcqumgu0s2	10	2025-10-16 23:44:11.034	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gp3w019tqlwc800bbi5z	This is a game changer. Thank you!	2025-04-13 05:17:30.657	\N	\N	cmgu2gnl5009rqlwcqumgu0s2	37	2025-10-16 23:44:11.037	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gp3y019vqlwcw3vz2qf9	This is exactly what I needed. Saved!	2025-01-21 01:52:47.829	\N	\N	cmgu2gnl5009rqlwcqumgu0s2	11	2025-10-16 23:44:11.039	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gp43019xqlwcnix3805n	This is a game changer. Thank you!	2025-08-19 09:50:04.08	\N	\N	cmgu2gnl7009tqlwcf2hx0xzn	31	2025-10-16 23:44:11.044	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gp45019zqlwcjt18eldo	This is exactly what I needed. Saved!	2025-08-31 11:56:19.759	\N	\N	cmgu2gnl7009tqlwcf2hx0xzn	5	2025-10-16 23:44:11.046	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gp4701a1qlwcnivpbl3f	I've been doing this for years and can vouch for it.	2025-07-11 12:40:04.37	\N	\N	cmgu2gnl7009tqlwcf2hx0xzn	56	2025-10-16 23:44:11.048	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gp4901a3qlwcxoe40b8l	Bookmarking this for later. Excellent content!	2025-08-31 21:06:15.254	\N	\N	cmgu2gnl7009tqlwcf2hx0xzn	0	2025-10-16 23:44:11.05	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gp4b01a5qlwcgbz0qlba	Following this thread. Great discussion!	2025-08-16 05:38:26.346	\N	\N	cmgu2gnl7009tqlwcf2hx0xzn	39	2025-10-16 23:44:11.052	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gp4g01a7qlwcef2bdmm7	Nihil infit bibo tam caput. Certe aduro aeger. Carmen sublime talis expedita demergo.	2025-10-16 11:21:07.894	\N	\N	cmgu2gnl9009vqlwcpd4swuy7	39	2025-10-16 23:44:11.057	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gp4i01a9qlwclwko22z6	I disagree, but I respect your opinion.	2025-10-13 12:17:04.862	\N	\N	cmgu2gnl9009vqlwcpd4swuy7	48	2025-10-16 23:44:11.059	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gp4k01abqlwcjwi45pf0	Great post! Really helpful information.	2025-07-24 13:15:07.945	\N	\N	cmgu2gnl9009vqlwcpd4swuy7	10	2025-10-16 23:44:11.061	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gp4n01adqlwcgnrjgwcy	This deserves more upvotes!	2025-06-27 06:25:12.654	\N	\N	cmgu2gnl9009vqlwcpd4swuy7	7	2025-10-16 23:44:11.063	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gp4p01afqlwc04kta1co	Thanks for posting this! Very informative.	2025-09-29 21:40:56.033	\N	\N	cmgu2gnl9009vqlwcpd4swuy7	0	2025-10-16 23:44:11.065	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gp4r01ahqlwcjt0vx3sv	I had the same experience! Thanks for sharing.	2025-08-26 17:43:44.058	\N	\N	cmgu2gnl9009vqlwcpd4swuy7	-4	2025-10-16 23:44:11.068	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gp4t01ajqlwcribxn532	I've been doing this for years and can vouch for it.	2025-08-17 11:11:12.547	\N	\N	cmgu2gnl9009vqlwcpd4swuy7	24	2025-10-16 23:44:11.07	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gp4w01alqlwcz7zlyki0	Can confirm, this is accurate.	2025-10-02 06:40:21.518	\N	\N	cmgu2gnl9009vqlwcpd4swuy7	49	2025-10-16 23:44:11.072	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gp4y01anqlwc3w185al1	Supra arbor vito sint itaque speculum. Tero aeternus excepturi veniam assentator victus ascisco a demitto odio. Suadeo testimonium ventus delinquo conforto balbus thema voluptates adulatio.	2025-06-26 22:09:03.368	\N	\N	cmgu2gnl9009vqlwcpd4swuy7	89	2025-10-16 23:44:11.074	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gp5001apqlwc274k2f2p	I had the same experience! Thanks for sharing.	2025-08-31 22:40:20.667	\N	\N	cmgu2gnl9009vqlwcpd4swuy7	38	2025-10-16 23:44:11.077	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gp5501arqlwc2qufuzmo	Could you elaborate more on this point?	2025-10-08 04:36:11.714	\N	\N	cmgu2gnlc009xqlwcpztauvzu	48	2025-10-16 23:44:11.082	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gp5801atqlwc38q7z6rp	Unde tantum tandem aeger vesco versus. Sui deprimo studio ipsum inflammatio accusator una. Tolero creator adflicto ocer deduco tenuis corona acsi.	2025-06-05 17:28:58.291	\N	\N	cmgu2gnlc009xqlwcpztauvzu	10	2025-10-16 23:44:11.084	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gp5a01avqlwctjtlcysg	I disagree, but I respect your opinion.	2025-07-05 19:21:58.846	\N	\N	cmgu2gnlc009xqlwcpztauvzu	22	2025-10-16 23:44:11.086	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gp5c01axqlwck3hdq4xn	This is a game changer. Thank you!	2025-06-27 09:31:18.153	\N	\N	cmgu2gnlc009xqlwcpztauvzu	45	2025-10-16 23:44:11.088	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gp5g01azqlwc831r2hse	Interesting perspective. I never thought about it that way.	2025-05-16 20:49:53.029	\N	\N	cmgu2gnlc009xqlwcpztauvzu	63	2025-10-16 23:44:11.093	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gp5j01b1qlwclg4bs34e	Could you elaborate more on this point?	2025-06-20 13:30:30.985	\N	\N	cmgu2gnlc009xqlwcpztauvzu	-2	2025-10-16 23:44:11.096	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gp5m01b3qlwc0ej6qaqb	This is exactly what I needed. Saved!	2025-06-14 02:38:52.512	\N	\N	cmgu2gnlc009xqlwcpztauvzu	61	2025-10-16 23:44:11.098	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gp5p01b5qlwca32cuixw	Bookmarking this for later. Excellent content!	2025-08-07 19:56:32.802	\N	\N	cmgu2gnlc009xqlwcpztauvzu	44	2025-10-16 23:44:11.102	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gp5s01b7qlwcu9ka5c73	Could you elaborate more on this point?	2025-08-31 18:46:56.744	\N	\N	cmgu2gnlc009xqlwcpztauvzu	97	2025-10-16 23:44:11.104	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gp5w01b9qlwc38ehcaf8	This is a game changer. Thank you!	2025-10-13 00:28:11.585	\N	\N	cmgu2gnlc009xqlwcpztauvzu	39	2025-10-16 23:44:11.109	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gpa601e1qlwct8xe21hr	Great post! Really helpful information.	2025-05-31 05:08:12.487	\N	\N	cmgu2gnlv00abqlwcdbxcll1r	24	2025-10-16 23:44:11.262	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gpa901e3qlwc7vmbzid7	I had the same experience! Thanks for sharing.	2025-10-04 07:38:44.792	\N	\N	cmgu2gnlv00abqlwcdbxcll1r	65	2025-10-16 23:44:11.265	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gpac01e5qlwcz4r4f8cs	Great post! Really helpful information.	2025-08-14 01:24:12.096	\N	\N	cmgu2gnlv00abqlwcdbxcll1r	15	2025-10-16 23:44:11.268	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gpae01e7qlwc8pvejnhn	Great post! Really helpful information.	2025-10-03 14:53:59.91	\N	\N	cmgu2gnlv00abqlwcdbxcll1r	96	2025-10-16 23:44:11.27	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gpak01e9qlwcqhdh23cs	Following this thread. Great discussion!	2025-10-12 11:51:18.239	\N	\N	cmgu2gnlv00abqlwcdbxcll1r	4	2025-10-16 23:44:11.276	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gpan01ebqlwchu5ueouo	I disagree, but I respect your opinion.	2025-06-01 16:40:14.284	\N	\N	cmgu2gnlv00abqlwcdbxcll1r	18	2025-10-16 23:44:11.279	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gpat01edqlwchwdcjsp6	Interesting perspective. I never thought about it that way.	2025-10-09 18:15:37.227	\N	\N	cmgu2gnlx00adqlwc0jmi9uk2	-2	2025-10-16 23:44:11.285	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gpav01efqlwc8noehyjy	This is exactly what I needed. Saved!	2025-10-07 01:39:05.928	\N	\N	cmgu2gnlx00adqlwc0jmi9uk2	10	2025-10-16 23:44:11.288	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gpay01ehqlwcstbk866b	This is a game changer. Thank you!	2025-10-04 04:46:12.644	\N	\N	cmgu2gnlx00adqlwc0jmi9uk2	-3	2025-10-16 23:44:11.29	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gpb001ejqlwc7nlfgdk7	I disagree, but I respect your opinion.	2025-10-09 22:51:07.383	\N	\N	cmgu2gnlx00adqlwc0jmi9uk2	3	2025-10-16 23:44:11.293	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gpb301elqlwcem1smb6i	Following this thread. Great discussion!	2025-10-10 02:38:23.673	\N	\N	cmgu2gnlx00adqlwc0jmi9uk2	44	2025-10-16 23:44:11.295	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gpb501enqlwci47ee3q2	I had the same experience! Thanks for sharing.	2025-09-14 22:50:28.517	\N	\N	cmgu2gnlx00adqlwc0jmi9uk2	17	2025-10-16 23:44:11.298	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gpb801epqlwcvp6c1p9g	Interesting perspective. I never thought about it that way.	2025-09-23 10:37:49.402	\N	\N	cmgu2gnlx00adqlwc0jmi9uk2	8	2025-10-16 23:44:11.3	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gpbf01erqlwcke34podj	Can confirm, this is accurate.	2025-09-24 06:42:23.446	\N	\N	cmgu2gnlz00afqlwczotfwiph	82	2025-10-16 23:44:11.307	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gpbj01etqlwcb6svfi2q	Bookmarking this for later. Excellent content!	2025-09-29 14:15:33.361	\N	\N	cmgu2gnlz00afqlwczotfwiph	34	2025-10-16 23:44:11.311	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gp8h01cvqlwc83hdbicd	Thanks for posting this! Very informative.	2025-09-14 05:05:39.257	\N	\N	cmgu2gnln00a5qlwc8e6zxumw	3	2025-10-16 23:44:11.202	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gp8k01cxqlwcr8hotzf5	This deserves more upvotes!	2025-10-14 14:42:50.911	\N	\N	cmgu2gnln00a5qlwc8e6zxumw	55	2025-10-16 23:44:11.204	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gp8m01czqlwc9ev881dm	Following this thread. Great discussion!	2025-09-30 23:33:35.851	\N	\N	cmgu2gnln00a5qlwc8e6zxumw	4	2025-10-16 23:44:11.207	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gp8p01d1qlwckvjzgctd	Could you elaborate more on this point?	2025-10-13 08:25:24.649	\N	\N	cmgu2gnln00a5qlwc8e6zxumw	39	2025-10-16 23:44:11.209	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gp8u01d3qlwc72bnroj3	Can confirm, this is accurate.	2025-08-24 16:40:09.202	\N	\N	cmgu2gnlq00a7qlwcmnzktsif	76	2025-10-16 23:44:11.214	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gp8w01d5qlwc3rlkvm2x	Following this thread. Great discussion!	2025-08-24 21:51:38.849	\N	\N	cmgu2gnlq00a7qlwcmnzktsif	60	2025-10-16 23:44:11.216	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gp8y01d7qlwcbzy2fczz	This is a game changer. Thank you!	2025-08-12 09:00:11.421	\N	\N	cmgu2gnlq00a7qlwcmnzktsif	48	2025-10-16 23:44:11.219	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gp9101d9qlwcnozvwamy	I disagree, but I respect your opinion.	2025-09-17 21:11:08.257	\N	\N	cmgu2gnlq00a7qlwcmnzktsif	80	2025-10-16 23:44:11.221	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gp9301dbqlwcgofhmwri	Bookmarking this for later. Excellent content!	2025-09-05 00:47:18.161	\N	\N	cmgu2gnlq00a7qlwcmnzktsif	64	2025-10-16 23:44:11.223	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gp9601ddqlwcmkdj8kwg	Curia et absum torqueo dolore torrens. Articulus conduco utique. Molestiae possimus arguo velociter agnitio stella.	2025-10-16 01:42:51.22	\N	\N	cmgu2gnlq00a7qlwcmnzktsif	13	2025-10-16 23:44:11.227	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gp9901dfqlwcxl3796d8	I had the same experience! Thanks for sharing.	2025-10-04 21:27:41.315	\N	\N	cmgu2gnlq00a7qlwcmnzktsif	37	2025-10-16 23:44:11.229	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gp9e01dhqlwc2w3c4ng7	What resources would you recommend for learning more?	2025-02-27 12:45:39.053	\N	\N	cmgu2gnls00a9qlwcem9rdm32	95	2025-10-16 23:44:11.234	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gp9g01djqlwcemdzb7r5	Could you elaborate more on this point?	2025-03-21 17:46:42.062	\N	\N	cmgu2gnls00a9qlwcem9rdm32	60	2025-10-16 23:44:11.237	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gp9i01dlqlwc09g50q5k	Tabula ultra toties capitulus spargo adimpleo stultus. Sumo testimonium velit. Creta conforto vociferor surculus testimonium articulus amaritudo cribro amoveo spargo.	2025-02-14 10:49:26.496	\N	\N	cmgu2gnls00a9qlwcem9rdm32	93	2025-10-16 23:44:11.239	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gp9l01dnqlwcxbht1ity	Update: I tried this and it worked perfectly!	2025-03-15 16:15:20.002	\N	\N	cmgu2gnls00a9qlwcem9rdm32	89	2025-10-16 23:44:11.241	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gp9n01dpqlwc04pxg6p8	This deserves more upvotes!	2025-02-20 20:21:09.59	\N	\N	cmgu2gnls00a9qlwcem9rdm32	98	2025-10-16 23:44:11.244	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gp9q01drqlwcbubxznbx	Interesting perspective. I never thought about it that way.	2025-07-21 22:23:08.117	\N	\N	cmgu2gnls00a9qlwcem9rdm32	24	2025-10-16 23:44:11.246	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gp9s01dtqlwc81t9do11	Can confirm, this is accurate.	2025-02-08 10:40:18.203	\N	\N	cmgu2gnls00a9qlwcem9rdm32	66	2025-10-16 23:44:11.248	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gp9v01dvqlwcmhygvht1	This is a game changer. Thank you!	2025-06-11 00:40:22.228	\N	\N	cmgu2gnls00a9qlwcem9rdm32	94	2025-10-16 23:44:11.252	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gp9y01dxqlwc0nixt675	This is exactly what I needed. Saved!	2025-05-01 03:11:42.519	\N	\N	cmgu2gnls00a9qlwcem9rdm32	46	2025-10-16 23:44:11.254	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gpa101dzqlwcdrj682f4	Articulus ex a. Vulpes attero itaque utor officiis. Tertius comburo trado dolorum summisse.	2025-01-30 19:09:00.583	\N	\N	cmgu2gnls00a9qlwcem9rdm32	21	2025-10-16 23:44:11.257	cmgu2gn5s0007qlwcjhhzi8m9	0	0	0
cmgu2gpbn01evqlwcweo6l7w1	Great post! Really helpful information.	2025-09-24 12:41:21.858	\N	\N	cmgu2gnlz00afqlwczotfwiph	47	2025-10-16 23:44:11.315	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gpbq01exqlwc62kw7stn	Bookmarking this for later. Excellent content!	2025-09-23 07:28:47.928	\N	\N	cmgu2gnlz00afqlwczotfwiph	47	2025-10-16 23:44:11.318	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gpbs01ezqlwcy2f2lhdd	This is exactly what I needed. Saved!	2025-10-06 22:43:15.674	\N	\N	cmgu2gnlz00afqlwczotfwiph	72	2025-10-16 23:44:11.321	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gpbx01f1qlwc9yaba26b	Thanks for posting this! Very informative.	2025-07-23 04:39:53.747	\N	\N	cmgu2gnm100ahqlwckvill1c9	28	2025-10-16 23:44:11.326	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gpbz01f3qlwc1mqq7hnf	This is a game changer. Thank you!	2025-08-16 03:00:18.183	\N	\N	cmgu2gnm100ahqlwckvill1c9	2	2025-10-16 23:44:11.328	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gpc201f5qlwcqqky6vq5	Addo demonstro venustas. Barba vulgus tepidus avarus tepesco torqueo saepe. Sono testimonium adflicto vitium defluo denuo angelus.	2025-07-29 08:28:34.88	\N	\N	cmgu2gnm100ahqlwckvill1c9	44	2025-10-16 23:44:11.331	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gpc501f7qlwca26kxylz	I've been doing this for years and can vouch for it.	2025-08-23 08:59:36.17	\N	\N	cmgu2gnm100ahqlwckvill1c9	95	2025-10-16 23:44:11.333	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gpc701f9qlwcdpbsv4qx	Update: I tried this and it worked perfectly!	2025-09-29 03:30:09.981	\N	\N	cmgu2gnm100ahqlwckvill1c9	67	2025-10-16 23:44:11.336	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gpca01fbqlwct5d48mxh	Could you elaborate more on this point?	2025-08-08 10:55:13.553	\N	\N	cmgu2gnm100ahqlwckvill1c9	51	2025-10-16 23:44:11.338	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gpcc01fdqlwc6q94vfgc	This is exactly what I needed. Saved!	2025-09-20 03:54:01.139	\N	\N	cmgu2gnm100ahqlwckvill1c9	39	2025-10-16 23:44:11.34	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gpce01ffqlwcia5jx07q	Following this thread. Great discussion!	2025-10-15 23:30:50.262	\N	\N	cmgu2gnm100ahqlwckvill1c9	6	2025-10-16 23:44:11.342	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gpcg01fhqlwci35t589g	Update: I tried this and it worked perfectly!	2025-09-21 16:48:27.763	\N	\N	cmgu2gnm100ahqlwckvill1c9	97	2025-10-16 23:44:11.345	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gpcl01fjqlwczhuxnv6n	Update: I tried this and it worked perfectly!	2025-06-12 05:08:12.085	\N	\N	cmgu2gnm400ajqlwc5sfuue6y	56	2025-10-16 23:44:11.35	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gpco01flqlwco10wqwck	I've been doing this for years and can vouch for it.	2025-06-02 06:57:06.45	\N	\N	cmgu2gnm400ajqlwc5sfuue6y	20	2025-10-16 23:44:11.352	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gpcq01fnqlwc7kzudcde	Accedo ambitus caute ara. Tendo vapulus consequatur. Volup cervus tego.	2025-09-03 13:15:25.388	\N	\N	cmgu2gnm400ajqlwc5sfuue6y	3	2025-10-16 23:44:11.354	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gpct01fpqlwcfvt7ko4e	Great post! Really helpful information.	2025-06-19 11:33:18.948	\N	\N	cmgu2gnm400ajqlwc5sfuue6y	85	2025-10-16 23:44:11.358	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gpcw01frqlwcfbfpopxz	Doloribus repudiandae comitatus. Sed vulariter comis verbum. Stabilis voro comes animadverto voluptate rerum.	2025-08-28 19:19:06.795	\N	\N	cmgu2gnm400ajqlwc5sfuue6y	-3	2025-10-16 23:44:11.36	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gpd101ftqlwcg970n88d	Following this thread. Great discussion!	2025-08-24 03:13:03.322	\N	\N	cmgu2gnm600alqlwckfvyri83	97	2025-10-16 23:44:11.366	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gpd401fvqlwcyp7m1pzl	Update: I tried this and it worked perfectly!	2025-07-23 19:16:18.868	\N	\N	cmgu2gnm600alqlwckfvyri83	52	2025-10-16 23:44:11.368	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gpd601fxqlwc87pr5pe6	Bookmarking this for later. Excellent content!	2025-09-22 06:12:26.215	\N	\N	cmgu2gnm600alqlwckfvyri83	49	2025-10-16 23:44:11.37	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gpd801fzqlwctuo7dn9c	Interesting perspective. I never thought about it that way.	2025-10-08 19:16:51.001	\N	\N	cmgu2gnm600alqlwckfvyri83	45	2025-10-16 23:44:11.373	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gpdb01g1qlwct0a9607u	Could you elaborate more on this point?	2025-09-13 03:53:20.742	\N	\N	cmgu2gnm600alqlwckfvyri83	74	2025-10-16 23:44:11.376	cmgu2gn4v0003qlwcugkrmdpr	0	0	0
cmgu2gpdd01g3qlwc1xbdgk30	Could you elaborate more on this point?	2025-07-25 07:02:23.666	\N	\N	cmgu2gnm600alqlwckfvyri83	17	2025-10-16 23:44:11.378	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gpdg01g5qlwcjvnb02dz	Deficio currus tonsor vel vobis ascisco benigne quo trado thermae. Conventus vulgo maxime. Commodo vulnus stabilis crepusculum.	2025-07-18 23:54:57.982	\N	\N	cmgu2gnm600alqlwckfvyri83	45	2025-10-16 23:44:11.38	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gpdi01g7qlwc5xibjulz	Update: I tried this and it worked perfectly!	2025-10-15 11:57:22.818	\N	\N	cmgu2gnm600alqlwckfvyri83	58	2025-10-16 23:44:11.382	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gpdk01g9qlwct8sbstgm	Thanks for posting this! Very informative.	2025-07-25 10:17:14.593	\N	\N	cmgu2gnm600alqlwckfvyri83	43	2025-10-16 23:44:11.384	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gpdm01gbqlwc83axhcn6	I had the same experience! Thanks for sharing.	2025-08-29 20:43:42.7	\N	\N	cmgu2gnm600alqlwckfvyri83	4	2025-10-16 23:44:11.387	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gpdr01gdqlwc7n3ug4sl	Update: I tried this and it worked perfectly!	2025-10-14 15:32:45.063	\N	\N	cmgu2gnm800anqlwccqm3mxb6	92	2025-10-16 23:44:11.392	cmgu2gn4k0001qlwc2fpdaslv	0	0	0
cmgu2gpdu01gfqlwc9956eitw	I've been doing this for years and can vouch for it.	2025-08-15 14:12:11.512	\N	\N	cmgu2gnm800anqlwccqm3mxb6	11	2025-10-16 23:44:11.394	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gpdw01ghqlwct9bjd99n	Thanks for posting this! Very informative.	2025-01-02 10:25:54.842	\N	\N	cmgu2gnm800anqlwccqm3mxb6	48	2025-10-16 23:44:11.396	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gpdy01gjqlwcmn88gms2	I had the same experience! Thanks for sharing.	2025-07-15 15:54:40.261	\N	\N	cmgu2gnm800anqlwccqm3mxb6	10	2025-10-16 23:44:11.398	cmgu2gn620009qlwcdnj97s63	0	0	0
cmgu2gpe001glqlwcs3rrtlh5	Could you elaborate more on this point?	2025-02-15 21:45:06.007	\N	\N	cmgu2gnm800anqlwccqm3mxb6	36	2025-10-16 23:44:11.401	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gpe501gnqlwct1a3kquw	Bookmarking this for later. Excellent content!	2025-06-15 15:11:17.916	\N	\N	cmgu2gnm800anqlwccqm3mxb6	84	2025-10-16 23:44:11.405	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gpe701gpqlwc4kfydxn2	Thanks for posting this! Very informative.	2025-07-14 13:02:39.132	\N	\N	cmgu2gnm800anqlwccqm3mxb6	12	2025-10-16 23:44:11.408	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gpea01grqlwcvg74ffeh	I had the same experience! Thanks for sharing.	2025-01-10 18:49:57.741	\N	\N	cmgu2gnm800anqlwccqm3mxb6	76	2025-10-16 23:44:11.41	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gpeh01gtqlwcok395oct	Can confirm, this is accurate.	2025-09-06 20:24:42.95	\N	\N	cmgu2gnmb00apqlwc1jlv03ic	54	2025-10-16 23:44:11.417	cmgu2gn500004qlwcjxvp6xez	0	0	0
cmgu2gpej01gvqlwc44wmbhax	This is exactly what I needed. Saved!	2025-06-12 08:46:32.377	\N	\N	cmgu2gnmb00apqlwc1jlv03ic	27	2025-10-16 23:44:11.419	cmgu2gn5x0008qlwc51j7cb44	0	0	0
cmgu2gpel01gxqlwcigzyozbt	I've been doing this for years and can vouch for it.	2025-04-09 00:49:57.827	\N	\N	cmgu2gnmb00apqlwc1jlv03ic	0	2025-10-16 23:44:11.422	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gpeo01gzqlwcdxu27myj	Interesting perspective. I never thought about it that way.	2025-05-14 22:25:13.579	\N	\N	cmgu2gnmb00apqlwc1jlv03ic	49	2025-10-16 23:44:11.424	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gpeq01h1qlwcmoidtsxk	Great post! Really helpful information.	2024-12-26 03:03:38.458	\N	\N	cmgu2gnmb00apqlwc1jlv03ic	33	2025-10-16 23:44:11.426	cmgu2gn5f0005qlwcdx8tb0kd	0	0	0
cmgu2gpes01h3qlwc7cndaqnq	Great post! Really helpful information.	2025-06-19 14:48:01.883	\N	\N	cmgu2gnmb00apqlwc1jlv03ic	49	2025-10-16 23:44:11.429	cmgu2gn5n0006qlwcqfu7g12g	0	0	0
cmgu2gpeu01h5qlwct7le2fmu	Bookmarking this for later. Excellent content!	2024-12-17 03:53:22.406	\N	\N	cmgu2gnmb00apqlwc1jlv03ic	90	2025-10-16 23:44:11.431	cmgu2gn4p0002qlwc80wfogfe	0	0	0
cmgu2gpex01h7qlwc1l54za7u	Vulnus delicate curso vulgo vorago est defetiscor tergo crustulum. Vox desino sublime doloribus commemoro aureus turbo. Sequi bestia tabula tollo circumvenio torqueo.	2025-07-06 11:11:30.603	\N	\N	cmgu2gnmb00apqlwc1jlv03ic	33	2025-10-16 23:44:11.433	cmgu2gn420000qlwcc82uc6sp	0	0	0
cmgu2gpez01h9qlwcbtpsidpv	Bookmarking this for later. Excellent content!	2025-09-15 13:31:30.071	\N	\N	cmgu2gnmb00apqlwc1jlv03ic	78	2025-10-16 23:44:11.435	cmgu2gn5x0008qlwc51j7cb44	0	0	0
\.


--
-- Data for Name: Community; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Community" (id, name, description, banner, "createdAt", "displayName", icon, "isNsfw", "isPublic", "memberCount", rules, "updatedAt") FROM stdin;
cmgu2gn66000aqlwcxvsqs7z0	science	Scientific discoveries and discussions	https://loremflickr.com/640/480/science?lock=187008236388352	2025-10-16 23:44:08.527	🔬 Science	https://api.dicebear.com/7.x/shapes/svg?seed=science	f	f	5	"[{\\"id\\":1,\\"title\\":\\"Be respectful\\",\\"description\\":\\"Treat others with respect\\"},{\\"id\\":2,\\"title\\":\\"No spam\\",\\"description\\":\\"Quality content only\\"},{\\"id\\":3,\\"title\\":\\"Stay on topic\\",\\"description\\":\\"Keep posts relevant to the community\\"}]"	2025-10-16 23:44:08.617
cmgu2gn6b000bqlwcmdrkh4ll	fitness	Workout tips, nutrition, and wellness	https://loremflickr.com/640/480/fitness?lock=7047327667716096	2025-10-16 23:44:08.531	💪 Fitness & Health	https://api.dicebear.com/7.x/shapes/svg?seed=fitness	f	t	9	"[{\\"id\\":1,\\"title\\":\\"Be respectful\\",\\"description\\":\\"Treat others with respect\\"},{\\"id\\":2,\\"title\\":\\"No spam\\",\\"description\\":\\"Quality content only\\"},{\\"id\\":3,\\"title\\":\\"Stay on topic\\",\\"description\\":\\"Keep posts relevant to the community\\"}]"	2025-10-16 23:44:08.645
cmgu2gn6h000dqlwcumqoxnq3	music	Music discussion, sharing, and discovery	https://loremflickr.com/640/480/music?lock=7257368515575808	2025-10-16 23:44:08.537	🎵 Music	https://api.dicebear.com/7.x/shapes/svg?seed=music	f	t	10	"[{\\"id\\":1,\\"title\\":\\"Be respectful\\",\\"description\\":\\"Treat others with respect\\"},{\\"id\\":2,\\"title\\":\\"No spam\\",\\"description\\":\\"Quality content only\\"},{\\"id\\":3,\\"title\\":\\"Stay on topic\\",\\"description\\":\\"Keep posts relevant to the community\\"}]"	2025-10-16 23:44:08.697
cmgu2gn7b000eqlwct6d6k946	movies	Film discussions, reviews, and recommendations	https://loremflickr.com/640/480/movies?lock=6505527435591680	2025-10-16 23:44:08.54	🎬 Movies & TV	https://api.dicebear.com/7.x/shapes/svg?seed=movies	f	t	10	"[{\\"id\\":1,\\"title\\":\\"Be respectful\\",\\"description\\":\\"Treat others with respect\\"},{\\"id\\":2,\\"title\\":\\"No spam\\",\\"description\\":\\"Quality content only\\"},{\\"id\\":3,\\"title\\":\\"Stay on topic\\",\\"description\\":\\"Keep posts relevant to the community\\"}]"	2025-10-16 23:44:08.725
cmgu2gn7m000gqlwctzte3k6i	art	Digital art, design, and creative work	https://loremflickr.com/640/480/art?lock=2470864972939264	2025-10-16 23:44:08.578	🎨 Art & Design	https://api.dicebear.com/7.x/shapes/svg?seed=art	f	f	9	"[{\\"id\\":1,\\"title\\":\\"Be respectful\\",\\"description\\":\\"Treat others with respect\\"},{\\"id\\":2,\\"title\\":\\"No spam\\",\\"description\\":\\"Quality content only\\"},{\\"id\\":3,\\"title\\":\\"Stay on topic\\",\\"description\\":\\"Keep posts relevant to the community\\"}]"	2025-10-16 23:44:08.774
cmgu2gn7r000hqlwc70v2wi8q	books	Book clubs, reviews, and literary discussions	https://loremflickr.com/640/480/books?lock=8704448979271680	2025-10-16 23:44:08.584	📚 Books & Reading	https://api.dicebear.com/7.x/shapes/svg?seed=books	f	t	9	"[{\\"id\\":1,\\"title\\":\\"Be respectful\\",\\"description\\":\\"Treat others with respect\\"},{\\"id\\":2,\\"title\\":\\"No spam\\",\\"description\\":\\"Quality content only\\"},{\\"id\\":3,\\"title\\":\\"Stay on topic\\",\\"description\\":\\"Keep posts relevant to the community\\"}]"	2025-10-16 23:44:08.796
cmgu2gn7y000jqlwc50ywgwgj	crypto	Crypto trading, blockchain, and Web3	https://loremflickr.com/640/480/crypto?lock=3912241883643904	2025-10-16 23:44:08.591	₿ Cryptocurrency	https://api.dicebear.com/7.x/shapes/svg?seed=crypto	f	t	6	"[{\\"id\\":1,\\"title\\":\\"Be respectful\\",\\"description\\":\\"Treat others with respect\\"},{\\"id\\":2,\\"title\\":\\"No spam\\",\\"description\\":\\"Quality content only\\"},{\\"id\\":3,\\"title\\":\\"Stay on topic\\",\\"description\\":\\"Keep posts relevant to the community\\"}]"	2025-10-16 23:44:08.83
cmgu2gn7u000iqlwc99a2xdcm	gaming	Video games, esports, and gaming culture	https://loremflickr.com/640/480/gaming?lock=7755204837507072	2025-10-16 23:44:08.587	🎮 Gaming	https://api.dicebear.com/7.x/shapes/svg?seed=gaming	f	t	8	"[{\\"id\\":1,\\"title\\":\\"Be respectful\\",\\"description\\":\\"Treat others with respect\\"},{\\"id\\":2,\\"title\\":\\"No spam\\",\\"description\\":\\"Quality content only\\"},{\\"id\\":3,\\"title\\":\\"Stay on topic\\",\\"description\\":\\"Keep posts relevant to the community\\"}]"	2025-10-18 00:24:38.681
cmgu2gn7g000fqlwcjl9oszqf	coding	Code, development, and software engineering	https://loremflickr.com/640/480/coding?lock=4179682626895872	2025-10-16 23:44:08.573	⌨️ Programming	https://api.dicebear.com/7.x/shapes/svg?seed=coding	f	t	11	"[{\\"id\\":1,\\"title\\":\\"Be respectful\\",\\"description\\":\\"Treat others with respect\\"},{\\"id\\":2,\\"title\\":\\"No spam\\",\\"description\\":\\"Quality content only\\"},{\\"id\\":3,\\"title\\":\\"Stay on topic\\",\\"description\\":\\"Keep posts relevant to the community\\"}]"	2025-10-18 00:26:50.727
cmgu2gn6e000cqlwcn2qhrb5b	technology	All things tech, gadgets, and innovation	https://loremflickr.com/640/480/technology?lock=4501543124467712	2025-10-16 23:44:08.534	💻 Technology	https://api.dicebear.com/7.x/shapes/svg?seed=technology	f	t	9	"[{\\"id\\":1,\\"title\\":\\"Be respectful\\",\\"description\\":\\"Treat others with respect\\"},{\\"id\\":2,\\"title\\":\\"No spam\\",\\"description\\":\\"Quality content only\\"},{\\"id\\":3,\\"title\\":\\"Stay on topic\\",\\"description\\":\\"Keep posts relevant to the community\\"}]"	2025-10-18 05:29:39.864
\.


--
-- Data for Name: CommunityBadge; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."CommunityBadge" (id, "serverId", "communityId", "collectionId", name, description, image, requirements, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CommunityMember; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."CommunityMember" (id, "communityId", "userId", karma, "joinedAt") FROM stdin;
cmgu2gn82000lqlwc8shkaowu	cmgu2gn66000aqlwcxvsqs7z0	cmgu2gn4v0003qlwcugkrmdpr	0	2025-04-04 01:56:22.448
cmgu2gn8d000nqlwc0pjwwmok	cmgu2gn66000aqlwcxvsqs7z0	cmgu2gn420000qlwcc82uc6sp	0	2025-05-25 20:32:03.871
cmgu2gn8g000pqlwc5hs3ard8	cmgu2gn66000aqlwcxvsqs7z0	cmgu2gn620009qlwcdnj97s63	0	2025-05-15 04:57:57.484
cmgu2gn8j000rqlwccwtdooa6	cmgu2gn66000aqlwcxvsqs7z0	cmgu2gn5n0006qlwcqfu7g12g	0	2024-12-24 06:26:57.02
cmgu2gn8l000tqlwc87h14sot	cmgu2gn66000aqlwcxvsqs7z0	cmgu2gn5f0005qlwcdx8tb0kd	0	2024-12-05 22:48:39.502
cmgu2gn8u000vqlwcxwp9cj1u	cmgu2gn6b000bqlwcmdrkh4ll	cmgu2gn4k0001qlwc2fpdaslv	0	2024-11-12 12:07:02.252
cmgu2gn8x000xqlwcp2mnw2rd	cmgu2gn6b000bqlwcmdrkh4ll	cmgu2gn620009qlwcdnj97s63	0	2024-12-10 22:33:56.488
cmgu2gn8z000zqlwc2bscy23z	cmgu2gn6b000bqlwcmdrkh4ll	cmgu2gn4p0002qlwc80wfogfe	0	2024-10-17 02:40:39.568
cmgu2gn920011qlwcuf4j9stj	cmgu2gn6b000bqlwcmdrkh4ll	cmgu2gn5f0005qlwcdx8tb0kd	0	2025-03-13 04:33:09.383
cmgu2gn940013qlwcq230zrwf	cmgu2gn6b000bqlwcmdrkh4ll	cmgu2gn4v0003qlwcugkrmdpr	0	2025-05-06 02:27:47.216
cmgu2gn960015qlwcffdcgztn	cmgu2gn6b000bqlwcmdrkh4ll	cmgu2gn500004qlwcjxvp6xez	0	2025-01-19 19:28:28.924
cmgu2gn990017qlwc6fptehvy	cmgu2gn6b000bqlwcmdrkh4ll	cmgu2gn5s0007qlwcjhhzi8m9	0	2025-01-29 14:04:26.548
cmgu2gn9b0019qlwchky1inrt	cmgu2gn6b000bqlwcmdrkh4ll	cmgu2gn5x0008qlwc51j7cb44	0	2025-08-20 08:05:01.282
cmgu2gn9d001bqlwcovhgzoys	cmgu2gn6b000bqlwcmdrkh4ll	cmgu2gn420000qlwcc82uc6sp	0	2025-05-22 05:10:59.003
cmgu2gn9j001dqlwcwcngzv9c	cmgu2gn6e000cqlwcn2qhrb5b	cmgu2gn500004qlwcjxvp6xez	0	2025-01-04 09:48:38.121
cmgu2gn9m001fqlwc4myn5p8l	cmgu2gn6e000cqlwcn2qhrb5b	cmgu2gn5f0005qlwcdx8tb0kd	0	2025-07-26 16:54:52.549
cmgu2gn9o001hqlwcyj0mlmlu	cmgu2gn6e000cqlwcn2qhrb5b	cmgu2gn4p0002qlwc80wfogfe	0	2025-05-15 07:54:50.1
cmgu2gn9q001jqlwcvq1spaxw	cmgu2gn6e000cqlwcn2qhrb5b	cmgu2gn420000qlwcc82uc6sp	0	2025-07-04 03:41:20.259
cmgu2gn9s001lqlwcbw73m0cx	cmgu2gn6e000cqlwcn2qhrb5b	cmgu2gn4k0001qlwc2fpdaslv	0	2025-02-03 15:04:21.998
cmgu2gn9u001nqlwc5qmhubub	cmgu2gn6e000cqlwcn2qhrb5b	cmgu2gn5s0007qlwcjhhzi8m9	0	2025-04-09 20:01:14.747
cmgu2gn9w001pqlwcmqjrcvua	cmgu2gn6e000cqlwcn2qhrb5b	cmgu2gn5x0008qlwc51j7cb44	0	2025-02-23 01:07:04.69
cmgu2gn9y001rqlwca6g7ptpv	cmgu2gn6e000cqlwcn2qhrb5b	cmgu2gn5n0006qlwcqfu7g12g	0	2024-12-08 23:37:50.945
cmgu2gna3001tqlwcu3xjbzrh	cmgu2gn6h000dqlwcumqoxnq3	cmgu2gn500004qlwcjxvp6xez	0	2025-04-05 12:34:45.358
cmgu2gna5001vqlwclxbc5x4t	cmgu2gn6h000dqlwcumqoxnq3	cmgu2gn620009qlwcdnj97s63	0	2025-01-14 14:18:10.193
cmgu2gna7001xqlwcqng1t5fi	cmgu2gn6h000dqlwcumqoxnq3	cmgu2gn4p0002qlwc80wfogfe	0	2025-01-22 17:44:30.871
cmgu2gna9001zqlwchj3zm7lg	cmgu2gn6h000dqlwcumqoxnq3	cmgu2gn5x0008qlwc51j7cb44	0	2024-12-08 18:54:12.121
cmgu2gnab0021qlwcrb5vwdtc	cmgu2gn6h000dqlwcumqoxnq3	cmgu2gn5s0007qlwcjhhzi8m9	0	2024-11-07 22:29:22.655
cmgu2gnah0023qlwcqs0edlky	cmgu2gn6h000dqlwcumqoxnq3	cmgu2gn4v0003qlwcugkrmdpr	0	2025-05-28 04:58:56.968
cmgu2gnak0025qlwczubf6f68	cmgu2gn6h000dqlwcumqoxnq3	cmgu2gn5f0005qlwcdx8tb0kd	0	2025-04-16 22:45:21.999
cmgu2gnao0027qlwcv3t8bpmx	cmgu2gn6h000dqlwcumqoxnq3	cmgu2gn5n0006qlwcqfu7g12g	0	2025-02-19 17:55:24.999
cmgu2gnas0029qlwcg54y7v7p	cmgu2gn6h000dqlwcumqoxnq3	cmgu2gn4k0001qlwc2fpdaslv	0	2025-03-06 22:00:28.787
cmgu2gnav002bqlwcwdc104iz	cmgu2gn6h000dqlwcumqoxnq3	cmgu2gn420000qlwcc82uc6sp	0	2025-05-16 20:21:47.36
cmgu2gnb1002dqlwcr2jpfid7	cmgu2gn7b000eqlwct6d6k946	cmgu2gn4k0001qlwc2fpdaslv	0	2025-03-26 04:18:49.659
cmgu2gnb5002fqlwcyu40xtrm	cmgu2gn7b000eqlwct6d6k946	cmgu2gn420000qlwcc82uc6sp	0	2025-01-27 06:53:43.532
cmgu2gnb8002hqlwcy5j5gacc	cmgu2gn7b000eqlwct6d6k946	cmgu2gn4p0002qlwc80wfogfe	0	2025-07-20 04:32:04.826
cmgu2gnba002jqlwc9j3i6fw4	cmgu2gn7b000eqlwct6d6k946	cmgu2gn500004qlwcjxvp6xez	0	2025-05-30 00:34:46.111
cmgu2gnbc002lqlwcfb04els1	cmgu2gn7b000eqlwct6d6k946	cmgu2gn4v0003qlwcugkrmdpr	0	2025-05-06 08:02:21.717
cmgu2gnbe002nqlwcpq2ghoya	cmgu2gn7b000eqlwct6d6k946	cmgu2gn5f0005qlwcdx8tb0kd	0	2025-03-02 16:16:14.725
cmgu2gnbh002pqlwcc4n0ndhv	cmgu2gn7b000eqlwct6d6k946	cmgu2gn5s0007qlwcjhhzi8m9	0	2025-05-09 12:29:51.954
cmgu2gnbj002rqlwcrw1iyc6v	cmgu2gn7b000eqlwct6d6k946	cmgu2gn5x0008qlwc51j7cb44	0	2025-08-25 23:09:50.272
cmgu2gnbl002tqlwcfwge76ls	cmgu2gn7b000eqlwct6d6k946	cmgu2gn5n0006qlwcqfu7g12g	0	2024-12-22 16:00:36.51
cmgu2gnbn002vqlwc8ig8xwr9	cmgu2gn7b000eqlwct6d6k946	cmgu2gn620009qlwcdnj97s63	0	2025-10-06 08:37:38.156
cmgu2gnbr002xqlwccxemynmu	cmgu2gn7g000fqlwcjl9oszqf	cmgu2gn620009qlwcdnj97s63	0	2025-08-11 09:47:08.958
cmgu2gnbt002zqlwcgtmkc4vo	cmgu2gn7g000fqlwcjl9oszqf	cmgu2gn5f0005qlwcdx8tb0kd	0	2025-01-31 16:26:15.947
cmgu2gnbv0031qlwcg7m52bsa	cmgu2gn7g000fqlwcjl9oszqf	cmgu2gn4p0002qlwc80wfogfe	0	2024-11-29 00:53:05.084
cmgu2gnbx0033qlwc9juhac6s	cmgu2gn7g000fqlwcjl9oszqf	cmgu2gn4k0001qlwc2fpdaslv	0	2025-10-16 12:48:58.608
cmgu2gnc00035qlwcf4647oop	cmgu2gn7g000fqlwcjl9oszqf	cmgu2gn5x0008qlwc51j7cb44	0	2025-05-31 22:42:47.536
cmgu2gnc20037qlwc929ybyte	cmgu2gn7g000fqlwcjl9oszqf	cmgu2gn500004qlwcjxvp6xez	0	2025-04-30 22:50:26.726
cmgu2gnc40039qlwc8he2s3r8	cmgu2gn7g000fqlwcjl9oszqf	cmgu2gn4v0003qlwcugkrmdpr	0	2025-08-27 00:05:37.247
cmgu2gnc7003bqlwcwafnrjo8	cmgu2gn7g000fqlwcjl9oszqf	cmgu2gn5n0006qlwcqfu7g12g	0	2025-10-10 06:05:09.177
cmgu2gnc9003dqlwc0fww9vpb	cmgu2gn7g000fqlwcjl9oszqf	cmgu2gn5s0007qlwcjhhzi8m9	0	2025-03-09 01:50:10.16
cmgu2gncb003fqlwcn9lbqjyl	cmgu2gn7g000fqlwcjl9oszqf	cmgu2gn420000qlwcc82uc6sp	0	2025-06-21 17:18:08.041
cmgu2gncg003hqlwcgg7ovym7	cmgu2gn7m000gqlwctzte3k6i	cmgu2gn4v0003qlwcugkrmdpr	0	2025-10-15 00:17:47.497
cmgu2gnci003jqlwcs8n04jy6	cmgu2gn7m000gqlwctzte3k6i	cmgu2gn5n0006qlwcqfu7g12g	0	2025-10-07 08:11:51.582
cmgu2gncl003lqlwchfepkbze	cmgu2gn7m000gqlwctzte3k6i	cmgu2gn5s0007qlwcjhhzi8m9	0	2025-04-10 02:03:08.122
cmgu2gncn003nqlwc4v57dztu	cmgu2gn7m000gqlwctzte3k6i	cmgu2gn4p0002qlwc80wfogfe	0	2024-10-18 09:45:46.863
cmgu2gncp003pqlwcpet8mhn4	cmgu2gn7m000gqlwctzte3k6i	cmgu2gn5x0008qlwc51j7cb44	0	2024-11-20 07:53:06.898
cmgu2gncs003rqlwcsrgtqz9q	cmgu2gn7m000gqlwctzte3k6i	cmgu2gn4k0001qlwc2fpdaslv	0	2025-06-20 23:49:14.661
cmgu2gncu003tqlwcpy0m714d	cmgu2gn7m000gqlwctzte3k6i	cmgu2gn620009qlwcdnj97s63	0	2025-04-17 19:07:20.65
cmgu2gncw003vqlwc8yspoebr	cmgu2gn7m000gqlwctzte3k6i	cmgu2gn500004qlwcjxvp6xez	0	2024-12-07 08:13:55.967
cmgu2gncz003xqlwcyohn64hr	cmgu2gn7m000gqlwctzte3k6i	cmgu2gn420000qlwcc82uc6sp	0	2025-07-27 03:28:10.815
cmgu2gnd4003zqlwct0rd2xb7	cmgu2gn7r000hqlwc70v2wi8q	cmgu2gn420000qlwcc82uc6sp	0	2025-01-21 14:22:26.464
cmgu2gnd60041qlwcwi77jnk8	cmgu2gn7r000hqlwc70v2wi8q	cmgu2gn620009qlwcdnj97s63	0	2025-01-29 13:29:49.321
cmgu2gnd80043qlwcswx4ouo1	cmgu2gn7r000hqlwc70v2wi8q	cmgu2gn5x0008qlwc51j7cb44	0	2025-07-27 16:43:16.078
cmgu2gnda0045qlwciaawbbg4	cmgu2gn7r000hqlwc70v2wi8q	cmgu2gn4k0001qlwc2fpdaslv	0	2025-06-12 00:20:01.716
cmgu2gndc0047qlwc672uwbm0	cmgu2gn7r000hqlwc70v2wi8q	cmgu2gn5s0007qlwcjhhzi8m9	0	2025-02-04 05:43:49.919
cmgu2gndf0049qlwcr2wuvp1l	cmgu2gn7r000hqlwc70v2wi8q	cmgu2gn4v0003qlwcugkrmdpr	0	2025-04-15 12:48:49.294
cmgu2gndh004bqlwcd7mbxowe	cmgu2gn7r000hqlwc70v2wi8q	cmgu2gn5n0006qlwcqfu7g12g	0	2024-11-21 22:28:08.566
cmgu2gndj004dqlwc0f0da012	cmgu2gn7r000hqlwc70v2wi8q	cmgu2gn5f0005qlwcdx8tb0kd	0	2025-09-23 19:47:39.248
cmgu2gndl004fqlwc6c5brirk	cmgu2gn7r000hqlwc70v2wi8q	cmgu2gn4p0002qlwc80wfogfe	0	2025-05-20 13:36:45.558
cmgu2gndq004hqlwchfb9nkik	cmgu2gn7u000iqlwc99a2xdcm	cmgu2gn5s0007qlwcjhhzi8m9	0	2025-05-19 03:33:01.791
cmgu2gnds004jqlwc6lwhyz88	cmgu2gn7u000iqlwc99a2xdcm	cmgu2gn5n0006qlwcqfu7g12g	0	2025-07-28 03:49:07.454
cmgu2gndu004lqlwc09706v69	cmgu2gn7u000iqlwc99a2xdcm	cmgu2gn4v0003qlwcugkrmdpr	0	2025-05-27 03:34:54.037
cmgu2gndw004nqlwcicxql211	cmgu2gn7u000iqlwc99a2xdcm	cmgu2gn620009qlwcdnj97s63	0	2025-08-08 09:03:58.732
cmgu2gne0004pqlwcugpa18di	cmgu2gn7u000iqlwc99a2xdcm	cmgu2gn500004qlwcjxvp6xez	0	2025-03-04 15:54:28.768
cmgu2gne3004rqlwceweh9rzq	cmgu2gn7u000iqlwc99a2xdcm	cmgu2gn420000qlwcc82uc6sp	0	2025-04-01 20:36:52.509
cmgu2gne5004tqlwcwwm7r4j9	cmgu2gn7u000iqlwc99a2xdcm	cmgu2gn4p0002qlwc80wfogfe	0	2024-12-31 08:59:26.657
cmgu2gne9004vqlwck6hb3cb8	cmgu2gn7y000jqlwc50ywgwgj	cmgu2gn5n0006qlwcqfu7g12g	0	2024-12-17 01:03:00.018
cmgu2gneb004xqlwcgifict0f	cmgu2gn7y000jqlwc50ywgwgj	cmgu2gn500004qlwcjxvp6xez	0	2024-10-17 12:05:49.066
cmgu2gned004zqlwcxt089cym	cmgu2gn7y000jqlwc50ywgwgj	cmgu2gn4k0001qlwc2fpdaslv	0	2025-02-10 15:13:53.498
cmgu2gnef0051qlwc4otm2eb1	cmgu2gn7y000jqlwc50ywgwgj	cmgu2gn4p0002qlwc80wfogfe	0	2025-03-06 19:07:01.805
cmgu2gneh0053qlwc3jq1la43	cmgu2gn7y000jqlwc50ywgwgj	cmgu2gn5x0008qlwc51j7cb44	0	2025-01-05 12:00:33.747
cmgu2gnej0055qlwc9aadcvfo	cmgu2gn7y000jqlwc50ywgwgj	cmgu2gn620009qlwcdnj97s63	0	2025-01-21 08:33:12.068
cmgvjckya0002vzb89fvndiv2	cmgu2gn7u000iqlwc99a2xdcm	cmgvj6xwm0000vzb8a21ggzfo	0	2025-10-18 00:24:38.674
cmgvjfeu70002k62dejscx5iw	cmgu2gn7g000fqlwcjl9oszqf	cmgvje2zo0000k62dygaismzy	0	2025-10-18 00:26:50.719
cmgvu8u8h0002kf6c6lalrurn	cmgu2gn6e000cqlwcn2qhrb5b	cmgvqpaza0000kf6cmh62ub5w	0	2025-10-18 05:29:39.857
\.


--
-- Data for Name: CryptoPayment; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."CryptoPayment" (id, "userId", "transactionType", provider, "externalId", status, amount, currency, "usdAmount", "recipientAddress", "txHash", chain, metadata, "webhookData", "createdAt", "updatedAt", "completedAt") FROM stdin;
\.


--
-- Data for Name: CryptoTip; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."CryptoTip" (id, "senderId", "recipientId", "paymentId", amount, currency, "usdAmount", message, "isAnonymous", status, "txHash", "createdAt", "processedAt") FROM stdin;
\.


--
-- Data for Name: DirectMessageParticipant; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."DirectMessageParticipant" (id, "channelId", "userId", "joinedAt", "lastReadMessageId") FROM stdin;
\.


--
-- Data for Name: FileAccessLog; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."FileAccessLog" (id, "fileId", "userId", "accessType", "ipAddress", "userAgent", referrer, country, region, city, "responseTime", "bytesServed", "accessedAt") FROM stdin;
\.


--
-- Data for Name: FileAnalytics; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."FileAnalytics" (id, "fileId", "viewCount", "uniqueViews", "downloadCount", "streamCount", "avgViewDuration", "bounceRate", "shareCount", "avgLoadTime", "bandwidthUsed", "topCountries", "topCities", "hourlyStats", "dailyStats", "monthlyStats", "deviceTypes", browsers, "operatingSystems", "lastCalculated", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: FilePermission; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."FilePermission" (id, "fileId", "isPublic", "allowHotlinking", "requireAuth", "allowedUsers", "allowedRoles", "deniedUsers", "maxDownloads", "downloadCount", "maxDownloadsPerUser", "availableFrom", "availableUntil", "allowedCountries", "deniedCountries", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: FileVariant; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."FileVariant" (id, "fileId", type, format, filename, url, bucket, size, width, height, quality, resolution, bitrate, duration, "createdAt") FROM stdin;
\.


--
-- Data for Name: Flair; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Flair" (id, "communityId", text, "backgroundColor", "textColor") FROM stdin;
\.


--
-- Data for Name: Follow; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Follow" (id, "followerId", "followingId", "createdAt") FROM stdin;
\.


--
-- Data for Name: Friendship; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Friendship" (id, "initiatorId", "receiverId", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: GovernanceProposal; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."GovernanceProposal" (id, "proposerId", title, description, category, status, "votingStartTime", "votingEndTime", quorum, "forVotes", "againstVotes", "abstainVotes", metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: GovernanceVote; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."GovernanceVote" (id, "proposalId", "voterId", "voteType", "votingPower", reason, "txHash", "createdAt") FROM stdin;
\.


--
-- Data for Name: HiddenWord; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."HiddenWord" (id, "userId", word, "createdAt") FROM stdin;
\.


--
-- Data for Name: Invite; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Invite" (id, code, "serverId", "inviterId", uses, "maxUses", "maxAge", temporary, "createdAt", "expiresAt") FROM stdin;
\.


--
-- Data for Name: Like; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Like" (id, "userId", "postId", "commentId", "createdAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceBid; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."MarketplaceBid" (id, "listingId", "bidderId", amount, currency, "usdAmount", status, "expiresAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceListing; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."MarketplaceListing" (id, "sellerId", "nftId", "collectionId", price, currency, "usdPrice", "listingType", status, "startTime", "endTime", "minBidIncrement", "reservePrice", metadata, views, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: MarketplaceSale; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."MarketplaceSale" (id, "listingId", "buyerId", "sellerId", "nftId", "salePrice", currency, "usdPrice", "platformFee", "royaltyFee", "txHash", status, "createdAt", "completedAt") FROM stdin;
\.


--
-- Data for Name: MemberRole; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."MemberRole" (id, "serverId", "userId", "roleId") FROM stdin;
\.


--
-- Data for Name: Message; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Message" (id, "channelId", "userId", content, nonce, tts, "timestamp", "editedTimestamp", flags, "isPinned", "mentionEveryone", mentions, "mentionRoles", "mentionChannels", "replyToId", "threadId", "webhookId", type, activity, application, "applicationId", "messageReference", stickers, "referencedMessage", interaction, components, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: MessageAnalytics; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."MessageAnalytics" (id, "serverId", "channelId", "userId", "messageCount", "characterCount", "wordCount", "attachmentCount", "mentionCount", "reactionCount", "timestamp") FROM stdin;
\.


--
-- Data for Name: MessageAttachment; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."MessageAttachment" (id, "messageId", filename, description, "contentType", size, url, "proxyUrl", height, width, ephemeral, duration, waveform, flags) FROM stdin;
\.


--
-- Data for Name: MessageEmbed; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."MessageEmbed" (id, "messageId", title, type, description, url, "timestamp", color, footer, image, thumbnail, video, provider, author, fields) FROM stdin;
\.


--
-- Data for Name: MessageReference; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."MessageReference" (id, "messageId", "channelId", "serverId", "referencedMessageId", type, "failIfNotExists") FROM stdin;
\.


--
-- Data for Name: Moderator; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Moderator" (id, "communityId", "userId", permissions, "addedAt") FROM stdin;
\.


--
-- Data for Name: Mute; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Mute" (id, "muterId", "mutedId", "createdAt") FROM stdin;
\.


--
-- Data for Name: NFT; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."NFT" (id, "collectionId", "tokenId", name, description, image, "animationUrl", attributes, metadata, "ownerAddress", rarity, "lastSalePrice", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: NFTCollection; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."NFTCollection" (id, "contractAddress", name, symbol, description, image, "bannerImage", chain, verified, "floorPrice", "totalSupply", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: NFTRequirement; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."NFTRequirement" (id, "ruleId", "collectionId", "minTokens", "specificTokenIds") FROM stdin;
\.


--
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Notification" (id, "userId", type, title, content, data, "isRead", "createdAt") FROM stdin;
\.


--
-- Data for Name: NotificationPreferences; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."NotificationPreferences" (id, "userId", "pushEnabled", "emailEnabled", "smsEnabled", "newMessageEnabled", "mentionEnabled", "replyEnabled", "followEnabled", "likeEnabled", "commentEnabled", "awardEnabled", "systemEnabled", "dmEnabled", "voiceCallEnabled", "serverInviteEnabled", "communityInviteEnabled", "quietHoursEnabled", "quietHoursStart", "quietHoursEnd", timezone, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: NotificationQueue; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."NotificationQueue" (id, "userId", type, title, body, data, priority, "scheduledAt", status, "processedAt", error, "retryCount", "maxRetries", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: NotificationTemplate; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."NotificationTemplate" (id, type, name, title, body, data, priority, sound, badge, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Poll; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Poll" (id, "postId", question, duration, "endsAt", "totalVotes", "createdAt") FROM stdin;
\.


--
-- Data for Name: PollOption; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."PollOption" (id, "pollId", option, votes, "position", "createdAt") FROM stdin;
\.


--
-- Data for Name: PollVote; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."PollVote" (id, "pollId", "optionId", "userId", "createdAt") FROM stdin;
\.


--
-- Data for Name: Post; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Post" (id, title, content, "commentCount", "communityId", "createdAt", "editedAt", flair, "isLocked", "isPinned", "isRemoved", nsfw, score, thumbnail, "updatedAt", url, "userId", "viewCount", "bookmarkCount", "isThread", "likeCount", metadata, "quoteCount", "quotedPostId", "replyCount", "repostCount", "repostOfId", "threadRootId", type) FROM stdin;
cmgu2gnev0059qlwcas2j7yrr	Beginner question	Just getting started in this area. Any tips for someone new?	7	cmgu2gn66000aqlwcxvsqs7z0	2025-07-06 12:35:55.603	\N	\N	f	f	f	f	272	\N	2025-10-16 23:44:09.157	\N	cmgu2gn4v0003qlwcugkrmdpr	746	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gney005bqlwc5wpupra3	Success story	Just achieved a major milestone! Here's how I did it.	6	cmgu2gn66000aqlwcxvsqs7z0	2025-04-26 07:01:33.428	\N	\N	f	f	f	f	144	\N	2025-10-16 23:44:09.179	\N	cmgu2gn4p0002qlwc80wfogfe	295	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnf1005dqlwckgg33wwt	Weekly discussion thread	What has everyone been up to this week? Share your updates!	8	cmgu2gn66000aqlwcxvsqs7z0	2025-09-19 04:10:36.841	\N	Meme	f	f	f	f	216	\N	2025-10-16 23:44:09.201	\N	cmgu2gn4v0003qlwcugkrmdpr	458	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnf5005fqlwcoglbuqud	Community feedback request	How can we make this community better? Share your ideas!	8	cmgu2gn66000aqlwcxvsqs7z0	2025-05-10 22:36:19.149	\N	\N	f	f	f	f	284	\N	2025-10-16 23:44:09.224	\N	cmgu2gn420000qlwcc82uc6sp	838	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnf8005hqlwc31vhv72o	Motivation Monday	Let's start the week strong! What are your goals?	10	cmgu2gn66000aqlwcxvsqs7z0	2025-03-24 22:52:48.949	\N	\N	f	f	f	f	182	\N	2025-10-16 23:44:09.25	\N	cmgu2gn500004qlwcjxvp6xez	46	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnfc005jqlwccmsu8ny1	Community feedback request	How can we make this community better? Share your ideas!	5	cmgu2gn66000aqlwcxvsqs7z0	2025-08-26 16:06:56.578	\N	\N	f	f	f	f	121	\N	2025-10-16 23:44:09.267	\N	cmgu2gn420000qlwcc82uc6sp	678	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnff005lqlwcea7weget	Motivation Monday	Let's start the week strong! What are your goals?	7	cmgu2gn66000aqlwcxvsqs7z0	2025-09-27 12:45:29.185	\N	\N	f	f	f	f	39	\N	2025-10-16 23:44:09.287	\N	cmgu2gn420000qlwcc82uc6sp	995	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnfi005nqlwcnzqeyknu	Beginner question	Just getting started in this area. Any tips for someone new?	9	cmgu2gn66000aqlwcxvsqs7z0	2025-06-19 01:20:52.316	\N	\N	f	f	f	f	36	\N	2025-10-16 23:44:09.312	\N	cmgu2gn4p0002qlwc80wfogfe	520	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnfl005pqlwccawv8ggk	Community feedback request	How can we make this community better? Share your ideas!	9	cmgu2gn66000aqlwcxvsqs7z0	2025-07-03 12:15:00.12	\N	\N	f	f	f	f	200	\N	2025-10-16 23:44:09.336	\N	cmgu2gn5n0006qlwcqfu7g12g	823	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnfv005xqlwcy9xwozs5	Looking for collaboration	Working on a project and looking for people to join. Interested?	7	cmgu2gn6b000bqlwcmdrkh4ll	2025-08-29 14:25:10.667	\N	\N	f	f	f	f	154	\N	2025-10-16 23:44:09.442	\N	cmgu2gn4p0002qlwc80wfogfe	512	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnfx005zqlwcdtj10tam	Looking for collaboration	Working on a project and looking for people to join. Interested?	10	cmgu2gn6b000bqlwcmdrkh4ll	2024-12-30 22:19:53.338	\N	\N	f	f	f	f	255	\N	2025-10-16 23:44:09.471	\N	cmgu2gn420000qlwcc82uc6sp	120	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gng50065qlwcpqngix97	Introduction post!	Hey everyone! Excited to join this community. Looking forward to great discussions!	10	cmgu2gn6b000bqlwcmdrkh4ll	2025-03-24 15:17:20.684	\N	\N	f	f	f	f	322	\N	2025-10-16 23:44:09.544	\N	cmgu2gn4v0003qlwcugkrmdpr	248	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gng80067qlwcmv5r819x	Success story	Just achieved a major milestone! Here's how I did it.	9	cmgu2gn6b000bqlwcmdrkh4ll	2025-09-20 21:24:33.504	\N	\N	f	f	f	f	51	\N	2025-10-16 23:44:09.576	\N	cmgu2gn4v0003qlwcugkrmdpr	377	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnga0069qlwcv0z1ejjv	Beginner question	Just getting started in this area. Any tips for someone new?	5	cmgu2gn6b000bqlwcmdrkh4ll	2025-01-14 11:14:43.577	\N	Guide	f	f	f	f	156	\N	2025-10-16 23:44:09.592	\N	cmgu2gn5f0005qlwcdx8tb0kd	27	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gngg006dqlwcw0pinl5l	Self-hosting everything in 2025	Complete guide to self-hosting your entire digital life. Ask me anything!	7	cmgu2gn6e000cqlwcn2qhrb5b	2025-05-14 00:04:36.644	\N	\N	f	f	f	f	30	\N	2025-10-16 23:44:09.645	\N	cmgu2gn620009qlwcdnj97s63	8	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gngj006fqlwc20qp2d27	Built a mechanical keyboard from scratch	Custom PCB, hand-soldered switches. Here's the build log!	6	cmgu2gn6e000cqlwcn2qhrb5b	2025-09-09 22:18:52.186	\N	\N	f	f	f	f	182	\N	2025-10-16 23:44:09.667	\N	cmgu2gn5s0007qlwcjhhzi8m9	647	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gngm006hqlwcwtj3886t	Self-hosting everything in 2025	Complete guide to self-hosting your entire digital life. Ask me anything!	9	cmgu2gn6e000cqlwcn2qhrb5b	2025-04-30 23:24:19.607	\N	\N	f	f	f	f	6	\N	2025-10-16 23:44:09.705	\N	cmgu2gn4v0003qlwcugkrmdpr	132	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gngs006lqlwcbc0g2wlw	Linux on desktop is finally viable	Switched to Linux full-time 6 months ago. Here's my experience.	7	cmgu2gn6e000cqlwcn2qhrb5b	2024-12-17 05:55:48.598	\N	Question	f	f	f	f	139	\N	2025-10-16 23:44:09.742	\N	cmgu2gn5s0007qlwcjhhzi8m9	834	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gngx006pqlwc65h899fc	Linux on desktop is finally viable	Switched to Linux full-time 6 months ago. Here's my experience.	9	cmgu2gn6e000cqlwcn2qhrb5b	2025-10-04 16:41:49.538	\N	Discussion	f	f	f	f	60	\N	2025-10-16 23:44:09.786	\N	cmgu2gn620009qlwcdnj97s63	671	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gngz006rqlwckw33v4ks	The future of quantum computing	IBM just announced a breakthrough. This could change everything.	8	cmgu2gn6e000cqlwcn2qhrb5b	2025-08-25 04:56:18.079	\N	\N	f	f	f	f	182	\N	2025-10-16 23:44:09.807	\N	cmgu2gn500004qlwcjxvp6xez	632	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnh3006tqlwctujwg677	New M4 MacBook Pro thoughts?	Anyone got the new MacBook Pro? How's the performance for heavy workloads?	10	cmgu2gn6e000cqlwcn2qhrb5b	2025-09-02 19:36:29.509	\N	\N	f	f	f	f	50	\N	2025-10-16 23:44:09.844	\N	cmgu2gn500004qlwcjxvp6xez	710	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnh5006vqlwcjzjtpsba	Ask me anything	I've been in this field for 5+ years. Happy to answer questions!	8	cmgu2gn6h000dqlwcumqoxnq3	2025-03-20 23:36:01.461	\N	\N	f	t	f	f	195	\N	2025-10-16 23:44:09.87	\N	cmgu2gn5f0005qlwcdx8tb0kd	508	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnfn005rqlwcc1mkauba	Beginner question	Just getting started in this area. Any tips for someone new?	9	cmgu2gn6b000bqlwcmdrkh4ll	2024-11-11 10:24:24.415	\N	\N	f	f	f	f	483	\N	2025-10-18 00:21:20.307	\N	cmgu2gn4k0001qlwc2fpdaslv	178	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnfq005tqlwc546jitoa	Sharing my recent project	Been working on this for a while. Would love your feedback and suggestions!	10	cmgu2gn6b000bqlwcmdrkh4ll	2025-10-07 05:19:08.736	\N	\N	f	f	f	f	442	\N	2025-10-18 00:21:20.307	\N	cmgu2gn4v0003qlwcugkrmdpr	426	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnhf0073qlwcwuulorou	Weekly discussion thread	What has everyone been up to this week? Share your updates!	6	cmgu2gn6h000dqlwcumqoxnq3	2024-11-14 13:36:54.069	\N	Meme	f	f	f	f	97	\N	2025-10-16 23:44:09.945	\N	cmgu2gn5f0005qlwcdx8tb0kd	330	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnhk0077qlwcda2i0b26	Motivation Monday	Let's start the week strong! What are your goals?	5	cmgu2gn6h000dqlwcumqoxnq3	2025-05-03 06:02:47.628	\N	\N	f	f	f	f	195	\N	2025-10-16 23:44:09.982	\N	cmgu2gn620009qlwcdnj97s63	448	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnhn0079qlwcpw5y5ivj	Motivation Monday	Let's start the week strong! What are your goals?	7	cmgu2gn6h000dqlwcumqoxnq3	2025-05-07 03:21:03.065	\N	\N	f	f	f	f	-5	\N	2025-10-16 23:44:10.002	\N	cmgu2gn620009qlwcdnj97s63	0	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnhq007bqlwcxm79p2ok	Sharing my recent project	Been working on this for a while. Would love your feedback and suggestions!	5	cmgu2gn6h000dqlwcumqoxnq3	2025-02-19 14:06:50.184	\N	\N	f	f	f	f	115	\N	2025-10-16 23:44:10.02	\N	cmgu2gn4k0001qlwc2fpdaslv	342	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnhs007dqlwc57g66cur	Introduction post!	Hey everyone! Excited to join this community. Looking forward to great discussions!	5	cmgu2gn6h000dqlwcumqoxnq3	2025-02-20 19:01:38.64	\N	\N	f	f	f	f	185	\N	2025-10-16 23:44:10.034	\N	cmgu2gn4v0003qlwcugkrmdpr	272	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnhy007hqlwcoyumsrpn	Resource recommendation	Found this amazing resource that helped me a lot. Highly recommended!	7	cmgu2gn7b000eqlwct6d6k946	2025-07-16 17:25:14.98	\N	\N	f	f	f	f	249	\N	2025-10-16 23:44:10.079	\N	cmgu2gn620009qlwcdnj97s63	947	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gni0007jqlwcrerqahm9	Introduction post!	Hey everyone! Excited to join this community. Looking forward to great discussions!	6	cmgu2gn7b000eqlwct6d6k946	2025-08-04 18:16:22.559	\N	\N	f	f	f	f	260	\N	2025-10-16 23:44:10.096	\N	cmgu2gn620009qlwcdnj97s63	241	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gni3007lqlwcgb8ihf60	Introduction post!	Hey everyone! Excited to join this community. Looking forward to great discussions!	7	cmgu2gn7b000eqlwct6d6k946	2025-03-13 04:07:30.218	\N	\N	f	f	f	f	212	\N	2025-10-16 23:44:10.121	\N	cmgu2gn500004qlwcjxvp6xez	131	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gni8007pqlwc4ha748o6	Ask me anything	I've been in this field for 5+ years. Happy to answer questions!	10	cmgu2gn7b000eqlwct6d6k946	2025-07-23 19:25:00.72	\N	Guide	f	f	f	f	152	\N	2025-10-16 23:44:10.187	\N	cmgu2gn4k0001qlwc2fpdaslv	397	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnia007rqlwc3vlzzprz	Weekly discussion thread	What has everyone been up to this week? Share your updates!	10	cmgu2gn7b000eqlwct6d6k946	2025-04-21 16:44:36.645	\N	Question	f	f	f	f	22	\N	2025-10-16 23:44:10.215	\N	cmgu2gn500004qlwcjxvp6xez	182	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnid007tqlwcaq97n5mw	Resource recommendation	Found this amazing resource that helped me a lot. Highly recommended!	7	cmgu2gn7b000eqlwct6d6k946	2024-12-16 10:15:59.726	\N	News	f	f	f	f	107	\N	2025-10-16 23:44:10.235	\N	cmgu2gn620009qlwcdnj97s63	585	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnif007vqlwcm4n0dlnu	Motivation Monday	Let's start the week strong! What are your goals?	7	cmgu2gn7b000eqlwct6d6k946	2025-04-04 07:34:09.742	\N	\N	f	f	f	f	10	\N	2025-10-16 23:44:10.257	\N	cmgu2gn5n0006qlwcqfu7g12g	113	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnii007xqlwcmmuc0h4z	Introduction post!	Hey everyone! Excited to join this community. Looking forward to great discussions!	6	cmgu2gn7b000eqlwct6d6k946	2025-05-20 16:18:43.654	\N	Discussion	f	f	f	f	264	\N	2025-10-16 23:44:10.273	\N	cmgu2gn5n0006qlwcqfu7g12g	459	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnil007zqlwcu2ev4o64	Sharing my recent project	Been working on this for a while. Would love your feedback and suggestions!	7	cmgu2gn7g000fqlwcjl9oszqf	2025-02-15 06:41:10.123	\N	\N	f	t	f	f	306	\N	2025-10-16 23:44:10.291	\N	cmgu2gn4v0003qlwcugkrmdpr	202	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnin0081qlwchuegw75e	Success story	Just achieved a major milestone! Here's how I did it.	6	cmgu2gn7g000fqlwcjl9oszqf	2025-08-13 06:14:13.437	\N	News	f	f	f	f	25	\N	2025-10-16 23:44:10.309	\N	cmgu2gn5x0008qlwc51j7cb44	404	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gniq0083qlwcqs532ixz	Success story	Just achieved a major milestone! Here's how I did it.	5	cmgu2gn7g000fqlwcjl9oszqf	2025-04-23 05:36:01.242	\N	\N	f	f	f	f	194	\N	2025-10-16 23:44:10.322	\N	cmgu2gn4v0003qlwcugkrmdpr	434	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnit0085qlwc1j8lc8nm	Introduction post!	Hey everyone! Excited to join this community. Looking forward to great discussions!	8	cmgu2gn7g000fqlwcjl9oszqf	2025-09-12 09:31:13.323	\N	Guide	f	f	f	f	222	\N	2025-10-16 23:44:10.343	\N	cmgu2gn500004qlwcjxvp6xez	654	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gniw0087qlwc0hlk874k	Community feedback request	How can we make this community better? Share your ideas!	10	cmgu2gn7g000fqlwcjl9oszqf	2025-04-25 03:37:14.901	\N	\N	f	f	f	f	256	\N	2025-10-16 23:44:10.369	\N	cmgu2gn5n0006qlwcqfu7g12g	281	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gniy0089qlwcsaw897wa	Weekly discussion thread	What has everyone been up to this week? Share your updates!	5	cmgu2gn7g000fqlwcjl9oszqf	2025-07-06 08:32:08.552	\N	\N	f	f	f	f	309	\N	2025-10-16 23:44:10.382	\N	cmgu2gn5f0005qlwcdx8tb0kd	450	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnj7008dqlwcyxyvgapx	Motivation Monday	Let's start the week strong! What are your goals?	9	cmgu2gn7g000fqlwcjl9oszqf	2025-09-20 13:42:41.856	\N	\N	f	f	f	f	268	\N	2025-10-16 23:44:10.432	\N	cmgu2gn5f0005qlwcdx8tb0kd	22	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnja008fqlwcvkwxqr0e	Beginner question	Just getting started in this area. Any tips for someone new?	9	cmgu2gn7g000fqlwcjl9oszqf	2025-05-13 22:11:52.544	\N	Discussion	f	f	f	f	82	\N	2025-10-16 23:44:10.46	\N	cmgu2gn4p0002qlwc80wfogfe	390	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnjh008lqlwcq5fykzfg	Resource recommendation	Found this amazing resource that helped me a lot. Highly recommended!	9	cmgu2gn7m000gqlwctzte3k6i	2024-12-17 15:48:39.592	\N	\N	f	f	f	f	7	\N	2025-10-16 23:44:10.537	\N	cmgu2gn4p0002qlwc80wfogfe	656	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnjk008nqlwci580g2tw	Weekly discussion thread	What has everyone been up to this week? Share your updates!	5	cmgu2gn7m000gqlwctzte3k6i	2025-04-23 04:02:53.395	\N	\N	f	f	f	f	329	\N	2025-10-16 23:44:10.559	\N	cmgu2gn5f0005qlwcdx8tb0kd	221	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnjo008rqlwcx4frguc9	Resource recommendation	Found this amazing resource that helped me a lot. Highly recommended!	10	cmgu2gn7m000gqlwctzte3k6i	2025-08-09 23:31:20.732	\N	News	f	f	f	f	48	\N	2025-10-16 23:44:10.631	\N	cmgu2gn5n0006qlwcqfu7g12g	805	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnjr008tqlwc2pb5jwav	Beginner question	Just getting started in this area. Any tips for someone new?	5	cmgu2gn7m000gqlwctzte3k6i	2024-10-23 18:52:45.533	\N	Meme	f	f	f	f	239	\N	2025-10-16 23:44:10.646	\N	cmgu2gn620009qlwcdnj97s63	31	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnhh0075qlwc1j0bigi1	Sharing my recent project	Been working on this for a while. Would love your feedback and suggestions!	8	cmgu2gn6h000dqlwcumqoxnq3	2024-12-23 03:36:42.158	\N	\N	f	f	f	f	366	\N	2025-10-18 00:21:20.307	\N	cmgu2gn5f0005qlwcdx8tb0kd	95	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnjy008zqlwcbic3v3ah	Success story	Just achieved a major milestone! Here's how I did it.	10	cmgu2gn7m000gqlwctzte3k6i	2025-09-07 13:58:18.115	\N	\N	f	f	f	f	35	\N	2025-10-16 23:44:10.728	\N	cmgu2gn5x0008qlwc51j7cb44	915	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnk10091qlwczxozltln	Introduction post!	Hey everyone! Excited to join this community. Looking forward to great discussions!	10	cmgu2gn7m000gqlwctzte3k6i	2025-05-18 17:41:29.658	\N	\N	f	f	f	f	54	\N	2025-10-16 23:44:10.761	\N	cmgu2gn4v0003qlwcugkrmdpr	90	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnk60095qlwcid6g7s9i	Introduction post!	Hey everyone! Excited to join this community. Looking forward to great discussions!	10	cmgu2gn7r000hqlwc70v2wi8q	2025-06-19 17:41:03.136	\N	\N	f	f	f	f	0	\N	2025-10-16 23:44:10.812	\N	cmgu2gn5x0008qlwc51j7cb44	218	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnk90097qlwc9nh7qwx4	Sharing my recent project	Been working on this for a while. Would love your feedback and suggestions!	7	cmgu2gn7r000hqlwc70v2wi8q	2025-04-01 21:31:34.028	\N	\N	f	f	f	f	94	\N	2025-10-16 23:44:10.829	\N	cmgu2gn5s0007qlwcjhhzi8m9	805	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnkd0099qlwct5vp58ks	Weekly discussion thread	What has everyone been up to this week? Share your updates!	8	cmgu2gn7r000hqlwc70v2wi8q	2025-07-06 01:29:40.215	\N	\N	f	f	f	f	176	\N	2025-10-16 23:44:10.851	\N	cmgu2gn4p0002qlwc80wfogfe	543	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnkg009bqlwcb1bb9okj	Introduction post!	Hey everyone! Excited to join this community. Looking forward to great discussions!	10	cmgu2gn7r000hqlwc70v2wi8q	2025-01-10 18:17:35.885	\N	\N	f	f	f	f	182	\N	2025-10-16 23:44:10.882	\N	cmgu2gn5f0005qlwcdx8tb0kd	243	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnkr009hqlwce988449u	Ask me anything	I've been in this field for 5+ years. Happy to answer questions!	8	cmgu2gn7r000hqlwc70v2wi8q	2025-02-12 21:00:34.537	\N	Question	f	f	f	f	76	\N	2025-10-16 23:44:10.946	\N	cmgu2gn4k0001qlwc2fpdaslv	584	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnku009jqlwceysdpvay	Looking for collaboration	Working on a project and looking for people to join. Interested?	6	cmgu2gn7r000hqlwc70v2wi8q	2025-03-10 09:09:24.397	\N	\N	f	f	f	f	242	\N	2025-10-16 23:44:10.963	\N	cmgu2gn5s0007qlwcjhhzi8m9	958	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnkx009lqlwc3khkg597	Community feedback request	How can we make this community better? Share your ideas!	10	cmgu2gn7r000hqlwc70v2wi8q	2025-09-09 16:42:18.453	\N	News	f	f	f	f	23	\N	2025-10-16 23:44:10.991	\N	cmgu2gn4k0001qlwc2fpdaslv	507	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnl0009nqlwck1qy5iwt	Best indie games of 2025	What hidden gems have you discovered this year?	5	cmgu2gn7u000iqlwc99a2xdcm	2025-02-11 05:08:08.165	\N	Guide	f	f	f	f	344	\N	2025-10-16 23:44:11.004	\N	cmgu2gn4k0001qlwc2fpdaslv	747	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnl2009pqlwc9xzsxdar	My gaming setup tour	After years of upgrades, here's my complete battle station.	6	cmgu2gn7u000iqlwc99a2xdcm	2024-12-16 04:45:00.87	\N	\N	f	f	f	f	255	\N	2025-10-16 23:44:11.021	\N	cmgu2gn4v0003qlwcugkrmdpr	634	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnl5009rqlwcqumgu0s2	Completed my first 100% run	Took 80 hours but I got every achievement. Worth it!	8	cmgu2gn7u000iqlwc99a2xdcm	2024-12-23 22:36:03.148	\N	Guide	f	f	f	f	207	\N	2025-10-16 23:44:11.041	\N	cmgu2gn4v0003qlwcugkrmdpr	987	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnl7009tqlwcf2hx0xzn	Retro gaming is back	Been collecting and playing classic games. The nostalgia is real!	5	cmgu2gn7u000iqlwc99a2xdcm	2025-04-13 14:21:51.548	\N	\N	f	f	f	f	93	\N	2025-10-16 23:44:11.054	\N	cmgu2gn4p0002qlwc80wfogfe	94	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnl9009vqlwcpd4swuy7	Game recommendations for Steam Deck?	Just got a Steam Deck. What games work best on it?	10	cmgu2gn7u000iqlwc99a2xdcm	2025-06-18 06:49:40.156	\N	\N	f	f	f	f	184	\N	2025-10-16 23:44:11.079	\N	cmgu2gn5x0008qlwc51j7cb44	622	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnle009zqlwc8etodfqh	Completed my first 100% run	Took 80 hours but I got every achievement. Worth it!	9	cmgu2gn7u000iqlwc99a2xdcm	2025-03-25 17:29:24.772	\N	\N	f	f	f	f	62	\N	2025-10-16 23:44:11.143	\N	cmgu2gn4k0001qlwc2fpdaslv	919	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnln00a5qlwc8e6zxumw	Just hit Diamond rank!	Finally climbed out of Platinum after 200 games. AMA!	7	cmgu2gn7u000iqlwc99a2xdcm	2025-08-29 01:05:29.423	\N	\N	f	f	f	f	333	\N	2025-10-16 23:44:11.212	\N	cmgu2gn4p0002qlwc80wfogfe	499	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnls00a9qlwcem9rdm32	ETH 2.0 staking guide	Complete guide to staking ETH safely. Ask me anything!	10	cmgu2gn7y000jqlwc50ywgwgj	2025-01-13 05:12:42.421	\N	Meme	f	f	f	f	123	\N	2025-10-16 23:44:11.26	\N	cmgu2gn5n0006qlwcqfu7g12g	93	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnlv00abqlwcdbxcll1r	Web3 gaming is evolving	Play-to-earn is dead, but play-and-earn is thriving.	6	cmgu2gn7y000jqlwc50ywgwgj	2025-04-23 23:35:37.201	\N	\N	f	f	f	f	65	\N	2025-10-16 23:44:11.282	\N	cmgu2gn5s0007qlwcjhhzi8m9	214	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnlx00adqlwc0jmi9uk2	Building on Solana	Developer guide to building dApps on Solana. Resources included!	7	cmgu2gn7y000jqlwc50ywgwgj	2025-09-13 21:06:49.345	\N	\N	f	f	f	f	154	\N	2025-10-16 23:44:11.302	\N	cmgu2gn500004qlwcjxvp6xez	5	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnlz00afqlwczotfwiph	Best wallets for security	Hardware vs software wallets - what do you recommend?	5	cmgu2gn7y000jqlwc50ywgwgj	2025-09-21 04:07:59.35	\N	\N	f	f	f	f	289	\N	2025-10-16 23:44:11.323	\N	cmgu2gn5x0008qlwc51j7cb44	476	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnm100ahqlwckvill1c9	Web3 gaming is evolving	Play-to-earn is dead, but play-and-earn is thriving.	9	cmgu2gn7y000jqlwc50ywgwgj	2025-07-09 18:09:48.347	\N	\N	f	f	f	f	284	\N	2025-10-16 23:44:11.347	\N	cmgu2gn620009qlwcdnj97s63	643	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnm600alqlwckfvyri83	ETH 2.0 staking guide	Complete guide to staking ETH safely. Ask me anything!	10	cmgu2gn7y000jqlwc50ywgwgj	2025-07-16 06:18:59.635	\N	\N	f	f	f	f	155	\N	2025-10-16 23:44:11.389	\N	cmgu2gn5x0008qlwc51j7cb44	652	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnm800anqlwccqm3mxb6	Crypto tax tips for 2025	CPA here - answering your crypto tax questions!	8	cmgu2gn7y000jqlwc50ywgwgj	2024-12-30 01:16:28.31	\N	Guide	f	f	f	f	252	\N	2025-10-16 23:44:11.414	\N	cmgu2gn5f0005qlwcdx8tb0kd	122	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnjw008xqlwc4t87cugu	Beginner question	Just getting started in this area. Any tips for someone new?	6	cmgu2gn7m000gqlwctzte3k6i	2025-02-26 02:00:50.519	\N	\N	f	f	f	f	418	\N	2025-10-18 00:21:20.307	\N	cmgu2gn5s0007qlwcjhhzi8m9	225	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnep0057qlwcxevt29ue	Ask me anything	I've been in this field for 5+ years. Happy to answer questions!	6	cmgu2gn66000aqlwcxvsqs7z0	2025-09-23 12:34:37.621	\N	\N	f	f	f	f	117	\N	2025-10-16 23:44:09.13	\N	cmgu2gn620009qlwcdnj97s63	434	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gngp006jqlwce38mhknu	Finally got my homelab running	Set up a complete homelab with Docker, K8s, and monitoring. Happy to share my setup!	6	cmgu2gn6e000cqlwcn2qhrb5b	2025-02-01 15:02:48.262	\N	\N	f	f	f	f	260	\N	2025-10-16 23:44:09.722	\N	cmgu2gn620009qlwcdnj97s63	880	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnjd008hqlwce9ko8bra	Resource recommendation	Found this amazing resource that helped me a lot. Highly recommended!	10	cmgu2gn7g000fqlwcjl9oszqf	2025-07-11 19:17:59.84	\N	Guide	f	f	f	f	81	\N	2025-10-16 23:44:10.493	\N	cmgu2gn5n0006qlwcqfu7g12g	967	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnjt008vqlwcawp7orur	Looking for collaboration	Working on a project and looking for people to join. Interested?	10	cmgu2gn7m000gqlwctzte3k6i	2025-03-14 22:51:34.937	\N	Guide	f	f	f	f	252	\N	2025-10-16 23:44:10.677	\N	cmgu2gn4k0001qlwc2fpdaslv	384	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnmb00apqlwc1jlv03ic	Best wallets for security	Hardware vs software wallets - what do you recommend?	9	cmgu2gn7y000jqlwc50ywgwgj	2024-11-24 01:16:52.331	\N	\N	f	f	f	f	148	\N	2025-10-16 23:44:11.437	\N	cmgu2gn5f0005qlwcdx8tb0kd	896	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnfs005vqlwclpefas5f	Community feedback request	How can we make this community better? Share your ideas!	9	cmgu2gn6b000bqlwcmdrkh4ll	2025-01-23 01:35:43.168	\N	\N	f	f	f	f	365	\N	2025-10-18 00:21:20.307	\N	cmgu2gn4k0001qlwc2fpdaslv	464	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gng00061qlwcl70jll7j	Motivation Monday	Let's start the week strong! What are your goals?	8	cmgu2gn6b000bqlwcmdrkh4ll	2024-11-29 14:48:14.444	\N	\N	f	f	f	f	449	\N	2025-10-18 00:21:20.307	\N	cmgu2gn420000qlwcc82uc6sp	357	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gng30063qlwc4kk643yf	Weekly discussion thread	What has everyone been up to this week? Share your updates!	8	cmgu2gn6b000bqlwcmdrkh4ll	2024-12-03 00:43:55.423	\N	Discussion	f	f	f	f	406	\N	2025-10-18 00:21:20.307	\N	cmgu2gn620009qlwcdnj97s63	943	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gngd006bqlwczd46xwge	Linux on desktop is finally viable	Switched to Linux full-time 6 months ago. Here's my experience.	9	cmgu2gn6e000cqlwcn2qhrb5b	2025-10-06 19:37:02.847	\N	\N	f	f	f	f	364	\N	2025-10-18 00:21:20.307	\N	cmgu2gn5s0007qlwcjhhzi8m9	80	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gngu006nqlwcot6ujewu	AI is changing everything	The pace of AI development is incredible. What are your thoughts on where we're headed?	6	cmgu2gn6e000cqlwcn2qhrb5b	2025-08-27 23:04:38.552	\N	\N	f	f	f	f	390	\N	2025-10-18 00:21:20.307	\N	cmgu2gn5x0008qlwc51j7cb44	490	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnh8006xqlwcn5qke237	Weekly discussion thread	What has everyone been up to this week? Share your updates!	8	cmgu2gn6h000dqlwcumqoxnq3	2025-03-24 07:35:44.488	\N	\N	f	f	f	f	498	\N	2025-10-18 00:21:20.307	\N	cmgu2gn4k0001qlwc2fpdaslv	80	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnha006zqlwccxtsawgd	Resource recommendation	Found this amazing resource that helped me a lot. Highly recommended!	7	cmgu2gn6h000dqlwcumqoxnq3	2025-08-15 06:47:53.043	\N	\N	f	f	f	f	465	\N	2025-10-18 00:21:20.307	\N	cmgu2gn4p0002qlwc80wfogfe	929	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnhv007fqlwcof2gdbb4	Ask me anything	I've been in this field for 5+ years. Happy to answer questions!	10	cmgu2gn7b000eqlwct6d6k946	2024-12-15 12:37:51.278	\N	\N	f	f	f	f	399	\N	2025-10-18 00:21:20.307	\N	cmgu2gn5s0007qlwcjhhzi8m9	867	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gni6007nqlwc431gp7q9	Resource recommendation	Found this amazing resource that helped me a lot. Highly recommended!	5	cmgu2gn7b000eqlwct6d6k946	2024-10-31 15:56:23.011	\N	\N	f	f	f	f	413	\N	2025-10-18 00:21:20.307	\N	cmgu2gn5f0005qlwcdx8tb0kd	377	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnj4008bqlwcj0ktc4tm	Beginner question	Just getting started in this area. Any tips for someone new?	7	cmgu2gn7g000fqlwcjl9oszqf	2025-04-23 10:38:32.877	\N	\N	f	f	f	f	431	\N	2025-10-18 00:21:20.307	\N	cmgu2gn4v0003qlwcugkrmdpr	274	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnjf008jqlwcibobhafv	Introduction post!	Hey everyone! Excited to join this community. Looking forward to great discussions!	6	cmgu2gn7m000gqlwctzte3k6i	2025-07-15 17:18:50.675	\N	\N	f	t	f	f	360	\N	2025-10-18 00:21:20.307	\N	cmgu2gn500004qlwcjxvp6xez	858	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnjm008pqlwc8shv880s	Beginner question	Just getting started in this area. Any tips for someone new?	9	cmgu2gn7m000gqlwctzte3k6i	2025-04-27 23:12:23.988	\N	News	f	f	f	f	473	\N	2025-10-18 00:21:20.307	\N	cmgu2gn500004qlwcjxvp6xez	730	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnk30093qlwc9recucdk	Introduction post!	Hey everyone! Excited to join this community. Looking forward to great discussions!	7	cmgu2gn7r000hqlwc70v2wi8q	2024-12-22 22:17:19.878	\N	\N	f	f	f	f	355	\N	2025-10-18 00:21:20.307	\N	cmgu2gn5f0005qlwcdx8tb0kd	861	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnkl009dqlwcr3niwh4z	Weekly discussion thread	What has everyone been up to this week? Share your updates!	8	cmgu2gn7r000hqlwc70v2wi8q	2025-08-19 15:13:10.985	\N	\N	f	f	f	f	382	\N	2025-10-18 00:21:20.307	\N	cmgu2gn4k0001qlwc2fpdaslv	511	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnko009fqlwcajdqljn7	Introduction post!	Hey everyone! Excited to join this community. Looking forward to great discussions!	8	cmgu2gn7r000hqlwc70v2wi8q	2025-05-29 05:12:28.752	\N	Guide	f	f	f	f	405	\N	2025-10-18 00:21:20.307	\N	cmgu2gn420000qlwcc82uc6sp	891	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnlc009xqlwcpztauvzu	Speedrun world record!	Just set a new Any% WR in my favorite game. Video in comments!	10	cmgu2gn7u000iqlwc99a2xdcm	2025-05-10 09:48:06.997	\N	\N	f	f	f	f	345	\N	2025-10-18 00:21:20.307	\N	cmgu2gn5n0006qlwcqfu7g12g	934	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnlj00a1qlwcxgx920iz	Just hit Diamond rank!	Finally climbed out of Platinum after 200 games. AMA!	9	cmgu2gn7u000iqlwc99a2xdcm	2025-06-08 17:53:05.527	\N	Meme	f	f	f	f	459	\N	2025-10-18 00:21:20.307	\N	cmgu2gn500004qlwcjxvp6xez	29	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnll00a3qlwc9n91f457	Game recommendations for Steam Deck?	Just got a Steam Deck. What games work best on it?	7	cmgu2gn7u000iqlwc99a2xdcm	2025-06-07 09:24:00.975	\N	\N	f	f	f	f	488	\N	2025-10-18 00:21:20.307	\N	cmgu2gn5x0008qlwc51j7cb44	997	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnlq00a7qlwcmnzktsif	Layer 2 solutions comparison	Analyzed Arbitrum, Optimism, and zkSync. Here are the results.	7	cmgu2gn7y000jqlwc50ywgwgj	2025-08-06 22:51:27.261	\N	Meme	f	f	f	f	455	\N	2025-10-18 00:21:20.307	\N	cmgu2gn4p0002qlwc80wfogfe	921	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnm400ajqlwc5sfuue6y	Got rugged, lessons learned	Lost $5k to a scam project. Here's how to avoid my mistakes.	5	cmgu2gn7y000jqlwc50ywgwgj	2025-05-14 10:50:15.282	\N	\N	f	f	f	f	493	\N	2025-10-18 00:21:20.307	\N	cmgu2gn4p0002qlwc80wfogfe	57	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgu2gnhd0071qlwc97sfr00k	Weekly discussion thread	What has everyone been up to this week? Share your updates!	5	cmgu2gn6h000dqlwcumqoxnq3	2025-03-08 13:47:14.637	\N	\N	f	f	f	f	488	\N	2025-10-18 00:21:20.307	\N	cmgu2gn420000qlwcc82uc6sp	437	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
cmgvusmpa0004kf6cjhb0ym86	Test Post	This is my test post	0	cmgu2gn6e000cqlwcn2qhrb5b	2025-10-18 05:45:03.215	\N	\N	f	f	f	f	0	\N	2025-10-18 05:45:03.215	\N	cmgvqpaza0000kf6cmh62ub5w	0	0	f	0	\N	0	\N	0	0	\N	\N	TEXT
\.


--
-- Data for Name: PostMedia; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."PostMedia" (id, "postId", type, url, thumbnail, alt, width, height, duration, "fileSize", "mimeType", "position", "createdAt") FROM stdin;
\.


--
-- Data for Name: PushDevice; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."PushDevice" (id, "userId", "deviceToken", "deviceType", "deviceModel", "osVersion", "appVersion", "isActive", "lastActiveAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PushNotificationDelivery; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."PushNotificationDelivery" (id, "notificationId", "templateId", "deviceId", "userId", title, body, data, status, provider, "providerResponse", error, "sentAt", "deliveredAt", "clickedAt", "retryCount", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Reaction; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Reaction" (id, "messageId", "userId", emoji, "createdAt") FROM stdin;
\.


--
-- Data for Name: Report; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Report" (id, "reporterId", "postId", "commentId", reason, details, status, "createdAt", "reviewedAt", "reviewedBy") FROM stdin;
\.


--
-- Data for Name: Repost; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Repost" (id, "userId", "postId", comment, "createdAt") FROM stdin;
\.


--
-- Data for Name: Role; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Role" (id, "serverId", name, color, "position", permissions, mentionable, hoisted, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: SavedPost; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."SavedPost" (id, "userId", "postId", "createdAt") FROM stdin;
\.


--
-- Data for Name: SecurityLog; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."SecurityLog" (id, type, "userId", "ipAddress", "userAgent", details, "riskScore", location, "createdAt") FROM stdin;
\.


--
-- Data for Name: Server; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Server" (id, name, description, icon, banner, splash, "discoverySplash", "ownerId", "isPublic", "tokenGated", "requiredTokens", "maxMembers", "maxPresences", "maxVideoChannelUsers", "approximateMemberCount", "approximatePresenceCount", permissions, features, "verificationLevel", "defaultMessageNotifications", "explicitContentFilter", "mfaLevel", "systemChannelId", "systemChannelFlags", "rulesChannelId", "maxPresences2", "vanityUrlCode", "premiumTier", "premiumSubscriptionCount", "preferredLocale", "publicUpdatesChannelId", nsfw, "nsfwLevel", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ServerAnalytics; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."ServerAnalytics" (id, "serverId", "memberCount", "onlineCount", "messageCount", "voiceMinutes", "timestamp") FROM stdin;
\.


--
-- Data for Name: ServerEmoji; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."ServerEmoji" (id, "serverId", name, image, "requireColons", managed, animated, available, roles, "user") FROM stdin;
\.


--
-- Data for Name: ServerMember; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."ServerMember" (id, "serverId", "userId", nickname, avatar, banner, bio, "joinedAt", "premiumSince", deaf, mute, flags, pending, permissions, "communicationDisabledUntil") FROM stdin;
\.


--
-- Data for Name: ServerSticker; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."ServerSticker" (id, "serverId", name, description, tags, type, "formatType", available, "sortValue") FROM stdin;
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Session" (id, "userId", token, "refreshToken", "expiresAt", "createdAt", "updatedAt") FROM stdin;
edab10f4-b91a-40bd-acd7-dc71fcad6bf1	cmgvj6xwm0000vzb8a21ggzfo	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2ajZ4d20wMDAwdnpiOGEyMWdnemZvIiwic2Vzc2lvbklkIjoiZWRhYjEwZjQtYjkxYS00MGJkLWFjZDctZGM3MWZjYWQ2YmYxIiwiZW1haWwiOiJoYXJzaDJAdGVzdC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiM2ZhNTdiYTYtMDc0Mi00MWFjLWI5OWQtMDA0MmE2ZWU5OTk3IiwiaWF0IjoxNzYwNzQ2ODE1LCJleHAiOjE3NjA3NDc3MTUsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.ee8C-z-g4o4gjY9gikzlNLkcIyLDUP_txIZUAY02bLU	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2ajZ4d20wMDAwdnpiOGEyMWdnemZvIiwic2Vzc2lvbklkIjoiZWRhYjEwZjQtYjkxYS00MGJkLWFjZDctZGM3MWZjYWQ2YmYxIiwidHlwZSI6InJlZnJlc2giLCJqdGkiOiI3NmYxN2Q0Ny00Y2E2LTRhOGQtOTE0MS1iNzUwYjcyNzg1NGIiLCJpYXQiOjE3NjA3NDY4MTUsImV4cCI6MTc2MzMzODgxNSwiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.IJZSVAgO000XEsHQ8q4HfRmwjD5juHw-io6xyqowIF4	2025-11-17 00:20:15.533	2025-10-18 00:20:15.551	2025-10-18 00:20:15.551
11685956-f454-4486-bf5e-293017e8f304	cmgvje2zo0000k62dygaismzy	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2amUyem8wMDAwazYyZHlnYWlzbXp5Iiwic2Vzc2lvbklkIjoiMTE2ODU5NTYtZjQ1NC00NDg2LWJmNWUtMjkzMDE3ZThmMzA0IiwiZW1haWwiOiJ1eC10ZXN0ZXJAdGVzdC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiNTc0NDFhZjMtNmVkNC00YzhlLTk0YTItY2Q4NTA1YjU3ODAyIiwiaWF0IjoxNzYwNzQ3MTQ4LCJleHAiOjE3NjA3NDgwNDgsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.ueW-VFL-VYErS3rPEfJs5EIaZyyopb27kjy7o9pUXDg	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2amUyem8wMDAwazYyZHlnYWlzbXp5Iiwic2Vzc2lvbklkIjoiMTE2ODU5NTYtZjQ1NC00NDg2LWJmNWUtMjkzMDE3ZThmMzA0IiwidHlwZSI6InJlZnJlc2giLCJqdGkiOiIzZmFhYTg0MC0xZDI2LTQzMjItYmM3YS1iMmQ1NDQ5NTY5OTIiLCJpYXQiOjE3NjA3NDcxNDgsImV4cCI6MTc2MzMzOTE0OCwiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.7_iXuF-_fo6hzI1WITZvz8FP2wW3O8gIjt83hBGJHqM	2025-11-17 00:25:48.716	2025-10-18 00:25:48.727	2025-10-18 00:25:48.727
abb99a3d-cf5e-472d-90d7-21ef5074cc08	cmgvqpaza0000kf6cmh62ub5w	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiYWJiOTlhM2QtY2Y1ZS00NzJkLTkwZDctMjFlZjUwNzRjYzA4IiwiZW1haWwiOiJ0ZXN0OTk5QHRlc3QuY29tIiwid2FsbGV0QWRkcmVzcyI6bnVsbCwiaXNWZXJpZmllZCI6ZmFsc2UsImp0aSI6IjNiYWZmYmEzLWY5MzAtNDk5OC1hYWEwLWRmMmQwMmFiYTUzNSIsImlhdCI6MTc2MDc1OTQyOSwiZXhwIjoxNzYwNzYwMzI5LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.4B7cYZ5iIry9IY5irNk0zZweYOm3olpScSEHL5LJt-o	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiYWJiOTlhM2QtY2Y1ZS00NzJkLTkwZDctMjFlZjUwNzRjYzA4IiwidHlwZSI6InJlZnJlc2giLCJqdGkiOiI5NzY4YTU2Zi02MTkwLTQ2OGUtOWRhZS0xNGM3MDZiYjljY2QiLCJpYXQiOjE3NjA3NTk0MjksImV4cCI6MTc2MzM1MTQyOSwiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.TcZOB5JsA0u1LLvPFG5-EMFkEduQkHxa3ZlwroPo7oU	2025-11-17 03:50:29.596	2025-10-18 03:50:29.602	2025-10-18 03:50:29.602
b5c98f6f-1fb9-474b-8d4d-05950621d7f1	cmgvqpaza0000kf6cmh62ub5w	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiYjVjOThmNmYtMWZiOS00NzRiLThkNGQtMDU5NTA2MjFkN2YxIiwiZW1haWwiOiJ0ZXN0OTk5QHRlc3QuY29tIiwid2FsbGV0QWRkcmVzcyI6bnVsbCwiaXNWZXJpZmllZCI6ZmFsc2UsImp0aSI6IjlhZTIzMzFhLWVmMjAtNDUzOS04ZDI0LTYxOGU5Njc4NzBhZSIsImlhdCI6MTc2MDc1OTYyNCwiZXhwIjoxNzYwNzYwNTI0LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.gm84mXwcEWZvw86caFDObrjH0fWx-IIc6vohQ1vsWZ0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiYjVjOThmNmYtMWZiOS00NzRiLThkNGQtMDU5NTA2MjFkN2YxIiwidHlwZSI6InJlZnJlc2giLCJqdGkiOiIyNGZkNTg0OC1hZjlkLTQ2YTYtOWYwNS1lN2I5YTdhZmMzNTgiLCJpYXQiOjE3NjA3NTk2MjQsImV4cCI6MTc2MzM1MTYyNCwiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.lDbpB8A3jotanhjgbVCplSj10iaeOn6UoznRf3WloZU	2025-11-17 03:53:44.242	2025-10-18 03:53:44.249	2025-10-18 03:53:44.249
4d143456-0b69-4b34-a8fa-8a28be29015c	cmgvqpaza0000kf6cmh62ub5w	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiNGQxNDM0NTYtMGI2OS00YjM0LWE4ZmEtOGEyOGJlMjkwMTVjIiwiZW1haWwiOiJ0ZXN0OTk5QHRlc3QuY29tIiwid2FsbGV0QWRkcmVzcyI6bnVsbCwiaXNWZXJpZmllZCI6ZmFsc2UsImp0aSI6IjMwMTQwNDRkLTZhMzUtNGJlZC05OWVmLTkyMzE0YmY4MjQ2ZCIsImlhdCI6MTc2MDc2MzI5OSwiZXhwIjoxNzYwNzY0MTk5LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.XyfpUbGjRDgDPQL7zqrd4qGlPeutLmAiPjdJ9VqyAI0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiNGQxNDM0NTYtMGI2OS00YjM0LWE4ZmEtOGEyOGJlMjkwMTVjIiwidHlwZSI6InJlZnJlc2giLCJqdGkiOiJiOTNlMTYyZS0wMmVkLTRlMmQtODYzNS0yNzZiNWNhYTFkYjMiLCJpYXQiOjE3NjA3NjMyOTksImV4cCI6MTc2MzM1NTI5OSwiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.tM2eTYSJSYaLiV1_4js_of9RMwQ2Ai6ZiLA5hKhvdvk	2025-11-17 04:54:59.568	2025-10-18 04:54:59.574	2025-10-18 04:54:59.574
e2948b63-d630-4673-8096-fa264e5f1e4b	cmgvqpaza0000kf6cmh62ub5w	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiZTI5NDhiNjMtZDYzMC00NjczLTgwOTYtZmEyNjRlNWYxZTRiIiwiZW1haWwiOiJ0ZXN0OTk5QHRlc3QuY29tIiwid2FsbGV0QWRkcmVzcyI6bnVsbCwiaXNWZXJpZmllZCI6ZmFsc2UsImp0aSI6IjExMjMzYWJiLWYxZDEtNGZlYy1iYjUxLWIyM2ZiMTRhZjY4ZCIsImlhdCI6MTc2MDc2NTM3OSwiZXhwIjoxNzYwNzY2Mjc5LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.7nIxLEmpKdiipGTBPLnvWAmyqk0OdITKiesMcL0GEVE	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiZTI5NDhiNjMtZDYzMC00NjczLTgwOTYtZmEyNjRlNWYxZTRiIiwidHlwZSI6InJlZnJlc2giLCJqdGkiOiJhM2FkNmQ5OS1hNjFiLTRiODYtYmM1My0wZTAyYzM3NzhiNWUiLCJpYXQiOjE3NjA3NjUzNzksImV4cCI6MTc2MzM1NzM3OSwiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.LttC0p3ha4GIkNf62JLxBHC25Wcd9MtQIuS_eMm-DNg	2025-11-17 05:29:39.713	2025-10-18 05:29:39.72	2025-10-18 05:29:39.72
e473415c-147c-42dc-895d-a87c185b0b63	cmgvqpaza0000kf6cmh62ub5w	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiZTQ3MzQxNWMtMTQ3Yy00MmRjLTg5NWQtYTg3YzE4NWIwYjYzIiwiZW1haWwiOiJ0ZXN0OTk5QHRlc3QuY29tIiwid2FsbGV0QWRkcmVzcyI6bnVsbCwiaXNWZXJpZmllZCI6ZmFsc2UsImp0aSI6ImVmYzk5MTYxLTMxNTQtNDIyNS05NjU4LWVkOTU2MGRmZDFlMiIsImlhdCI6MTc2MDc2NTQyOSwiZXhwIjoxNzYwNzY2MzI5LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.MFIyW76_9DHMnLesp7_G95wTPAzJQ45zRRze3Z_YnYA	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiZTQ3MzQxNWMtMTQ3Yy00MmRjLTg5NWQtYTg3YzE4NWIwYjYzIiwidHlwZSI6InJlZnJlc2giLCJqdGkiOiI4YjkxNjgwZi1hZTI4LTQyNzktODdiOS03YzgzMWNhNTFlNTAiLCJpYXQiOjE3NjA3NjU0MjksImV4cCI6MTc2MzM1NzQyOSwiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.fYVdj3OlDCds-8W0sBulaeUbNlp6jOFpWyEbWJ5HKeY	2025-11-17 05:30:29.292	2025-10-18 05:30:29.297	2025-10-18 05:30:29.297
1634a8ff-99b2-49f8-b795-d7f19450c62e	cmgvqpaza0000kf6cmh62ub5w	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiMTYzNGE4ZmYtOTliMi00OWY4LWI3OTUtZDdmMTk0NTBjNjJlIiwiZW1haWwiOiJ0ZXN0OTk5QHRlc3QuY29tIiwid2FsbGV0QWRkcmVzcyI6bnVsbCwiaXNWZXJpZmllZCI6ZmFsc2UsImp0aSI6Ijc1Y2JiNzVkLTFmZTgtNDgwMC04OGVmLTZjYzc2ZGVjZDdlYyIsImlhdCI6MTc2MDc2NjMwMywiZXhwIjoxNzYwNzY3MjAzLCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.AswcTCP9CY-USwf5VT5kaZfmhRewn9_e6vvCuhwUnfw	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiMTYzNGE4ZmYtOTliMi00OWY4LWI3OTUtZDdmMTk0NTBjNjJlIiwidHlwZSI6InJlZnJlc2giLCJqdGkiOiIyNTQ3NzZhZS05OTZhLTQ4OWMtYjk3Yi0xYWUyYzI4NDY1ZmIiLCJpYXQiOjE3NjA3NjYzMDMsImV4cCI6MTc2MzM1ODMwMywiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.XYEUgWXTgc70tC6rVsCowR0x__yMZebwQc1YPydopC4	2025-11-17 05:45:03.052	2025-10-18 05:45:03.058	2025-10-18 05:45:03.058
86f3ef22-f58c-4e57-afb6-11e89aaea733	cmgvqpaza0000kf6cmh62ub5w	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiODZmM2VmMjItZjU4Yy00ZTU3LWFmYjYtMTFlODlhYWVhNzMzIiwiZW1haWwiOiJ0ZXN0OTk5QHRlc3QuY29tIiwid2FsbGV0QWRkcmVzcyI6bnVsbCwiaXNWZXJpZmllZCI6ZmFsc2UsImp0aSI6ImIxM2NjNmM1LWE5NDMtNDg3Mi04MzU5LTlkZmVkN2ViODIzMyIsImlhdCI6MTc2MDc2NjkyNiwiZXhwIjoxNzYwNzY3ODI2LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.cTkpHcUxsSTNeotDssVMpmQw9IJAntD_rDtJHVjyVXQ	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiODZmM2VmMjItZjU4Yy00ZTU3LWFmYjYtMTFlODlhYWVhNzMzIiwidHlwZSI6InJlZnJlc2giLCJqdGkiOiJhMmNjN2UwMC0wYjFmLTQwMTQtOTQ2YS0zYTlhN2UxNjA3MjkiLCJpYXQiOjE3NjA3NjY5MjYsImV4cCI6MTc2MzM1ODkyNiwiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.A-UTcpm8PhmbACNH_GmZ_mP7zlz_nR9QyJIRJSVOres	2025-11-17 05:55:26.898	2025-10-18 05:55:26.909	2025-10-18 05:55:26.909
e3e5d2be-7b02-416f-9e69-e9b276912c4d	cmgvqpaza0000kf6cmh62ub5w	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiZTNlNWQyYmUtN2IwMi00MTZmLTllNjktZTliMjc2OTEyYzRkIiwiZW1haWwiOiJ0ZXN0OTk5QHRlc3QuY29tIiwid2FsbGV0QWRkcmVzcyI6bnVsbCwiaXNWZXJpZmllZCI6ZmFsc2UsImp0aSI6IjQwZDFlMDBlLTdkMDctNDFkYy1hMzNiLTAzZWExODY0MGE0ZSIsImlhdCI6MTc2MDc2NzE0MiwiZXhwIjoxNzYwNzY4MDQyLCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.yVtiNy8qJZI7wB_PzAo6MhtzP8R-6aiC7HbeOy4A6jk	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiZTNlNWQyYmUtN2IwMi00MTZmLTllNjktZTliMjc2OTEyYzRkIiwidHlwZSI6InJlZnJlc2giLCJqdGkiOiJmZWRjNTE0ZC1mMzVhLTRiNTgtYjFlNC0zMWJiZDlmN2Q5NzEiLCJpYXQiOjE3NjA3NjcxNDIsImV4cCI6MTc2MzM1OTE0MiwiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.HREoSG1ktKpriMBLfmgdTvJnbmk7ObNtgwxocx6cq-s	2025-11-17 05:59:02.87	2025-10-18 05:59:02.88	2025-10-18 05:59:02.88
87df71d3-e4b5-406c-b0ba-28bce5f41e20	cmgvqpaza0000kf6cmh62ub5w	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiODdkZjcxZDMtZTRiNS00MDZjLWIwYmEtMjhiY2U1ZjQxZTIwIiwiZW1haWwiOiJ0ZXN0OTk5QHRlc3QuY29tIiwid2FsbGV0QWRkcmVzcyI6bnVsbCwiaXNWZXJpZmllZCI6ZmFsc2UsImp0aSI6IjgxZmJkZWIwLTg2NmItNDIxYi04MTE4LWU3MmMzMWNhYTBjZSIsImlhdCI6MTc2MDc2NzI0MiwiZXhwIjoxNzYwNzY4MTQyLCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.LI85wYjv0canwJg731oM-9p1kwWw2zwLZoKjo3zE62g	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiODdkZjcxZDMtZTRiNS00MDZjLWIwYmEtMjhiY2U1ZjQxZTIwIiwidHlwZSI6InJlZnJlc2giLCJqdGkiOiI5YjlkOTQ3Ny1jNjcwLTQ0ZTQtYjY3Zi03YjljNmVmNjVlMWEiLCJpYXQiOjE3NjA3NjcyNDIsImV4cCI6MTc2MzM1OTI0MiwiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.wtyazYpyjrt6WiPWjnaUMAd8d6yKrHy7f23hfbggzfc	2025-11-17 06:00:42.208	2025-10-18 06:00:42.213	2025-10-18 06:00:42.213
95d1da7e-2ed6-4b71-abcd-fa694abe8df5	cmgvqpaza0000kf6cmh62ub5w	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiOTVkMWRhN2UtMmVkNi00YjcxLWFiY2QtZmE2OTRhYmU4ZGY1IiwiZW1haWwiOiJ0ZXN0OTk5QHRlc3QuY29tIiwid2FsbGV0QWRkcmVzcyI6bnVsbCwiaXNWZXJpZmllZCI6ZmFsc2UsImp0aSI6ImI5Nzg1ODNmLWNjNTAtNGU4MS04NWQ3LTAwMzcxZmFhM2QwOCIsImlhdCI6MTc2MDc2NzM3NSwiZXhwIjoxNzYwNzY4Mjc1LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.syIyISG8aFTYv17BlW5kPPtgbyw2FJW6RtqGHZhy6nE	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiOTVkMWRhN2UtMmVkNi00YjcxLWFiY2QtZmE2OTRhYmU4ZGY1IiwidHlwZSI6InJlZnJlc2giLCJqdGkiOiJkODBjNjJkYS1mOTIwLTQxZDctOGVmMC05YTY0Yzk0MzE4NzEiLCJpYXQiOjE3NjA3NjczNzUsImV4cCI6MTc2MzM1OTM3NSwiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.h5JsNL-UeX1CFyh-C1SmMU0rOsrRql9qyNRiRjyQHHQ	2025-11-17 06:02:55.142	2025-10-18 06:02:55.147	2025-10-18 06:02:55.147
e0d40921-41d7-43d5-a597-03767a47e753	cmgvqpaza0000kf6cmh62ub5w	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiZTBkNDA5MjEtNDFkNy00M2Q1LWE1OTctMDM3NjdhNDdlNzUzIiwiZW1haWwiOiJ0ZXN0OTk5QHRlc3QuY29tIiwid2FsbGV0QWRkcmVzcyI6bnVsbCwiaXNWZXJpZmllZCI6ZmFsc2UsImp0aSI6ImEyMTQ2ZjY5LTFhMzgtNDEyMi1iMWE4LTgxOGM0MmE4OGE0ZSIsImlhdCI6MTc2MDc2NzYwMCwiZXhwIjoxNzYwNzY4NTAwLCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.unpthg0cWw6A0pG46tA6NxwQyX4odrOrt2b8JyEGqWA	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiZTBkNDA5MjEtNDFkNy00M2Q1LWE1OTctMDM3NjdhNDdlNzUzIiwidHlwZSI6InJlZnJlc2giLCJqdGkiOiIzY2RkMWFjOS03NmY3LTQ5MjItYjA2Zi05Y2VlMjJkOTdkOWEiLCJpYXQiOjE3NjA3Njc2MDAsImV4cCI6MTc2MzM1OTYwMCwiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.ibNRj6UjPblu6jOJt6pokN0njW29XZ-mnrkTCGEM68M	2025-11-17 06:06:40.824	2025-10-18 06:06:40.874	2025-10-18 06:06:40.874
7ba8fe5b-803e-4f37-a027-b0bdbedc70ff	cmgvqpaza0000kf6cmh62ub5w	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiN2JhOGZlNWItODAzZS00ZjM3LWEwMjctYjBiZGJlZGM3MGZmIiwiZW1haWwiOiJ0ZXN0OTk5QHRlc3QuY29tIiwid2FsbGV0QWRkcmVzcyI6bnVsbCwiaXNWZXJpZmllZCI6ZmFsc2UsImp0aSI6IjFhMmFjNWM0LTI1MzAtNDdhYi1iYmVkLTZjZDRlNzRmNjBhYiIsImlhdCI6MTc2MDc2Nzc1NiwiZXhwIjoxNzYwNzY4NjU2LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.s0pHPhdyz7cIlpyKr3iUWjDL18nNJLdI4sRvWecp5g8	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiN2JhOGZlNWItODAzZS00ZjM3LWEwMjctYjBiZGJlZGM3MGZmIiwidHlwZSI6InJlZnJlc2giLCJqdGkiOiIxYzNmOGRlYS01MjliLTRiYzUtYjdjYy0xODE3MjZlNmUzNWEiLCJpYXQiOjE3NjA3Njc3NTYsImV4cCI6MTc2MzM1OTc1NiwiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.606zI3EsMUz-pHL408lAalg4YNP6rZBNhPUGb4Xtx-4	2025-11-17 06:09:16.4	2025-10-18 06:09:16.405	2025-10-18 06:09:16.405
c24e3448-7df7-40a3-a916-a6a5126cbbd6	cmgvqpaza0000kf6cmh62ub5w	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiYzI0ZTM0NDgtN2RmNy00MGEzLWE5MTYtYTZhNTEyNmNiYmQ2IiwiZW1haWwiOiJ0ZXN0OTk5QHRlc3QuY29tIiwid2FsbGV0QWRkcmVzcyI6bnVsbCwiaXNWZXJpZmllZCI6ZmFsc2UsImp0aSI6ImZmYTc4ZmEzLTE5ZGItNDRhZi04YjI1LTQ3NDc0MmRmNjEwZiIsImlhdCI6MTc2MDc2Nzc2NSwiZXhwIjoxNzYwNzY4NjY1LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.E0iMCtm3qoESf07pUWCLJCADt2yZ8AVr7uut5TXU-RM	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2cXBhemEwMDAwa2Y2Y21oNjJ1YjV3Iiwic2Vzc2lvbklkIjoiYzI0ZTM0NDgtN2RmNy00MGEzLWE5MTYtYTZhNTEyNmNiYmQ2IiwidHlwZSI6InJlZnJlc2giLCJqdGkiOiI2MjBmMDkwMS0xMmFkLTQ5YzEtOTdkYS03ZTAzYWJlZTg4ODMiLCJpYXQiOjE3NjA3Njc3NjUsImV4cCI6MTc2MzM1OTc2NSwiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.Hn6lvTzdU7UjlGB-Va_KEEwW5mzAuT7HSsS2Jkhf_m8	2025-11-17 06:09:25.619	2025-10-18 06:09:25.627	2025-10-18 06:09:25.627
2cafff3a-ca59-4377-8a3b-78d2f4a65f08	cmgvx4nri0000tb56kh6dggp0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2eDRucmkwMDAwdGI1NmtoNmRnZ3AwIiwic2Vzc2lvbklkIjoiMmNhZmZmM2EtY2E1OS00Mzc3LThhM2ItNzhkMmY0YTY1ZjA4IiwiZW1haWwiOiJ0ZXN0MTc2MDc3MDIyM0B0ZXN0LmNvbSIsIndhbGxldEFkZHJlc3MiOm51bGwsImlzVmVyaWZpZWQiOmZhbHNlLCJqdGkiOiIyMGY4YjNhZC1hNjVkLTRkODQtYTgzMi01N2Y5NjM5ODJjNDIiLCJpYXQiOjE3NjA3NzAyMjMsImV4cCI6MTc2MDc3MTEyMywiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.Mu5QaBR2tAMhdnpFvDouCmUB4xFFjwiAUibSspDQtmc	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2eDRucmkwMDAwdGI1NmtoNmRnZ3AwIiwic2Vzc2lvbklkIjoiMmNhZmZmM2EtY2E1OS00Mzc3LThhM2ItNzhkMmY0YTY1ZjA4IiwidHlwZSI6InJlZnJlc2giLCJqdGkiOiJlMDU1ZTZjMy1mMzY5LTQ2ZmMtYjYyYi0wYWZhZjcyMjE1NjEiLCJpYXQiOjE3NjA3NzAyMjMsImV4cCI6MTc2MzM2MjIyMywiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.OmlTMUo4UZ1-oRJ0vrodbS_pnTH0mRsJ9uJNEcvgB8A	2025-11-17 06:50:23.701	2025-10-18 06:50:23.712	2025-10-18 06:50:23.712
0bf2ce60-986a-46e1-becc-8ed3883e25c5	cmgvx4zf00001tb56yob022y0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2eDR6ZjAwMDAxdGI1NnlvYjAyMnkwIiwic2Vzc2lvbklkIjoiMGJmMmNlNjAtOTg2YS00NmUxLWJlY2MtOGVkMzg4M2UyNWM1IiwiZW1haWwiOiJ0ZXN0MTc2MDc3MDIzOEB0ZXN0LmNvbSIsIndhbGxldEFkZHJlc3MiOm51bGwsImlzVmVyaWZpZWQiOmZhbHNlLCJqdGkiOiI1ZTZlY2Y1Zi04NDdkLTQxMDktOTkyZS0xY2ZiNGI4MTFmN2MiLCJpYXQiOjE3NjA3NzAyMzgsImV4cCI6MTc2MDc3MTEzOCwiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.YGuRbHgGc4r-teaEUaVB35hiy5su2M6eBDhTATCRQHI	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd2eDR6ZjAwMDAxdGI1NnlvYjAyMnkwIiwic2Vzc2lvbklkIjoiMGJmMmNlNjAtOTg2YS00NmUxLWJlY2MtOGVkMzg4M2UyNWM1IiwidHlwZSI6InJlZnJlc2giLCJqdGkiOiI5YTAxYjZhMy1mOTdjLTRkMTUtOGRjYi1iYWI5YmJkZjRmZmEiLCJpYXQiOjE3NjA3NzAyMzgsImV4cCI6MTc2MzM2MjIzOCwiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.67h_D1Onxx4JpMLMk5yGhyfwo6ArRgVnpFY5qaBD8XE	2025-11-17 06:50:38.799	2025-10-18 06:50:38.805	2025-10-18 06:50:38.805
4ecde5ed-d5ba-4809-9d6a-0e30f5b45360	cmgwl5fbu0002tb56tz5q8dy9	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd3bDVmYnUwMDAydGI1NnR6NXE4ZHk5Iiwic2Vzc2lvbklkIjoiNGVjZGU1ZWQtZDViYS00ODA5LTlkNmEtMGUzMGY1YjQ1MzYwIiwiZW1haWwiOiJmdWxsdGVzdDE3NjA4MTA1NjlAdGVzdC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiZTkwYWQzYTAtYzNmMi00NWQ3LWI2MTktYzFkODY4NTk0ZGUwIiwiaWF0IjoxNzYwODEwNTcwLCJleHAiOjE3NjA4MTE0NzAsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.EGqF6YlvkhOV8tiWKK4XDlqCj6hbmyfhHrUQZE6PryE	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd3bDVmYnUwMDAydGI1NnR6NXE4ZHk5Iiwic2Vzc2lvbklkIjoiNGVjZGU1ZWQtZDViYS00ODA5LTlkNmEtMGUzMGY1YjQ1MzYwIiwidHlwZSI6InJlZnJlc2giLCJqdGkiOiI0NjcwYTYxMy00ODRhLTQwYTgtOGMwNi1jMTI4ZTQwN2U0MjYiLCJpYXQiOjE3NjA4MTA1NzAsImV4cCI6MTc2MzQwMjU3MCwiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.Ew2wLtbzTZ90stsXEFyKflOZMyb-XmdKwjvOTBsN_qE	2025-11-17 18:02:50.208	2025-10-18 18:02:50.254	2025-10-18 18:02:50.254
d18ee30f-a069-45aa-9e59-f93656c951a2	cmgwlg2bs0000ougoiu1utzzt	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd3bGcyYnMwMDAwb3Vnb2l1MXV0enp0Iiwic2Vzc2lvbklkIjoiZDE4ZWUzMGYtYTA2OS00NWFhLTllNTktZjkzNjU2Yzk1MWEyIiwiZW1haWwiOiJmdWxsdGVzdDE3NjA4MTEwNjZAdGVzdC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiM2E0MmUyOWEtODY2Zi00NTA4LThlMjMtOGMzZWNkZTFlNzY2IiwiaWF0IjoxNzYwODExMDY2LCJleHAiOjE3NjA4MTE5NjYsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0._zodkVVAou_K5DCr2xCRYTN0ic_BAL90DUB_HtIZEsc	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd3bGcyYnMwMDAwb3Vnb2l1MXV0enp0Iiwic2Vzc2lvbklkIjoiZDE4ZWUzMGYtYTA2OS00NWFhLTllNTktZjkzNjU2Yzk1MWEyIiwidHlwZSI6InJlZnJlc2giLCJqdGkiOiIwMzZhNDg4MC1jZjBhLTRlOGMtOTgyMC1jNjU2YTE2OWUzNmEiLCJpYXQiOjE3NjA4MTEwNjYsImV4cCI6MTc2MzQwMzA2NiwiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.YdgWRuJnsO4ItFtzYAKBsE2Xe6rfzOCzTRNGMC_AmzE	2025-11-17 18:11:06.573	2025-10-18 18:11:06.582	2025-10-18 18:11:06.582
5a586c0c-18e1-403d-b8e5-56cf1f44d7c2	cmgwlj4xu0001ougo9zbn5swt	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd3bGo0eHUwMDAxb3Vnbzl6Ym41c3d0Iiwic2Vzc2lvbklkIjoiNWE1ODZjMGMtMThlMS00MDNkLWI4ZTUtNTZjZjFmNDRkN2MyIiwiZW1haWwiOiJ2b2ljZXRlc3QxMjNAdGVzdC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiYjEwNWQ4NGUtMzk0YS00YTU1LWE0MWUtNjA0MGJlNzQzNjkyIiwiaWF0IjoxNzYwODExMjA5LCJleHAiOjE3NjA4MTIxMDksImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.2rPTHB0kE5v96ZJVxPgQbXjQPJwvUdk-r_qk1ZYUwDo	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd3bGo0eHUwMDAxb3Vnbzl6Ym41c3d0Iiwic2Vzc2lvbklkIjoiNWE1ODZjMGMtMThlMS00MDNkLWI4ZTUtNTZjZjFmNDRkN2MyIiwidHlwZSI6InJlZnJlc2giLCJqdGkiOiI0YTE1ZTU2Mi05NDA1LTQyMzAtODE3My0xOTg5ODI4M2JmYjAiLCJpYXQiOjE3NjA4MTEyMDksImV4cCI6MTc2MzQwMzIwOSwiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.TRFOB0VppEoiOleFRUIw8Owaio9eL73rI_DvSZhgK7k	2025-11-17 18:13:29.925	2025-10-18 18:13:29.931	2025-10-18 18:13:29.931
test_session	cmgu2gn420000qlwcc82uc6sp	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJjbWd1MmduNDIwMDAwcWx3Y2M4MnVjNnNwIiwic2Vzc2lvbklkIjoiZWMwZTEwYTYtZTdlNi00YmY0LThlMGEtOTUyN2ExOWFmYzIzIiwiZW1haWwiOiJsYXVyaWUuYXJtc3Ryb25nOTZAZ21haWwuY29tIiwid2FsbGV0QWRkcmVzcyI6bnVsbCwiaXNWZXJpZmllZCI6ZmFsc2UsImp0aSI6IjgxZDVlODQyLTlmMzctNGIzNC1hZjVlLTI5ZDgwNTJjN2E5NiIsImlhdCI6MTc2MDgxMzYyNSwiZXhwIjoxNzYwOTAwMDI1LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.iOg_cnytBxsM1myhj-LEYhzbNwGMLzRaVHtlnmSOcAI	refresh_test	2025-10-19 18:55:09.089	2025-10-18 18:55:09.089	2025-10-18 18:55:09.089
b208c4d2-9d43-42e9-977e-f99514243d05	1568087c-fad5-425e-a6d8-f89e92d947c0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxNTY4MDg3Yy1mYWQ1LTQyNWUtYTZkOC1mODllOTJkOTQ3YzAiLCJzZXNzaW9uSWQiOiJiMjA4YzRkMi05ZDQzLTQyZTktOTc3ZS1mOTk1MTQyNDNkMDUiLCJlbWFpbCI6ImFyX3R1cm9fbW9Ab3V0bG9vay5lcyIsIndhbGxldEFkZHJlc3MiOm51bGwsImlzVmVyaWZpZWQiOmZhbHNlLCJqdGkiOiI3MTZmNjQxMC1kZjZhLTRjMmMtOTNiZS05OTAxMDc2MGE1YjAiLCJpYXQiOjE3NjUyNDQ1MzMsImV4cCI6MTc2NTI0NTQzMywiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.c631FsXs6_Cz1ulEExq18XST4T2C6cmpVE-lEvCD2qc	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxNTY4MDg3Yy1mYWQ1LTQyNWUtYTZkOC1mODllOTJkOTQ3YzAiLCJzZXNzaW9uSWQiOiJiMjA4YzRkMi05ZDQzLTQyZTktOTc3ZS1mOTk1MTQyNDNkMDUiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6Ijk1ZGZiZDJiLTAxY2ItNDcxZi1hOThiLWE5ZTlmMjY0MTk1OSIsImlhdCI6MTc2NTI0NDUzMywiZXhwIjoxNzY3ODM2NTMzLCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.tam4ukDrojHlfvpNu1tw2C7ZJ7FDbeRb5-t59XnbzUM	2026-01-08 01:42:13.043	2025-12-09 01:42:13.052	2025-12-09 01:42:13.052
092bf305-132e-46f4-9fc2-4a4e1f60fb19	38e69ff3-0f78-4e7f-9b04-9bc7d2fdac60	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIzOGU2OWZmMy0wZjc4LTRlN2YtOWIwNC05YmM3ZDJmZGFjNjAiLCJzZXNzaW9uSWQiOiIwOTJiZjMwNS0xMzJlLTQ2ZjQtOWZjMi00YTRlMWY2MGZiMTkiLCJlbWFpbCI6Impob25ueUBhci1tZWRpaWEuY29tIiwid2FsbGV0QWRkcmVzcyI6bnVsbCwiaXNWZXJpZmllZCI6ZmFsc2UsImp0aSI6ImMxMjY1MzM3LTI4NjItNDUxNi05MmExLWM4OTZlZTBlOGVmYiIsImlhdCI6MTc2NTQ4NDQyNCwiZXhwIjoxNzY1NDg1MzI0LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.bIxpemWD_-ecH9tpPohT-C9ZTBYcqLmWLPQITJFsLqU	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIzOGU2OWZmMy0wZjc4LTRlN2YtOWIwNC05YmM3ZDJmZGFjNjAiLCJzZXNzaW9uSWQiOiIwOTJiZjMwNS0xMzJlLTQ2ZjQtOWZjMi00YTRlMWY2MGZiMTkiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6IjBkYTEzNWY2LTJiZjctNGViNi05OWNjLTRhNTg1OTZmODkwNSIsImlhdCI6MTc2NTQ4NDQyNCwiZXhwIjoxNzY4MDc2NDI0LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.ox476w3619J7K2IRF-LG-r_lqiGSlPKEyz3R3onsC0k	2026-01-10 20:20:24.586	2025-12-11 20:20:24.604	2025-12-11 20:20:24.604
8f23262f-43a9-44e1-bfa5-23c40c3f5f83	6ffe211d-5fd8-47e1-98c4-26f1383f3f98	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiI4ZjIzMjYyZi00M2E5LTQ0ZTEtYmZhNS0yM2M0MGMzZjVmODMiLCJlbWFpbCI6Impob25ueWFyYXlhN0BnbWFpbC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiNzI2YWJiYjEtNzc0OS00MTNhLWIyM2YtMWY5MzQzZThlMzRmIiwiaWF0IjoxNzY1NTA1NzUzLCJleHAiOjE3NjU1MDY2NTMsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.bgbsyNWLf157Px0upBmPzQDgDB-YBToGnnuXqu5q1EY	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiI4ZjIzMjYyZi00M2E5LTQ0ZTEtYmZhNS0yM2M0MGMzZjVmODMiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6IjNhYmQ5MjlmLTU1MDItNGI3Yi04YmRkLTYxZTQzZTZmYTQyNyIsImlhdCI6MTc2NTUwNTc1MywiZXhwIjoxNzY4MDk3NzUzLCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.OYdjvl-IO_5CI-qzTXvDYKiSGYVo-Kc9z2Dl8jddzGU	2026-01-11 02:15:53.723	2025-12-12 02:15:53.729	2025-12-12 02:15:53.729
666618b8-2ac1-4e0c-a548-dea475d205b4	6ffe211d-5fd8-47e1-98c4-26f1383f3f98	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiI2NjY2MThiOC0yYWMxLTRlMGMtYTU0OC1kZWE0NzVkMjA1YjQiLCJlbWFpbCI6Impob25ueWFyYXlhN0BnbWFpbC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiZWJkOTk3ZmItMzAxZS00YzUzLTk1MjUtNTZiZjdkZTU5M2M1IiwiaWF0IjoxNzY1NTE3OTkyLCJleHAiOjE3NjU1MTg4OTIsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.S6spacWnaNogChwf208DLP4EGwjUidDdnx_fHTCTmXg	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiI2NjY2MThiOC0yYWMxLTRlMGMtYTU0OC1kZWE0NzVkMjA1YjQiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6ImE5OTBlYjFmLTdkMDctNDk3OS1iMmZhLWQwYjg3Y2U0YjMyZSIsImlhdCI6MTc2NTUxNzk5MiwiZXhwIjoxNzY4MTA5OTkyLCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.AlFGTI4vYzm6gQqBeZk2tA7jRv9yTiUVRKFnUPzic8Q	2026-01-11 05:39:52.483	2025-12-12 05:39:52.49	2025-12-12 05:39:52.49
9b20a33b-8a00-42d3-8ee6-2560b41ab331	6ffe211d-5fd8-47e1-98c4-26f1383f3f98	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiI5YjIwYTMzYi04YTAwLTQyZDMtOGVlNi0yNTYwYjQxYWIzMzEiLCJlbWFpbCI6Impob25ueWFyYXlhN0BnbWFpbC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiZjgzNGQ0NGEtY2ViZS00ZmY3LWE2NDItYTYxN2YyN2E1ZGY4IiwiaWF0IjoxNzY1NTE4MDEwLCJleHAiOjE3NjU1MTg5MTAsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.tByCzemHnnNlmsNp3_3WjSdihIcTpGJQ2YiRCZrA2Sg	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiI5YjIwYTMzYi04YTAwLTQyZDMtOGVlNi0yNTYwYjQxYWIzMzEiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6ImYyMmJiZTIzLTY5NWUtNGU1NC1hMWEzLTA5MGUwODNhMGU3MCIsImlhdCI6MTc2NTUxODAxMCwiZXhwIjoxNzY4MTEwMDEwLCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.vf_Zkx-8xPtT6I6E6t5V8TVgWGkvXUxAPquUq0YMsXI	2026-01-11 05:40:10.45	2025-12-12 05:40:10.461	2025-12-12 05:40:10.461
91ca4fa5-4700-4b6c-9bcb-bb9a0797335f	6ffe211d-5fd8-47e1-98c4-26f1383f3f98	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiI5MWNhNGZhNS00NzAwLTRiNmMtOWJjYi1iYjlhMDc5NzMzNWYiLCJlbWFpbCI6Impob25ueWFyYXlhN0BnbWFpbC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiYmQzMDMxOWYtODRmZS00NGY2LWJlZjEtNGZhZDczYjlmOGYyIiwiaWF0IjoxNzY1NTE4OTc0LCJleHAiOjE3NjU1MTk4NzQsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.FjZKF25TjpIrDm3EBvXnDc9aXneJcC1Ubk_Vl2bpM9Q	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiI5MWNhNGZhNS00NzAwLTRiNmMtOWJjYi1iYjlhMDc5NzMzNWYiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6IjllNDgwNWI0LWYwOTUtNDBkNC1iYWViLTRjMTdmODZjNzdhYSIsImlhdCI6MTc2NTUxODk3NCwiZXhwIjoxNzY4MTEwOTc0LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.uiHO2Ikq2KZnWUMD2osUluz1Kz7Rtxw_GU5yqovXJGI	2026-01-11 05:56:14.362	2025-12-12 05:56:14.368	2025-12-12 05:56:14.368
db2b8c66-eba8-44a4-a446-49f9da06ecb7	6ffe211d-5fd8-47e1-98c4-26f1383f3f98	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiJkYjJiOGM2Ni1lYmE4LTQ0YTQtYTQ0Ni00OWY5ZGEwNmVjYjciLCJlbWFpbCI6Impob25ueWFyYXlhN0BnbWFpbC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiYTk0NTdlZDAtNjU3Ni00MGZjLTlmZWUtMThlYjNiZjhjYTg2IiwiaWF0IjoxNzY1NTE5MzU4LCJleHAiOjE3NjU1MjAyNTgsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.NLHf1Ksyx-xtnT2nlUGfrCpmLVQr3413sXDBRMR6Xf8	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiJkYjJiOGM2Ni1lYmE4LTQ0YTQtYTQ0Ni00OWY5ZGEwNmVjYjciLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6ImIxMDUzMWJkLTcxMDgtNDVmYy1hNTgyLTM2MTRlNmQ2NzY4NCIsImlhdCI6MTc2NTUxOTM1OCwiZXhwIjoxNzY4MTExMzU4LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.RxYU9wPbPOPSOpqmDmdFJb7GV2Ob8VhD7K7titddTuk	2026-01-11 06:02:38.541	2025-12-12 06:02:38.546	2025-12-12 06:02:38.546
092c4d0e-c703-43e1-9906-aa65b06252f3	6ffe211d-5fd8-47e1-98c4-26f1383f3f98	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiIwOTJjNGQwZS1jNzAzLTQzZTEtOTkwNi1hYTY1YjA2MjUyZjMiLCJlbWFpbCI6Impob25ueWFyYXlhN0BnbWFpbC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiOTk1MjU3MmItOTc2MS00ZjMxLTg4YzYtOTZjMjAxNzE5Y2YzIiwiaWF0IjoxNzY1NTE5NzEwLCJleHAiOjE3NjU1MjA2MTAsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.QtGH2scpSLBv-Yd6rKLd3kd3JlbbyZ2DOwqDuEodtZA	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiIwOTJjNGQwZS1jNzAzLTQzZTEtOTkwNi1hYTY1YjA2MjUyZjMiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6IjhmN2JjZTdmLTlhMmMtNDNlNS1iZGViLTZlMjUzZjU3MWNjYSIsImlhdCI6MTc2NTUxOTcxMCwiZXhwIjoxNzY4MTExNzEwLCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.XG9aToSxQL00gGj-E95UKFoawaIz6sawwAX9T5d725Q	2026-01-11 06:08:30.064	2025-12-12 06:08:30.068	2025-12-12 06:08:30.068
7bc24fc1-82f5-4715-baec-b4777e3ad2d4	6ffe211d-5fd8-47e1-98c4-26f1383f3f98	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiI3YmMyNGZjMS04MmY1LTQ3MTUtYmFlYy1iNDc3N2UzYWQyZDQiLCJlbWFpbCI6Impob25ueWFyYXlhN0BnbWFpbC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiODFmMjI2MTEtN2Y5NC00Nzc5LWE1MmUtYjg2YzQ2ZWY5MmU5IiwiaWF0IjoxNzY1NTIwMTI2LCJleHAiOjE3NjU1MjEwMjYsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.rbNjS26knSRTDDLQ2muUby6YzdG_lB-kUj5WYzgjlOo	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiI3YmMyNGZjMS04MmY1LTQ3MTUtYmFlYy1iNDc3N2UzYWQyZDQiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6IjIyOTk2YjViLTMyNTYtNGQ0Zi1hYzY0LWEyNjY3OWQ2OTFmMSIsImlhdCI6MTc2NTUyMDEyNiwiZXhwIjoxNzY4MTEyMTI2LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.9Ljn5ySXfvFz-rIALn0tM4yQK2VMiYpAa2x4nm4Tzgg	2026-01-11 06:15:26.301	2025-12-12 06:15:26.307	2025-12-12 06:15:26.307
fb7d5ccd-842a-4616-8db4-9238b786e149	6ffe211d-5fd8-47e1-98c4-26f1383f3f98	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiJmYjdkNWNjZC04NDJhLTQ2MTYtOGRiNC05MjM4Yjc4NmUxNDkiLCJlbWFpbCI6Impob25ueWFyYXlhN0BnbWFpbC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiZWYwYzI1ZWItNGY3My00YTI3LWJiNWYtOTczNDMyODIxMjRjIiwiaWF0IjoxNzY1NTIwMTUwLCJleHAiOjE3NjU1MjEwNTAsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.VFIaGdaZyVHJ0K2lIzy0gjKrK0ETGcR7nprTIhZH-fc	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiJmYjdkNWNjZC04NDJhLTQ2MTYtOGRiNC05MjM4Yjc4NmUxNDkiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6IjA3YTgzYmZjLTUzNjMtNDRkOC05ZmQ0LTkwNjkxMDQ1YmYzMSIsImlhdCI6MTc2NTUyMDE1MCwiZXhwIjoxNzY4MTEyMTUwLCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.evCXedftlp7hW7arNNlNK2EhNY-wDtxq8kyWwsP5v9U	2026-01-11 06:15:50.766	2025-12-12 06:15:50.77	2025-12-12 06:15:50.77
ef3b93e0-be01-4301-b77b-fa5c3c68c544	6ffe211d-5fd8-47e1-98c4-26f1383f3f98	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiJlZjNiOTNlMC1iZTAxLTQzMDEtYjc3Yi1mYTVjM2M2OGM1NDQiLCJlbWFpbCI6Impob25ueWFyYXlhN0BnbWFpbC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiOWY5MDk0YjItNGExYi00NmFmLThhYjEtN2ZhMWUwYmIzOTI2IiwiaWF0IjoxNzY1NTIxNzU0LCJleHAiOjE3NjU1MjI2NTQsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.aPV43llXEBosCGzWISJB8OD3CjiznDMIsSMhR5eiNMA	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiJlZjNiOTNlMC1iZTAxLTQzMDEtYjc3Yi1mYTVjM2M2OGM1NDQiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6IjBjMWE1NDFkLWZlODgtNDU3OS04YTE4LWY5ZDc0Mzk3MGM4MyIsImlhdCI6MTc2NTUyMTc1NCwiZXhwIjoxNzY4MTEzNzU0LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.wwqWWDo6yxbENQGfmSCkWAi59h5LLInLzqvVORIHLDk	2026-01-11 06:42:34.105	2025-12-12 06:42:34.11	2025-12-12 06:42:34.11
c9dceb05-df80-4a4f-93fd-9d85dcc5df03	6ffe211d-5fd8-47e1-98c4-26f1383f3f98	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiJjOWRjZWIwNS1kZjgwLTRhNGYtOTNmZC05ZDg1ZGNjNWRmMDMiLCJlbWFpbCI6Impob25ueWFyYXlhN0BnbWFpbC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiOWI4OTZjNmYtNGFmMC00ZWQ5LWFkOGItYjZmOWQwYTRmZWMzIiwiaWF0IjoxNzY1NTM0MzI4LCJleHAiOjE3NjU1MzUyMjgsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.Kh0mu0DuzzbR1WsAUO21g0jAshNicgVvJb1fyC7Abf0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiJjOWRjZWIwNS1kZjgwLTRhNGYtOTNmZC05ZDg1ZGNjNWRmMDMiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6ImRmNTk0MDZmLTg3NzEtNGRlNS04YjA4LTYwMGEwMDZlMzE0MSIsImlhdCI6MTc2NTUzNDMyOCwiZXhwIjoxNzY4MTI2MzI4LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.jxpog2Ka3CMEyW6DPnIRnmI7_lxP5UYklmUNjZKyhvQ	2026-01-11 10:12:08.348	2025-12-12 10:12:08.353	2025-12-12 10:12:08.353
cb8d6905-b79c-43dc-9e69-eedeed06e54d	6ffe211d-5fd8-47e1-98c4-26f1383f3f98	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiJjYjhkNjkwNS1iNzljLTQzZGMtOWU2OS1lZWRlZWQwNmU1NGQiLCJlbWFpbCI6Impob25ueWFyYXlhN0BnbWFpbC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiYzY5OWRhMTgtN2RiMy00ZmViLTg4NmQtYWNmOTUxNzQ1ZWY1IiwiaWF0IjoxNzY1NTY5MTY5LCJleHAiOjE3NjU1NzAwNjksImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.GnwuI1KKAKQkytWZrsWSfORXY-DlwIGMsbcooudpxjg	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiJjYjhkNjkwNS1iNzljLTQzZGMtOWU2OS1lZWRlZWQwNmU1NGQiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6IjdkMGZiMGQyLWNkZTktNDFlZC05YzYwLTkyYTZiYzYwYmY1MyIsImlhdCI6MTc2NTU2OTE2OSwiZXhwIjoxNzY4MTYxMTY5LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.bdJP4Mgo7n0-vup7YuDGRGL7hN27l0ElvQjsMODIKTA	2026-01-11 19:52:49.89	2025-12-12 19:52:49.895	2025-12-12 19:52:49.895
a7dd7af1-6117-40b4-a50a-f7090a5b27fb	38e69ff3-0f78-4e7f-9b04-9bc7d2fdac60	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIzOGU2OWZmMy0wZjc4LTRlN2YtOWIwNC05YmM3ZDJmZGFjNjAiLCJzZXNzaW9uSWQiOiJhN2RkN2FmMS02MTE3LTQwYjQtYTUwYS1mNzA5MGE1YjI3ZmIiLCJlbWFpbCI6Impob25ueUBhci1tZWRpaWEuY29tIiwid2FsbGV0QWRkcmVzcyI6bnVsbCwiaXNWZXJpZmllZCI6ZmFsc2UsImp0aSI6ImM5MjczNDBiLTg3ZDQtNGEyNy05MzJhLTg0NTIwMTUxZjE3YiIsImlhdCI6MTc2NTU3MDAzNSwiZXhwIjoxNzY1NTcwOTM1LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.5xJhfgWYcRqoZXqeOV0C6z28UNvEdAQqX2gmvfEoa68	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIzOGU2OWZmMy0wZjc4LTRlN2YtOWIwNC05YmM3ZDJmZGFjNjAiLCJzZXNzaW9uSWQiOiJhN2RkN2FmMS02MTE3LTQwYjQtYTUwYS1mNzA5MGE1YjI3ZmIiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6ImVmMzc4ZjcyLWQ1ZTQtNDE0Yy04NjhmLTVjNGI0MzJmNDZmYSIsImlhdCI6MTc2NTU3MDAzNSwiZXhwIjoxNzY4MTYyMDM1LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.BseCCnSfAbjEpo8V1IL0shXQve3h4fR72FVNs_Ek9Vw	2026-01-11 20:07:15.057	2025-12-12 20:07:15.062	2025-12-12 20:07:15.062
b57d01f6-7c14-41a2-b63c-3a61b9642dbf	38e69ff3-0f78-4e7f-9b04-9bc7d2fdac60	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIzOGU2OWZmMy0wZjc4LTRlN2YtOWIwNC05YmM3ZDJmZGFjNjAiLCJzZXNzaW9uSWQiOiJiNTdkMDFmNi03YzE0LTQxYTItYjYzYy0zYTYxYjk2NDJkYmYiLCJlbWFpbCI6Impob25ueUBhci1tZWRpaWEuY29tIiwid2FsbGV0QWRkcmVzcyI6bnVsbCwiaXNWZXJpZmllZCI6ZmFsc2UsImp0aSI6ImJlMzdhNzg5LWNiODMtNDlmMi04NWM0LWJmYTAwMjJjNmI2MyIsImlhdCI6MTc2NTU3MDQxMywiZXhwIjoxNzY1NTcxMzEzLCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.vI2bYNZedRzan0TrJrNKZaAFWm9ytcm2snE4o4NTDY8	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIzOGU2OWZmMy0wZjc4LTRlN2YtOWIwNC05YmM3ZDJmZGFjNjAiLCJzZXNzaW9uSWQiOiJiNTdkMDFmNi03YzE0LTQxYTItYjYzYy0zYTYxYjk2NDJkYmYiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6IjU0M2FkNTI5LTgyYzEtNDljNy04ZTk0LTA1MTQ2NjIxZjUzYSIsImlhdCI6MTc2NTU3MDQxMywiZXhwIjoxNzY4MTYyNDEzLCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.H61MLurm4im3NZXH0OK3Cb7Mdcwm4vwaZao2ZLAYLqo	2026-01-11 20:13:33.235	2025-12-12 20:13:33.24	2025-12-12 20:13:33.24
cfe70848-d404-4d66-b2f3-d16417710f9f	0a4ed904-e9c9-4cc1-b1e7-3e7f4ba173a1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwYTRlZDkwNC1lOWM5LTRjYzEtYjFlNy0zZTdmNGJhMTczYTEiLCJzZXNzaW9uSWQiOiJjZmU3MDg0OC1kNDA0LTRkNjYtYjJmMy1kMTY0MTc3MTBmOWYiLCJlbWFpbCI6ImJyYWRoaW1lbDAxQGdtYWlsLmNvbSIsIndhbGxldEFkZHJlc3MiOm51bGwsImlzVmVyaWZpZWQiOmZhbHNlLCJqdGkiOiIwNGUwYTE4Mi01OTRiLTQ2ZmEtODc4Ni01YzAxNDQwZGZiNGUiLCJpYXQiOjE3NjU1OTgyNTEsImV4cCI6MTc2NTU5OTE1MSwiYXVkIjoiY3J5Yi11c2VycyIsImlzcyI6ImNyeWItcGxhdGZvcm0ifQ.bdMCoHNgQVuy3nHEpa5FtfESzBK3a5a_cXF39ke7TFQ	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwYTRlZDkwNC1lOWM5LTRjYzEtYjFlNy0zZTdmNGJhMTczYTEiLCJzZXNzaW9uSWQiOiJjZmU3MDg0OC1kNDA0LTRkNjYtYjJmMy1kMTY0MTc3MTBmOWYiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6IjQ2Mzc5NTg3LTc2NjQtNGY1Yi1hYzBlLWY5ODRkZmFlYTg0YyIsImlhdCI6MTc2NTU5ODI1MSwiZXhwIjoxNzY4MTkwMjUxLCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.GXsi_ci1wIXBpsofcXDoXY1ztW_XOqoJNjVGlbTTeWM	2026-01-12 03:57:31.103	2025-12-13 03:57:31.113	2025-12-13 03:57:31.113
87826fab-67c7-49ef-a33c-5e187822d3a1	6ffe211d-5fd8-47e1-98c4-26f1383f3f98	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiI4NzgyNmZhYi02N2M3LTQ5ZWYtYTMzYy01ZTE4NzgyMmQzYTEiLCJlbWFpbCI6Impob25ueWFyYXlhN0BnbWFpbC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiOTFhNDZhZDItMmFmNi00MTllLWIyYmUtYmFmOWYyZmIzYjU1IiwiaWF0IjoxNzY1Njg4NDY2LCJleHAiOjE3NjU2ODkzNjYsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.t4s7F_Af4ia-aPqS9vOwxpayvFuzpBIYZ8NLcWNO6rs	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiI4NzgyNmZhYi02N2M3LTQ5ZWYtYTMzYy01ZTE4NzgyMmQzYTEiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6ImM1N2Q0NDVjLWMwMWUtNGM3YS1iZGYzLWVlZWQ1ODUwYmU3OCIsImlhdCI6MTc2NTY4ODQ2NiwiZXhwIjoxNzY4MjgwNDY2LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.HyrmMRNvK6u4gvwZhxlMf2JwmWsQyb_lPg2jB0MQn-E	2026-01-13 05:01:06.449	2025-12-14 05:01:06.455	2025-12-14 05:01:06.455
14c6a847-b9a3-4abd-8d17-a057d106b420	6ffe211d-5fd8-47e1-98c4-26f1383f3f98	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiIxNGM2YTg0Ny1iOWEzLTRhYmQtOGQxNy1hMDU3ZDEwNmI0MjAiLCJlbWFpbCI6Impob25ueWFyYXlhN0BnbWFpbC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiYTZhMTkwMDAtMzA0Mi00ZmExLWIxOTUtZmRhNjQ2NGY3OGNlIiwiaWF0IjoxNzY1ODM1MDc3LCJleHAiOjE3NjU4MzU5NzcsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.sscKHEoSWu20zicVFSlq7HQULPnCLYC3bj9XDQz7XXM	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiIxNGM2YTg0Ny1iOWEzLTRhYmQtOGQxNy1hMDU3ZDEwNmI0MjAiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6ImQ3YTQxYmI1LTlmMmQtNDlhNS05YTM0LTVkMmMwNDFiOTY1MSIsImlhdCI6MTc2NTgzNTA3NywiZXhwIjoxNzY4NDI3MDc3LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.gxECtcEkFoKxIFqIWZyUx1FoJtTkXPvf0cJmsAls7QA	2026-01-14 21:44:37.24	2025-12-15 21:44:37.247	2025-12-15 21:44:37.247
2b37f6bd-7c08-4057-ae1e-88f3538e6d36	6ffe211d-5fd8-47e1-98c4-26f1383f3f98	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiIyYjM3ZjZiZC03YzA4LTQwNTctYWUxZS04OGYzNTM4ZTZkMzYiLCJlbWFpbCI6Impob25ueWFyYXlhN0BnbWFpbC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiZjkzMTY2ODYtYzc5MS00MTAwLTlmZjEtNDhiMGRhMjYzMGQ2IiwiaWF0IjoxNzY1OTI3MjYyLCJleHAiOjE3NjU5MjgxNjIsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.nO2RuLYcqECCinFLgJhaxahcUtXiVKyq5RBU23mTt3s	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiIyYjM3ZjZiZC03YzA4LTQwNTctYWUxZS04OGYzNTM4ZTZkMzYiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6ImNmM2JkZGIxLTUwNTctNDU4Ny04YWM5LTFkNGI2ZjJkODBkNyIsImlhdCI6MTc2NTkyNzI2MiwiZXhwIjoxNzY4NTE5MjYyLCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.JteJ956WuguumOzVVccBt_X2Rvxxii1iuP9BCLFf-U0	2026-01-15 23:21:02.033	2025-12-16 23:21:02.042	2025-12-16 23:21:02.042
5d86db5a-b663-4eae-a4e1-685147c844e1	6ffe211d-5fd8-47e1-98c4-26f1383f3f98	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiI1ZDg2ZGI1YS1iNjYzLTRlYWUtYTRlMS02ODUxNDdjODQ0ZTEiLCJlbWFpbCI6Impob25ueWFyYXlhN0BnbWFpbC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiNWZjNmQxNGUtMTE0Ni00MGNmLWEwMjEtNTFlYzliNzhiMGY3IiwiaWF0IjoxNzY1OTI3NDE1LCJleHAiOjE3NjU5MjgzMTUsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.PRE2x8qR8eK-6-DVvAJrNCORnACdk6xb-lMCcgEN6oQ	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiI1ZDg2ZGI1YS1iNjYzLTRlYWUtYTRlMS02ODUxNDdjODQ0ZTEiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6ImNjOTI3NzhkLTliYjAtNGIzNC1hOTM3LWE2MzEzNTE5YjZmYyIsImlhdCI6MTc2NTkyNzQxNSwiZXhwIjoxNzY4NTE5NDE1LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.CfcuR2I580qp3NsIIr4I-jSj-73wuC6Z3eskjjshzsw	2026-01-15 23:23:35.498	2025-12-16 23:23:35.506	2025-12-16 23:23:35.506
82749a14-6399-4241-992d-29b8163a2c71	6ffe211d-5fd8-47e1-98c4-26f1383f3f98	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiI4Mjc0OWExNC02Mzk5LTQyNDEtOTkyZC0yOWI4MTYzYTJjNzEiLCJlbWFpbCI6Impob25ueWFyYXlhN0BnbWFpbC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiZjQ1MzkxYWQtM2U1NS00NjYyLTlmMTMtNzMwMjFlYzMwYmZiIiwiaWF0IjoxNzY1OTMzMzAyLCJleHAiOjE3NjU5MzQyMDIsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.efidCIHqR-1jAlrX7ExzSJMwJ1Cp3dBXkW2YzNytHi8	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiI4Mjc0OWExNC02Mzk5LTQyNDEtOTkyZC0yOWI4MTYzYTJjNzEiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6IjQzM2EwOWNhLTQ1OTktNDk3MC1iZmY4LWVlMGIwNGE1Y2Y4MyIsImlhdCI6MTc2NTkzMzMwMiwiZXhwIjoxNzY4NTI1MzAyLCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.wWuV6qJ38pf1eXPdy6ARxyuQHe2sygl7WTQFlOwZLl0	2026-01-16 01:01:42.489	2025-12-17 01:01:42.494	2025-12-17 01:01:42.494
00a008a9-dea6-4267-9ee1-105bd434fc1d	6ffe211d-5fd8-47e1-98c4-26f1383f3f98	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiIwMGEwMDhhOS1kZWE2LTQyNjctOWVlMS0xMDViZDQzNGZjMWQiLCJlbWFpbCI6Impob25ueWFyYXlhN0BnbWFpbC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiNzMxZTM0ODktNzNiZS00ZTI4LTg1MTYtMTU2YTVmYzlhOWY5IiwiaWF0IjoxNzY2MTA5MzEwLCJleHAiOjE3NjYxMTAyMTAsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.OBwktKj7LZldW4tBA_2ROkiqcBRLdp-w0oCiYbIZU48	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiIwMGEwMDhhOS1kZWE2LTQyNjctOWVlMS0xMDViZDQzNGZjMWQiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6ImJmYTU2ZDFlLTBiNDEtNDEzZC05Mzk1LTViM2MwNzQzY2M1ZSIsImlhdCI6MTc2NjEwOTMxMCwiZXhwIjoxNzY4NzAxMzEwLCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.mWbk3z1pUp5zGn7FalNfhz5EdrcBTCxsWP_e6dEdOQw	2026-01-18 01:55:10.685	2025-12-19 01:55:10.695	2025-12-19 01:55:10.695
3cf6f8ee-982c-4533-802a-6bd5199c9a09	6ffe211d-5fd8-47e1-98c4-26f1383f3f98	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiIzY2Y2ZjhlZS05ODJjLTQ1MzMtODAyYS02YmQ1MTk5YzlhMDkiLCJlbWFpbCI6Impob25ueWFyYXlhN0BnbWFpbC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiNzFiZjEyZDgtODQyZS00MzRmLThkNDYtMWRlOTQxM2RmNmI5IiwiaWF0IjoxNzY2MTE5Mzc2LCJleHAiOjE3NjYxMjAyNzYsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.1LIw9ERRJReSXdbNchJfWaZAd9N6MViiMiwqmzy9zEg	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiIzY2Y2ZjhlZS05ODJjLTQ1MzMtODAyYS02YmQ1MTk5YzlhMDkiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6ImE4MjQ1MmUzLWNjNmItNDBkNC1iOWFlLTBlNzYwNWYyYzdlYSIsImlhdCI6MTc2NjExOTM3NiwiZXhwIjoxNzY4NzExMzc2LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.sFe5SC6xZR9NBlphcp-RLgx01G94PMBExFag4YA6rlI	2026-01-18 04:42:56.187	2025-12-19 04:42:56.196	2025-12-19 04:42:56.196
a6742b2c-5490-4ccc-b03a-ddbce715e250	6ffe211d-5fd8-47e1-98c4-26f1383f3f98	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiJhNjc0MmIyYy01NDkwLTRjY2MtYjAzYS1kZGJjZTcxNWUyNTAiLCJlbWFpbCI6Impob25ueWFyYXlhN0BnbWFpbC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiYzVhNmRlOWYtMGY3ZS00MWIyLTlhODktM2MwZmYwNTVlY2JhIiwiaWF0IjoxNzY2MzAzNTMzLCJleHAiOjE3NjYzMDQ0MzMsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.OYseK-FXQQTrQRVz3vARGYa1lPlt1st-gxE-dS665vo	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiJhNjc0MmIyYy01NDkwLTRjY2MtYjAzYS1kZGJjZTcxNWUyNTAiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6ImFmMjBkMmY2LTk4ZTgtNDI4ZS1hMjM2LWU2ZWM1ODk3OGUyZCIsImlhdCI6MTc2NjMwMzUzMywiZXhwIjoxNzY4ODk1NTMzLCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.YAaC8ITZuDZBjcLqF-AsnSQcuifsQaQbHlCh6kpYpDw	2026-01-20 07:52:13.123	2025-12-21 07:52:13.197	2025-12-21 07:52:13.197
49ec9589-978d-4f6a-98f7-dc1ce5a3ae3c	6ffe211d-5fd8-47e1-98c4-26f1383f3f98	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiI0OWVjOTU4OS05NzhkLTRmNmEtOThmNy1kYzFjZTVhM2FlM2MiLCJlbWFpbCI6Impob25ueWFyYXlhN0BnbWFpbC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiZWZkYWRiOWEtYzk3Mi00Y2FkLWEwMmItMWZlNjk1ODdmOTJmIiwiaWF0IjoxNzY2MzA2MTk5LCJleHAiOjE3NjYzMDcwOTksImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.pNNFCxqT7fCxpawfV6wcixzZf15dYCqmsBesJCclWsE	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiI0OWVjOTU4OS05NzhkLTRmNmEtOThmNy1kYzFjZTVhM2FlM2MiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6IjQ4MmU0ODg2LWU4OTUtNDNmNy1hYzYzLTAwNzNjZDExMjM3YSIsImlhdCI6MTc2NjMwNjE5OSwiZXhwIjoxNzY4ODk4MTk5LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.Jeb03iLPaQgHfA5WapkqOXjdqnx_OFbFYI9onwNUhSQ	2026-01-20 08:36:39.6	2025-12-21 08:36:39.606	2025-12-21 08:36:39.606
66282508-ad5d-46fd-991f-cc52a93c44aa	6ffe211d-5fd8-47e1-98c4-26f1383f3f98	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiI2NjI4MjUwOC1hZDVkLTQ2ZmQtOTkxZi1jYzUyYTkzYzQ0YWEiLCJlbWFpbCI6Impob25ueWFyYXlhN0BnbWFpbC5jb20iLCJ3YWxsZXRBZGRyZXNzIjpudWxsLCJpc1ZlcmlmaWVkIjpmYWxzZSwianRpIjoiYTk1Yjk0OTgtYjA4MS00NGE5LWFkODctNGFkZjQxNzdkYTM3IiwiaWF0IjoxNzY2MzgxNTk2LCJleHAiOjE3NjYzODI0OTYsImF1ZCI6ImNyeWItdXNlcnMiLCJpc3MiOiJjcnliLXBsYXRmb3JtIn0.xZC7NLYZR8Lw_XKap5s_6wz2IRL-SqiDZETbyGsLtNM	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2ZmZlMjExZC01ZmQ4LTQ3ZTEtOThjNC0yNmYxMzgzZjNmOTgiLCJzZXNzaW9uSWQiOiI2NjI4MjUwOC1hZDVkLTQ2ZmQtOTkxZi1jYzUyYTkzYzQ0YWEiLCJ0eXBlIjoicmVmcmVzaCIsImp0aSI6Ijc4YmVlNzU3LThjM2QtNDc1Yy04YzYzLTg1OGFjNjNjMzljYiIsImlhdCI6MTc2NjM4MTU5NiwiZXhwIjoxNzY4OTczNTk2LCJhdWQiOiJjcnliLXVzZXJzIiwiaXNzIjoiY3J5Yi1wbGF0Zm9ybSJ9.GtbpEzoIzcTP710QQ0rFU-1skXcuLc6U7oprw4ikEoo	2026-01-21 05:33:16.051	2025-12-22 05:33:16.058	2025-12-22 05:33:16.058
\.


--
-- Data for Name: StakingPool; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."StakingPool" (id, name, description, "tokenAddress", "tokenSymbol", "tokenName", chain, apr, "lockPeriod", "minStakeAmount", "maxStakeAmount", "totalStaked", "totalRewards", "isActive", "startDate", "endDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: StakingReward; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."StakingReward" (id, "userId", "poolId", "stakeId", amount, currency, status, "txHash", "createdAt", "claimedAt") FROM stdin;
\.


--
-- Data for Name: Thread; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Thread" (id, "channelId", "userId", name, archived, locked, "autoArchive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Token; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Token" (id, "userId", address, symbol, name, decimals, balance, chain, verified) FROM stdin;
\.


--
-- Data for Name: TokenGatingRule; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."TokenGatingRule" (id, "serverId", "channelId", "communityId", name, description, "ruleType", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: TokenRequirement; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."TokenRequirement" (id, "ruleId", "tokenAddress", symbol, name, chain, "minAmount") FROM stdin;
\.


--
-- Data for Name: TranscodingJob; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."TranscodingJob" (id, "fileId", "userId", "jobType", "inputBucket", "inputFilename", "outputFormats", priority, status, progress, "startedAt", "completedAt", error, outputs, thumbnails, preview, waveform, metadata, "processingLogs", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: UploadChunk; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."UploadChunk" (id, "sessionId", "chunkIndex", size, hash, uploaded, "uploadedAt") FROM stdin;
\.


--
-- Data for Name: UploadedFile; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."UploadedFile" (id, "userId", "originalName", filename, "mimeType", size, hash, bucket, url, "cdnUrl", "thumbnailUrl", "previewUrl", width, height, duration, bitrate, framerate, channels, "sampleRate", "uploadType", "channelId", "messageId", processed, "scanPassed", "scanResult", validated, "validationErrors", "securityFlags", "createdAt", "updatedAt", "expiresAt", "lastAccessedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."User" (id, email, username, avatar, "bannedAt", banner, bio, "createdAt", discord_id, discriminator, "displayName", flags, github_id, google_id, "isBot", "isSystem", "isVerified", "lastSeenAt", locale, "mfaEnabled", "passwordHash", "premiumUntil", pronouns, "publicFlags", "twoFactorBackupCodes", "twoFactorEnabled", "twoFactorEnabledAt", "twoFactorSecret", "updatedAt", "walletAddress", "premiumType", "followerCount", "followingCount", "isPrivate", location, "postCount", "showActivityStatus", "showWalletHoldings", "socialLinks", website) FROM stdin;
cmgu2gn4k0001qlwc2fpdaslv	branson_ratke@hotmail.com	branson_ratke	https://avatars.githubusercontent.com/u/95672651	\N	https://loremflickr.com/640/480/nature?lock=4360988960751616	Coepi pariatur tepesco absque assumenda pel adopto.	2025-10-16 23:44:08.469	\N	4862	Branson Ratke	0	\N	\N	f	f	f	2025-10-12 12:09:11.302	en-US	f	\N	\N	\N	0	{}	f	\N	\N	2025-10-16 23:44:08.469	\N	NONE	0	0	f	\N	0	t	t	\N	\N
cmgu2gn4p0002qlwc80wfogfe	orie.roberts73@gmail.com	orie.roberts	https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/559.jpg	\N	\N	\N	2025-10-16 23:44:08.474	\N	5762	Orie Roberts	0	\N	\N	f	f	f	2025-10-11 00:56:10.663	en-US	f	\N	\N	she/her	0	{}	f	\N	\N	2025-10-16 23:44:08.474	\N	NONE	0	0	f	\N	0	t	t	\N	\N
cmgu2gn4v0003qlwcugkrmdpr	sherwood.gibson@hotmail.com	sherwood.gibson9	https://avatars.githubusercontent.com/u/85153640	\N	\N	Utrum campana qui.	2025-10-16 23:44:08.479	\N	0802	Sherwood Gibson	0	\N	\N	f	f	f	2025-10-11 23:19:01.934	en-US	f	\N	\N	\N	0	{}	f	\N	\N	2025-10-16 23:44:08.479	\N	NONE	0	0	f	\N	0	t	t	\N	\N
cmgu2gn500004qlwcjxvp6xez	sheila.smitham98@gmail.com	sheila_smitham	https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/760.jpg	\N	https://loremflickr.com/640/480/nature?lock=9000755837009920	Basium depereo at armarium vere statim.	2025-10-16 23:44:08.484	\N	8124	Sheila Smitham	0	\N	\N	f	f	f	2025-10-16 04:00:14.604	en-US	f	\N	\N	he/him	0	{}	f	\N	\N	2025-10-16 23:44:08.484	\N	NONE	0	0	f	\N	0	t	t	\N	\N
cmgu2gn5f0005qlwcdx8tb0kd	sigmund_boyle@gmail.com	sigmund.boyle	https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/378.jpg	\N	\N	\N	2025-10-16 23:44:08.499	\N	2314	Sigmund Boyle	0	\N	\N	f	f	f	2025-10-11 14:42:59.991	en-US	f	\N	\N	he/him	0	{}	f	\N	\N	2025-10-16 23:44:08.499	\N	NONE	0	0	f	\N	0	t	t	\N	\N
cmgu2gn5n0006qlwcqfu7g12g	reyna.berge@hotmail.com	reyna_berge49	https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/268.jpg	\N	\N	\N	2025-10-16 23:44:08.507	\N	5998	Reyna Berge	0	\N	\N	f	f	t	2025-10-12 17:47:50.637	en-US	f	\N	\N	she/her	0	{}	f	\N	\N	2025-10-16 23:44:08.507	\N	NONE	0	0	f	\N	0	t	t	\N	\N
cmgu2gn5s0007qlwcjhhzi8m9	rosario_hauck65@yahoo.com	rosario_hauck	https://avatars.githubusercontent.com/u/57708097	\N	\N	\N	2025-10-16 23:44:08.512	\N	5578	Rosario Hauck	0	\N	\N	f	f	t	2025-10-15 11:49:03.375	en-US	f	\N	\N	she/her	0	{}	f	\N	\N	2025-10-16 23:44:08.512	\N	NONE	0	0	f	\N	0	t	t	\N	\N
cmgu2gn5x0008qlwc51j7cb44	selena_krajcik93@gmail.com	selena_krajcik1	https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/365.jpg	\N	\N	\N	2025-10-16 23:44:08.517	\N	3555	Selena Krajcik	0	\N	\N	f	f	f	2025-10-14 10:19:51.901	en-US	f	\N	\N	\N	0	{}	f	\N	\N	2025-10-16 23:44:08.517	\N	NONE	0	0	f	\N	0	t	t	\N	\N
cmgu2gn620009qlwcdnj97s63	woodrow.prosacco@gmail.com	woodrow.prosacco	https://avatars.githubusercontent.com/u/39408684	\N	\N	Defluo adficio audentia dedecor speciosus solum cunctatio velut dignissimos conqueror.	2025-10-16 23:44:08.522	\N	9340	Woodrow Prosacco	0	\N	\N	f	f	f	2025-10-16 10:35:38.417	en-US	f	\N	\N	\N	0	{}	f	\N	\N	2025-10-16 23:44:08.522	\N	NONE	0	0	f	\N	0	t	t	\N	\N
cmgvj6xwm0000vzb8a21ggzfo	harsh2@test.com	harsh2test	\N	\N	\N	\N	2025-10-18 00:20:15.526	\N	0001	Harsh Tester	0	\N	\N	f	f	f	\N	en-US	f	$2b$12$o0EMNEKSeL247HD10eVGseyNHfbbdkf29gF3AFJVJXuVSidGzyPT.	\N	\N	0	{}	f	\N	\N	2025-10-18 00:20:15.526	\N	NONE	0	0	f	\N	0	t	t	\N	\N
cmgvje2zo0000k62dygaismzy	ux-tester@test.com	uxtester	\N	\N	\N	\N	2025-10-18 00:25:48.709	\N	0001	UX Tester	0	\N	\N	f	f	f	\N	en-US	f	$2b$12$DPLfZT0jh2/Wmy0Bk3R2..ScQZp3TjrhWahK8gxM2pLgACZB13b2y	\N	\N	0	{}	f	\N	\N	2025-10-18 00:25:48.709	\N	NONE	0	0	f	\N	0	t	t	\N	\N
cmgvqpaza0000kf6cmh62ub5w	test999@test.com	testuser999	\N	\N	\N	\N	2025-10-18 03:50:29.59	\N	0001	Test User	0	\N	\N	f	f	f	\N	en-US	f	$2b$12$DoA3nXKUvraz6oz3g1/zReWmD3VjU1Pn/0vja.W4fhWaOOlitQ/mO	\N	\N	0	{}	f	\N	\N	2025-10-18 03:50:29.59	\N	NONE	0	0	f	\N	0	t	t	\N	\N
cmgvx4nri0000tb56kh6dggp0	test1760770223@test.com	user1760770223	\N	\N	\N	\N	2025-10-18 06:50:23.695	\N	0001	Test User 1760770223	0	\N	\N	f	f	f	\N	en-US	f	$2b$12$QCrihFQ1/JgU.o9GZpdHAeZxQwEaLXJsz3AI93R0vC0CuZI1WCNIC	\N	\N	0	{}	f	\N	\N	2025-10-18 06:50:23.695	\N	NONE	0	0	f	\N	0	t	t	\N	\N
cmgvx4zf00001tb56yob022y0	test1760770238@test.com	user1760770238	\N	\N	\N	\N	2025-10-18 06:50:38.796	\N	0001	Test User 1760770238	0	\N	\N	f	f	f	\N	en-US	f	$2b$12$qFd3akRLa/7BrtoIHRJyoe7jhLHZj7fmVfenbRlj/DiQZra2kbaRW	\N	\N	0	{}	f	\N	\N	2025-10-18 06:50:38.796	\N	NONE	0	0	f	\N	0	t	t	\N	\N
cmgwl5fbu0002tb56tz5q8dy9	fulltest1760810569@test.com	fulltest1760810569	\N	\N	\N	\N	2025-10-18 18:02:50.201	\N	0001	Full Test User	0	\N	\N	f	f	f	\N	en-US	f	$2b$12$2yWIQ2S54lm/hEbs7NXZCOawNHqBnBvXgZ7UZMqTyjiHiCbFdp9l6	\N	\N	0	{}	f	\N	\N	2025-10-18 18:02:50.201	\N	NONE	0	0	f	\N	0	t	t	\N	\N
cmgwlg2bs0000ougoiu1utzzt	fulltest1760811066@test.com	fulltest1760811066	\N	\N	\N	\N	2025-10-18 18:11:06.569	\N	0001	Full Test User	0	\N	\N	f	f	f	\N	en-US	f	$2b$12$LBvMpD.m2yB9417KG1WYLe6Tq5YMLP68FlW/KzCUG8h6HTNq542vS	\N	\N	0	{}	f	\N	\N	2025-10-18 18:11:06.569	\N	NONE	0	0	f	\N	0	t	t	\N	\N
cmgwlj4xu0001ougo9zbn5swt	voicetest123@test.com	voicetest123	\N	\N	\N	\N	2025-10-18 18:13:29.922	\N	0001	Voice Test	0	\N	\N	f	f	f	\N	en-US	f	$2b$12$K4efBtMVZ5t6ZIbVOwPuWuvb/4O6fA5afSWLZycGe.slWywUyJMN6	\N	\N	0	{}	f	\N	\N	2025-10-18 18:13:29.922	\N	NONE	0	0	f	\N	0	t	t	\N	\N
cmgu2gn420000qlwcc82uc6sp	laurie.armstrong96@gmail.com	laurie_armstrong	https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/586.jpg	\N	https://loremflickr.com/640/480/nature?lock=5181532140470272	\N	2025-10-16 23:44:08.45	\N	3552	Laurie Armstrong	0	\N	\N	f	f	f	2025-10-14 12:02:14.44	en-US	f	\N	\N	he/him	0	{}	f	\N	\N	2025-10-16 23:44:08.45	\N	NONE	0	0	f	\N	0	t	t	\N	\N
1568087c-fad5-425e-a6d8-f89e92d947c0	ar_turo_mo@outlook.es	backx00	\N	\N	\N	\N	2025-12-09 01:42:13.009	\N	0001	Backx00	0	\N	\N	f	f	f	\N	en-US	f	$2b$12$RpypCN51gcxgwqR0roDnheXH2PU.O0eGlev5V2l1ZqFQUNzvDOuEG	\N	\N	0	{}	f	\N	\N	2025-12-09 01:42:13.007	\N	NONE	0	0	f	\N	0	t	t	\N	\N
38e69ff3-0f78-4e7f-9b04-9bc7d2fdac60	jhonny@ar-mediia.com	delenaa	\N	\N	\N	\N	2025-12-11 20:20:24.577	\N	0001	delenaa	0	\N	\N	f	f	f	\N	en-US	f	$2b$12$mbBHkQRm5pAPfmCHHzmVaOfOhrcTvyx7s50W.pn6QAyXYXflJ.YOa	\N	\N	0	{}	f	\N	\N	2025-12-11 20:20:24.575	\N	NONE	0	0	f	\N	0	t	t	\N	\N
6ffe211d-5fd8-47e1-98c4-26f1383f3f98	jhonnyaraya7@gmail.com	iou9oim	\N	\N	\N	\N	2025-12-12 00:33:22.327	\N	0001	iou9oim	0	\N	\N	f	f	f	\N	en-US	f	$2b$12$8AIFK7rNQ8QdFuO3mV7lWOcIf7/pQjup6FBoeXN.ei8zRTQPVLIem	\N	\N	0	{}	f	\N	\N	2025-12-12 02:15:42.387	\N	NONE	0	0	f	\N	0	t	t	\N	\N
0a4ed904-e9c9-4cc1-b1e7-3e7f4ba173a1	bradhimel01@gmail.com	bradleyhimel	\N	\N	\N	\N	2025-12-13 03:57:31.085	\N	0001	Bradleyhimel	0	\N	\N	f	f	f	\N	en-US	f	$2b$12$7TtKIbob57j0o.BAnKPIXu06pUExFY5YN90TEGH/rQRx24tE.VIXm	\N	\N	0	{}	f	\N	\N	2025-12-13 03:57:31.084	\N	NONE	0	0	f	\N	0	t	t	\N	\N
6713165b-3c44-4bd1-bd84-c2ba2a84fe28	jimecastrocalleja@hotmail.com	jime98	\N	\N	\N	\N	2025-12-14 19:27:27.777	\N	0001	Jime98	0	\N	\N	f	f	f	\N	en-US	f	$2b$12$zHr5vVl53BcYV67dvqrvUOitOG2lA5Qft2dyvL0tsI9Qd09ryUm.W	\N	\N	0	{}	f	\N	\N	2025-12-14 19:27:27.776	\N	NONE	0	0	f	\N	0	t	t	\N	\N
\.


--
-- Data for Name: UserActivity; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."UserActivity" (id, "userId", "presenceId", type, name, details, state, "applicationId", url, "createdAt", timestamps, assets, party, secrets, instance, flags) FROM stdin;
\.


--
-- Data for Name: UserBadge; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."UserBadge" (id, "userId", "badgeId", "earnedAt", "isVisible") FROM stdin;
\.


--
-- Data for Name: UserNFT; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."UserNFT" (id, "userId", "nftId", verified, "lastVerifiedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: UserPresence; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."UserPresence" (id, "userId", status, "clientStatus", "updatedAt") FROM stdin;
\.


--
-- Data for Name: UserProfilePicture; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."UserProfilePicture" (id, "userId", "nftId", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: UserStake; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."UserStake" (id, "userId", "poolId", amount, "lockedUntil", status, "txHash", "createdAt", "updatedAt", "withdrawnAt") FROM stdin;
\.


--
-- Data for Name: VoiceAnalytics; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."VoiceAnalytics" (id, "serverId", "channelId", "userId", "sessionDuration", "timestamp") FROM stdin;
\.


--
-- Data for Name: VoiceState; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."VoiceState" (id, "userId", "serverId", "channelId", "sessionId", deaf, mute, "selfDeaf", "selfMute", "selfStream", "selfVideo", suppress, "requestToSpeakTimestamp", "connectedAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Vote; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public."Vote" (id, "userId", "postId", "commentId", value, "createdAt") FROM stdin;
cmgu2gpf401hbqlwc5k8osjcz	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gngd006bqlwczd46xwge	\N	1	2025-10-16 23:44:11.44
cmgu2gpf801hdqlwcnkjie9ls	cmgu2gn620009qlwcdnj97s63	cmgu2gngd006bqlwczd46xwge	\N	-1	2025-10-16 23:44:11.445
cmgu2gpfb01hfqlwc9szqxovr	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gngd006bqlwczd46xwge	\N	1	2025-10-16 23:44:11.448
cmgu2gpfe01hhqlwcmo5wcktp	cmgu2gn4p0002qlwc80wfogfe	cmgu2gngd006bqlwczd46xwge	\N	1	2025-10-16 23:44:11.45
cmgu2gpfg01hjqlwce5ql8eqb	cmgu2gn5x0008qlwc51j7cb44	cmgu2gngd006bqlwczd46xwge	\N	1	2025-10-16 23:44:11.453
cmgu2gpfj01hlqlwcty3zqc2n	cmgu2gn420000qlwcc82uc6sp	cmgu2gngd006bqlwczd46xwge	\N	1	2025-10-16 23:44:11.455
cmgu2gpfm01hnqlwcdbtsl9mj	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnev0059qlwcas2j7yrr	\N	1	2025-10-16 23:44:11.458
cmgu2gpfo01hpqlwcrkdqe7gn	cmgu2gn420000qlwcc82uc6sp	cmgu2gnev0059qlwcas2j7yrr	\N	1	2025-10-16 23:44:11.461
cmgu2gpfq01hrqlwc84h9iu5p	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnev0059qlwcas2j7yrr	\N	1	2025-10-16 23:44:11.463
cmgu2gpfs01htqlwco1vyajgy	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnev0059qlwcas2j7yrr	\N	1	2025-10-16 23:44:11.465
cmgu2gpfu01hvqlwc9stenfd2	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnev0059qlwcas2j7yrr	\N	1	2025-10-16 23:44:11.467
cmgu2gpfw01hxqlwcq7hgauz9	cmgu2gn500004qlwcjxvp6xez	cmgu2gnev0059qlwcas2j7yrr	\N	1	2025-10-16 23:44:11.468
cmgu2gpfy01hzqlwcq5j7rt8o	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnev0059qlwcas2j7yrr	\N	1	2025-10-16 23:44:11.47
cmgu2gpg001i1qlwc4gx7s5t4	cmgu2gn620009qlwcdnj97s63	cmgu2gnev0059qlwcas2j7yrr	\N	1	2025-10-16 23:44:11.473
cmgu2gpg201i3qlwcj1z8q32x	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnl5009rqlwcqumgu0s2	\N	1	2025-10-16 23:44:11.475
cmgu2gpg401i5qlwc216x91ms	cmgu2gn500004qlwcjxvp6xez	cmgu2gnl5009rqlwcqumgu0s2	\N	-1	2025-10-16 23:44:11.477
cmgu2gpg601i7qlwchaqdg033	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnl5009rqlwcqumgu0s2	\N	1	2025-10-16 23:44:11.479
cmgu2gpg801i9qlwct5qc8huq	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnl5009rqlwcqumgu0s2	\N	1	2025-10-16 23:44:11.481
cmgu2gpga01ibqlwcmyuxxtip	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnkr009hqlwce988449u	\N	1	2025-10-16 23:44:11.483
cmgu2gpgc01idqlwcx1lydbmm	cmgu2gn500004qlwcjxvp6xez	cmgu2gnkr009hqlwce988449u	\N	-1	2025-10-16 23:44:11.485
cmgu2gpge01ifqlwckz4fvh1m	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnkr009hqlwce988449u	\N	1	2025-10-16 23:44:11.487
cmgu2gpgg01ihqlwccw7z0kzm	cmgu2gn420000qlwcc82uc6sp	cmgu2gnkr009hqlwce988449u	\N	1	2025-10-16 23:44:11.489
cmgu2gpgi01ijqlwcadwysvz0	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnkr009hqlwce988449u	\N	1	2025-10-16 23:44:11.491
cmgu2gpgk01ilqlwckal0qfln	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnkr009hqlwce988449u	\N	1	2025-10-16 23:44:11.493
cmgu2gpgm01inqlwc1575wsuu	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnkr009hqlwce988449u	\N	1	2025-10-16 23:44:11.495
cmgu2gpgo01ipqlwckz064km1	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnkr009hqlwce988449u	\N	-1	2025-10-16 23:44:11.497
cmgu2gpgr01irqlwcbw2jo79d	cmgu2gn620009qlwcdnj97s63	cmgu2gnkr009hqlwce988449u	\N	1	2025-10-16 23:44:11.5
cmgu2gpgu01itqlwcfuuxrgrf	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnkr009hqlwce988449u	\N	1	2025-10-16 23:44:11.502
cmgu2gpgw01ivqlwc3grg0ewi	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnh3006tqlwctujwg677	\N	1	2025-10-16 23:44:11.504
cmgu2gpgx01ixqlwcluoh3rw7	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnh3006tqlwctujwg677	\N	1	2025-10-16 23:44:11.506
cmgu2gpgz01izqlwc9qmp2fwo	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnh3006tqlwctujwg677	\N	-1	2025-10-16 23:44:11.508
cmgu2gph101j1qlwc1m17wrf1	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnh3006tqlwctujwg677	\N	-1	2025-10-16 23:44:11.51
cmgu2gph301j3qlwcse8d9l3j	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnh3006tqlwctujwg677	\N	-1	2025-10-16 23:44:11.512
cmgu2gph601j5qlwcfkegs4cg	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnh3006tqlwctujwg677	\N	1	2025-10-16 23:44:11.514
cmgu2gph801j7qlwcapb2p0gk	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnh3006tqlwctujwg677	\N	1	2025-10-16 23:44:11.516
cmgu2gpha01j9qlwcb3p1nd9k	cmgu2gn500004qlwcjxvp6xez	cmgu2gnh3006tqlwctujwg677	\N	1	2025-10-16 23:44:11.518
cmgu2gphc01jbqlwci8z4mxjt	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnia007rqlwc3vlzzprz	\N	-1	2025-10-16 23:44:11.52
cmgu2gphe01jdqlwcjw6xv3a0	cmgu2gn420000qlwcc82uc6sp	cmgu2gnia007rqlwc3vlzzprz	\N	1	2025-10-16 23:44:11.522
cmgu2gphg01jfqlwc10tzdake	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnia007rqlwc3vlzzprz	\N	1	2025-10-16 23:44:11.524
cmgu2gphi01jhqlwcyag8pk8w	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnia007rqlwc3vlzzprz	\N	1	2025-10-16 23:44:11.526
cmgu2gphk01jjqlwc2r058ot0	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnia007rqlwc3vlzzprz	\N	1	2025-10-16 23:44:11.528
cmgu2gphm01jlqlwcno9jw59y	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnia007rqlwc3vlzzprz	\N	1	2025-10-16 23:44:11.53
cmgu2gpho01jnqlwcit8ctwd7	cmgu2gn500004qlwcjxvp6xez	cmgu2gnia007rqlwc3vlzzprz	\N	1	2025-10-16 23:44:11.532
cmgu2gphq01jpqlwct35x8jwn	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnfs005vqlwclpefas5f	\N	-1	2025-10-16 23:44:11.534
cmgu2gphs01jrqlwclcwfmmcr	cmgu2gn500004qlwcjxvp6xez	cmgu2gnfs005vqlwclpefas5f	\N	1	2025-10-16 23:44:11.537
cmgu2gphu01jtqlwcjyr49dkt	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnfs005vqlwclpefas5f	\N	1	2025-10-16 23:44:11.539
cmgu2gphw01jvqlwcgp0g72t2	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnj4008bqlwcj0ktc4tm	\N	1	2025-10-16 23:44:11.541
cmgu2gphy01jxqlwc0gcbioaw	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnj4008bqlwcj0ktc4tm	\N	1	2025-10-16 23:44:11.543
cmgu2gpi101jzqlwclyaqy2sx	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnj4008bqlwcj0ktc4tm	\N	1	2025-10-16 23:44:11.545
cmgu2gpi301k1qlwcd9fe3ms2	cmgu2gn420000qlwcc82uc6sp	cmgu2gnj4008bqlwcj0ktc4tm	\N	-1	2025-10-16 23:44:11.547
cmgu2gpi501k3qlwctzsaoxin	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnj4008bqlwcj0ktc4tm	\N	1	2025-10-16 23:44:11.549
cmgu2gpi701k5qlwcegmpst5x	cmgu2gn620009qlwcdnj97s63	cmgu2gnj4008bqlwcj0ktc4tm	\N	-1	2025-10-16 23:44:11.552
cmgu2gpi901k7qlwc3mxap5bz	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnj4008bqlwcj0ktc4tm	\N	1	2025-10-16 23:44:11.554
cmgu2gpic01k9qlwcqeqx0uay	cmgu2gn500004qlwcjxvp6xez	cmgu2gnj4008bqlwcj0ktc4tm	\N	-1	2025-10-16 23:44:11.556
cmgu2gpie01kbqlwcncl7lkke	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gngg006dqlwcw0pinl5l	\N	1	2025-10-16 23:44:11.558
cmgu2gpig01kdqlwc1wvehqvx	cmgu2gn500004qlwcjxvp6xez	cmgu2gngg006dqlwcw0pinl5l	\N	-1	2025-10-16 23:44:11.561
cmgu2gpij01kfqlwceap61xup	cmgu2gn620009qlwcdnj97s63	cmgu2gngg006dqlwcw0pinl5l	\N	1	2025-10-16 23:44:11.563
cmgu2gpin01khqlwcg0q9vx6m	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gngg006dqlwcw0pinl5l	\N	-1	2025-10-16 23:44:11.568
cmgu2gpiq01kjqlwca48gvavw	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gngg006dqlwcw0pinl5l	\N	1	2025-10-16 23:44:11.57
cmgu2gpis01klqlwc9g1m982q	cmgu2gn420000qlwcc82uc6sp	cmgu2gngg006dqlwcw0pinl5l	\N	-1	2025-10-16 23:44:11.572
cmgu2gpiu01knqlwctfk2hmcd	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnm100ahqlwckvill1c9	\N	-1	2025-10-16 23:44:11.575
cmgu2gpiw01kpqlwc13pup3lq	cmgu2gn620009qlwcdnj97s63	cmgu2gnm100ahqlwckvill1c9	\N	1	2025-10-16 23:44:11.577
cmgu2gpiz01krqlwcu5y99okj	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnm100ahqlwckvill1c9	\N	1	2025-10-16 23:44:11.579
cmgu2gpj101ktqlwcspdt1rgx	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnm100ahqlwckvill1c9	\N	-1	2025-10-16 23:44:11.581
cmgu2gpj301kvqlwc9ff87u4l	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnm100ahqlwckvill1c9	\N	1	2025-10-16 23:44:11.583
cmgu2gpj501kxqlwc9gsfum1k	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnm100ahqlwckvill1c9	\N	1	2025-10-16 23:44:11.586
cmgu2gpj901kzqlwcjprhinzn	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnha006zqlwccxtsawgd	\N	-1	2025-10-16 23:44:11.589
cmgu2gpjf01l1qlwcjmvcz6by	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnha006zqlwccxtsawgd	\N	1	2025-10-16 23:44:11.596
cmgu2gpjl01l3qlwc24phcxco	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnha006zqlwccxtsawgd	\N	1	2025-10-16 23:44:11.601
cmgu2gpjn01l5qlwc4unmj8wg	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnha006zqlwccxtsawgd	\N	1	2025-10-16 23:44:11.604
cmgu2gpjq01l7qlwcbcos2w9r	cmgu2gn500004qlwcjxvp6xez	cmgu2gnha006zqlwccxtsawgd	\N	1	2025-10-16 23:44:11.606
cmgu2gpjs01l9qlwcfkm35i3o	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnha006zqlwccxtsawgd	\N	1	2025-10-16 23:44:11.608
cmgu2gpjv01lbqlwcr7t2fu4n	cmgu2gn420000qlwcc82uc6sp	cmgu2gnha006zqlwccxtsawgd	\N	-1	2025-10-16 23:44:11.611
cmgu2gpjx01ldqlwcysw486iy	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnha006zqlwccxtsawgd	\N	1	2025-10-16 23:44:11.613
cmgu2gpk001lfqlwcaafu6sm0	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnha006zqlwccxtsawgd	\N	1	2025-10-16 23:44:11.616
cmgu2gpk201lhqlwc4lekywk2	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnlq00a7qlwcmnzktsif	\N	1	2025-10-16 23:44:11.619
cmgu2gpk401ljqlwc7pelaoxi	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnlq00a7qlwcmnzktsif	\N	1	2025-10-16 23:44:11.621
cmgu2gpk701llqlwccagcjvc0	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnlq00a7qlwcmnzktsif	\N	1	2025-10-16 23:44:11.623
cmgu2gpk901lnqlwc1hopz2pi	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnlq00a7qlwcmnzktsif	\N	1	2025-10-16 23:44:11.625
cmgu2gpkb01lpqlwcx9aplxh1	cmgu2gn420000qlwcc82uc6sp	cmgu2gni3007lqlwcgb8ihf60	\N	-1	2025-10-16 23:44:11.628
cmgu2gpkd01lrqlwcrcq1c2ae	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gni3007lqlwcgb8ihf60	\N	1	2025-10-16 23:44:11.63
cmgu2gpkg01ltqlwcxov5khgz	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gni3007lqlwcgb8ihf60	\N	1	2025-10-16 23:44:11.632
cmgu2gpki01lvqlwc5c849qlo	cmgu2gn4p0002qlwc80wfogfe	cmgu2gni3007lqlwcgb8ihf60	\N	1	2025-10-16 23:44:11.634
cmgu2gpkk01lxqlwcglijec0u	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gngm006hqlwcwtj3886t	\N	1	2025-10-16 23:44:11.637
cmgu2gpkm01lzqlwcst5tojwz	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gngm006hqlwcwtj3886t	\N	1	2025-10-16 23:44:11.639
cmgu2gpko01m1qlwcihpogkje	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gngm006hqlwcwtj3886t	\N	1	2025-10-16 23:44:11.641
cmgu2gpks01m3qlwcvy6msc4z	cmgu2gn5x0008qlwc51j7cb44	cmgu2gngm006hqlwcwtj3886t	\N	1	2025-10-16 23:44:11.645
cmgu2gpkv01m5qlwcvrl1tigs	cmgu2gn420000qlwcc82uc6sp	cmgu2gngm006hqlwcwtj3886t	\N	1	2025-10-16 23:44:11.647
cmgu2gpl001m7qlwckiujytua	cmgu2gn420000qlwcc82uc6sp	cmgu2gnln00a5qlwc8e6zxumw	\N	-1	2025-10-16 23:44:11.652
cmgu2gpl201m9qlwcvwv4js7t	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnln00a5qlwc8e6zxumw	\N	-1	2025-10-16 23:44:11.655
cmgu2gpl801mbqlwchie7gxev	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnln00a5qlwc8e6zxumw	\N	1	2025-10-16 23:44:11.661
cmgu2gplb01mdqlwclpedyvia	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnln00a5qlwc8e6zxumw	\N	1	2025-10-16 23:44:11.663
cmgu2gpld01mfqlwcjae2wf5b	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnln00a5qlwc8e6zxumw	\N	1	2025-10-16 23:44:11.665
cmgu2gplf01mhqlwcht1sf3bh	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnln00a5qlwc8e6zxumw	\N	1	2025-10-16 23:44:11.668
cmgu2gplh01mjqlwcsgyklpx2	cmgu2gn500004qlwcjxvp6xez	cmgu2gnln00a5qlwc8e6zxumw	\N	1	2025-10-16 23:44:11.67
cmgu2gplj01mlqlwcwkogxaj1	cmgu2gn620009qlwcdnj97s63	cmgu2gnln00a5qlwc8e6zxumw	\N	1	2025-10-16 23:44:11.672
cmgu2gpll01mnqlwcqaw9dmo7	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnln00a5qlwc8e6zxumw	\N	1	2025-10-16 23:44:11.674
cmgu2gpln01mpqlwcp54zr36b	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnlv00abqlwcdbxcll1r	\N	1	2025-10-16 23:44:11.675
cmgu2gplp01mrqlwc5m0i6v1k	cmgu2gn620009qlwcdnj97s63	cmgu2gnlv00abqlwcdbxcll1r	\N	1	2025-10-16 23:44:11.677
cmgu2gplr01mtqlwc2otcfeh8	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnlv00abqlwcdbxcll1r	\N	-1	2025-10-16 23:44:11.679
cmgu2gplt01mvqlwcc2nca7to	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnlv00abqlwcdbxcll1r	\N	1	2025-10-16 23:44:11.681
cmgu2gplv01mxqlwc2enkwv0b	cmgu2gn420000qlwcc82uc6sp	cmgu2gnlv00abqlwcdbxcll1r	\N	-1	2025-10-16 23:44:11.683
cmgu2gplx01mzqlwclq584gal	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnlv00abqlwcdbxcll1r	\N	1	2025-10-16 23:44:11.685
cmgu2gplz01n1qlwc7tevr17w	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnlv00abqlwcdbxcll1r	\N	1	2025-10-16 23:44:11.687
cmgu2gpm101n3qlwcrs9lij3u	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnlv00abqlwcdbxcll1r	\N	1	2025-10-16 23:44:11.689
cmgu2gpm301n5qlwcp2m0usqq	cmgu2gn500004qlwcjxvp6xez	cmgu2gnlv00abqlwcdbxcll1r	\N	1	2025-10-16 23:44:11.691
cmgu2gpm401n7qlwckkvt6lpw	cmgu2gn5x0008qlwc51j7cb44	cmgu2gni6007nqlwc431gp7q9	\N	1	2025-10-16 23:44:11.693
cmgu2gpm701n9qlwcr2palb9c	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gni6007nqlwc431gp7q9	\N	1	2025-10-16 23:44:11.695
cmgu2gpm801nbqlwcfl2tbf0a	cmgu2gn500004qlwcjxvp6xez	cmgu2gni6007nqlwc431gp7q9	\N	1	2025-10-16 23:44:11.697
cmgu2gpmb01ndqlwccdzbjoh5	cmgu2gn620009qlwcdnj97s63	cmgu2gni6007nqlwc431gp7q9	\N	1	2025-10-16 23:44:11.699
cmgu2gpmd01nfqlwczod4qzyd	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gni6007nqlwc431gp7q9	\N	-1	2025-10-16 23:44:11.701
cmgu2gpmg01nhqlwct2qqslbb	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gni6007nqlwc431gp7q9	\N	1	2025-10-16 23:44:11.704
cmgu2gpmi01njqlwconkdf3ko	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gni6007nqlwc431gp7q9	\N	1	2025-10-16 23:44:11.706
cmgu2gpmk01nlqlwcm2s7k326	cmgu2gn500004qlwcjxvp6xez	cmgu2gnhf0073qlwcwuulorou	\N	1	2025-10-16 23:44:11.709
cmgu2gpmn01nnqlwc87vbwk2o	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnhf0073qlwcwuulorou	\N	1	2025-10-16 23:44:11.711
cmgu2gpmp01npqlwc6sv7j66o	cmgu2gn420000qlwcc82uc6sp	cmgu2gnhf0073qlwcwuulorou	\N	1	2025-10-16 23:44:11.714
cmgu2gpmt01nrqlwcyvtfz3gc	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnhf0073qlwcwuulorou	\N	1	2025-10-16 23:44:11.718
cmgu2gpmy01ntqlwcdlj3xfj4	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnhf0073qlwcwuulorou	\N	-1	2025-10-16 23:44:11.722
cmgu2gpn101nvqlwcdjpn5lim	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnhf0073qlwcwuulorou	\N	1	2025-10-16 23:44:11.725
cmgu2gpn501nxqlwc4biulim2	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnhf0073qlwcwuulorou	\N	1	2025-10-16 23:44:11.73
cmgu2gpn801nzqlwcq2d2u6e3	cmgu2gn620009qlwcdnj97s63	cmgu2gnhf0073qlwcwuulorou	\N	1	2025-10-16 23:44:11.732
cmgu2gpna01o1qlwchmbaxev2	cmgu2gn420000qlwcc82uc6sp	cmgu2gnja008fqlwcvkwxqr0e	\N	1	2025-10-16 23:44:11.734
cmgu2gpne01o3qlwcxs1nzgl6	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnja008fqlwcvkwxqr0e	\N	-1	2025-10-16 23:44:11.738
cmgu2gpni01o5qlwcu0bzwij0	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnja008fqlwcvkwxqr0e	\N	1	2025-10-16 23:44:11.742
cmgu2gpno01o7qlwcqe28z8rm	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnja008fqlwcvkwxqr0e	\N	1	2025-10-16 23:44:11.748
cmgu2gpns01o9qlwc1jmnd1cc	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnja008fqlwcvkwxqr0e	\N	1	2025-10-16 23:44:11.753
cmgu2gpnz01obqlwc9xxyd0ir	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnja008fqlwcvkwxqr0e	\N	1	2025-10-16 23:44:11.759
cmgu2gpo301odqlwc6d4kgls9	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnja008fqlwcvkwxqr0e	\N	1	2025-10-16 23:44:11.762
cmgu2gpo901ofqlwctcmuptws	cmgu2gn500004qlwcjxvp6xez	cmgu2gnja008fqlwcvkwxqr0e	\N	1	2025-10-16 23:44:11.769
cmgu2gpoc01ohqlwc1d6jjl99	cmgu2gn620009qlwcdnj97s63	cmgu2gnja008fqlwcvkwxqr0e	\N	1	2025-10-16 23:44:11.772
cmgu2gpof01ojqlwct1u19xig	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gni0007jqlwcrerqahm9	\N	1	2025-10-16 23:44:11.776
cmgu2gpoi01olqlwclqv8f49e	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gni0007jqlwcrerqahm9	\N	1	2025-10-16 23:44:11.778
cmgu2gpol01onqlwc84we1o79	cmgu2gn5x0008qlwc51j7cb44	cmgu2gni0007jqlwcrerqahm9	\N	1	2025-10-16 23:44:11.781
cmgu2gpop01opqlwcmwi9sw1r	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gni0007jqlwcrerqahm9	\N	-1	2025-10-16 23:44:11.785
cmgu2gpos01orqlwcmeio7jx0	cmgu2gn500004qlwcjxvp6xez	cmgu2gni0007jqlwcrerqahm9	\N	-1	2025-10-16 23:44:11.789
cmgu2gpoy01otqlwc4ijm6kv2	cmgu2gn5x0008qlwc51j7cb44	cmgu2gngz006rqlwckw33v4ks	\N	1	2025-10-16 23:44:11.794
cmgu2gpp201ovqlwcel5ei8yp	cmgu2gn500004qlwcjxvp6xez	cmgu2gngz006rqlwckw33v4ks	\N	-1	2025-10-16 23:44:11.798
cmgu2gpp801oxqlwcexu9h8y1	cmgu2gn420000qlwcc82uc6sp	cmgu2gngz006rqlwckw33v4ks	\N	1	2025-10-16 23:44:11.804
cmgu2gppd01ozqlwczhrto3dw	cmgu2gn620009qlwcdnj97s63	cmgu2gngz006rqlwckw33v4ks	\N	1	2025-10-16 23:44:11.809
cmgu2gppg01p1qlwc1ivhr1cz	cmgu2gn4p0002qlwc80wfogfe	cmgu2gngz006rqlwckw33v4ks	\N	-1	2025-10-16 23:44:11.812
cmgu2gppk01p3qlwc6py1c4b3	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnl9009vqlwcpd4swuy7	\N	1	2025-10-16 23:44:11.816
cmgu2gppn01p5qlwcw533q6bh	cmgu2gn620009qlwcdnj97s63	cmgu2gnl9009vqlwcpd4swuy7	\N	-1	2025-10-16 23:44:11.819
cmgu2gppp01p7qlwcta3ixl9r	cmgu2gn500004qlwcjxvp6xez	cmgu2gnl9009vqlwcpd4swuy7	\N	1	2025-10-16 23:44:11.821
cmgu2gpps01p9qlwck64tk6tk	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnhh0075qlwc1j0bigi1	\N	1	2025-10-16 23:44:11.824
cmgu2gppx01pbqlwcntb9dc08	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnhh0075qlwc1j0bigi1	\N	1	2025-10-16 23:44:11.829
cmgu2gpq301pdqlwcahrk0lbf	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnhh0075qlwc1j0bigi1	\N	1	2025-10-16 23:44:11.835
cmgu2gpq501pfqlwc8znyeawk	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnhh0075qlwc1j0bigi1	\N	1	2025-10-16 23:44:11.837
cmgu2gpq701phqlwco0u0masw	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnhh0075qlwc1j0bigi1	\N	-1	2025-10-16 23:44:11.84
cmgu2gpqa01pjqlwcx0e9h4s6	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnhh0075qlwc1j0bigi1	\N	1	2025-10-16 23:44:11.843
cmgu2gpqd01plqlwc90ffzhwn	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnhh0075qlwc1j0bigi1	\N	1	2025-10-16 23:44:11.846
cmgu2gpqg01pnqlwc71fupe7o	cmgu2gn620009qlwcdnj97s63	cmgu2gnhh0075qlwc1j0bigi1	\N	1	2025-10-16 23:44:11.848
cmgu2gpqi01ppqlwco8k4ae77	cmgu2gn500004qlwcjxvp6xez	cmgu2gnhh0075qlwc1j0bigi1	\N	1	2025-10-16 23:44:11.85
cmgu2gpqk01prqlwct7xddnhh	cmgu2gn420000qlwcc82uc6sp	cmgu2gnhh0075qlwc1j0bigi1	\N	1	2025-10-16 23:44:11.852
cmgu2gpqm01ptqlwc0kw6okm7	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnjt008vqlwcawp7orur	\N	1	2025-10-16 23:44:11.855
cmgu2gpqp01pvqlwc5pdikrkx	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnjt008vqlwcawp7orur	\N	1	2025-10-16 23:44:11.857
cmgu2gpqr01pxqlwc2ienicwe	cmgu2gn420000qlwcc82uc6sp	cmgu2gnjt008vqlwcawp7orur	\N	1	2025-10-16 23:44:11.859
cmgu2gpqt01pzqlwclk7lr4wp	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnm400ajqlwc5sfuue6y	\N	1	2025-10-16 23:44:11.862
cmgu2gpqx01q1qlwcgqj9qwye	cmgu2gn500004qlwcjxvp6xez	cmgu2gnm400ajqlwc5sfuue6y	\N	-1	2025-10-16 23:44:11.866
cmgu2gpr301q3qlwcjyv2snhh	cmgu2gn620009qlwcdnj97s63	cmgu2gnm400ajqlwc5sfuue6y	\N	1	2025-10-16 23:44:11.871
cmgu2gpr501q5qlwcdzheq04s	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnm400ajqlwc5sfuue6y	\N	1	2025-10-16 23:44:11.874
cmgu2gpr801q7qlwcmalo7o28	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnm400ajqlwc5sfuue6y	\N	1	2025-10-16 23:44:11.876
cmgu2gpra01q9qlwcix1xpv6i	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnff005lqlwcea7weget	\N	-1	2025-10-16 23:44:11.879
cmgu2gprd01qbqlwcjeoplguu	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnff005lqlwcea7weget	\N	1	2025-10-16 23:44:11.881
cmgu2gprg01qdqlwc5znhhp54	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnff005lqlwcea7weget	\N	1	2025-10-16 23:44:11.884
cmgu2gpri01qfqlwcwloymcum	cmgu2gn420000qlwcc82uc6sp	cmgu2gnff005lqlwcea7weget	\N	1	2025-10-16 23:44:11.886
cmgu2gprk01qhqlwchp12j13s	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnff005lqlwcea7weget	\N	-1	2025-10-16 23:44:11.889
cmgu2gprm01qjqlwclqut7pq7	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnff005lqlwcea7weget	\N	-1	2025-10-16 23:44:11.891
cmgu2gpro01qlqlwc3vz8iaut	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnff005lqlwcea7weget	\N	1	2025-10-16 23:44:11.893
cmgu2gprq01qnqlwcg2gv4e09	cmgu2gn500004qlwcjxvp6xez	cmgu2gnff005lqlwcea7weget	\N	1	2025-10-16 23:44:11.895
cmgu2gprs01qpqlwckrdc97w4	cmgu2gn500004qlwcjxvp6xez	cmgu2gnjo008rqlwcx4frguc9	\N	1	2025-10-16 23:44:11.897
cmgu2gpru01qrqlwcjzictj3d	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnjo008rqlwcx4frguc9	\N	1	2025-10-16 23:44:11.899
cmgu2gprw01qtqlwcz859lu52	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnjo008rqlwcx4frguc9	\N	1	2025-10-16 23:44:11.901
cmgu2gpry01qvqlwcy65d87cu	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnjo008rqlwcx4frguc9	\N	1	2025-10-16 23:44:11.903
cmgu2gps001qxqlwcsf9h4n3i	cmgu2gn420000qlwcc82uc6sp	cmgu2gnjo008rqlwcx4frguc9	\N	-1	2025-10-16 23:44:11.905
cmgu2gps201qzqlwcvsn93ghi	cmgu2gn620009qlwcdnj97s63	cmgu2gnjo008rqlwcx4frguc9	\N	1	2025-10-16 23:44:11.907
cmgu2gps401r1qlwcqut9mxbk	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnjo008rqlwcx4frguc9	\N	1	2025-10-16 23:44:11.909
cmgu2gps601r3qlwckfbd24x0	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnjo008rqlwcx4frguc9	\N	1	2025-10-16 23:44:11.911
cmgu2gps901r5qlwciz20kmzc	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnhn0079qlwcpw5y5ivj	\N	1	2025-10-16 23:44:11.913
cmgu2gpsb01r7qlwcawu6xkpi	cmgu2gn620009qlwcdnj97s63	cmgu2gnhn0079qlwcpw5y5ivj	\N	1	2025-10-16 23:44:11.915
cmgu2gpsd01r9qlwciq2z6740	cmgu2gn500004qlwcjxvp6xez	cmgu2gnhn0079qlwcpw5y5ivj	\N	1	2025-10-16 23:44:11.918
cmgu2gpsf01rbqlwc3yxh5tkt	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnhn0079qlwcpw5y5ivj	\N	1	2025-10-16 23:44:11.92
cmgu2gpsh01rdqlwcpqajvwt1	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnhn0079qlwcpw5y5ivj	\N	1	2025-10-16 23:44:11.921
cmgu2gpso01rfqlwcuowbodxe	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnhn0079qlwcpw5y5ivj	\N	1	2025-10-16 23:44:11.928
cmgu2gpss01rhqlwc3p7m6n9a	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnhn0079qlwcpw5y5ivj	\N	-1	2025-10-16 23:44:11.933
cmgu2gpsv01rjqlwclrsptoqm	cmgu2gn420000qlwcc82uc6sp	cmgu2gnhn0079qlwcpw5y5ivj	\N	1	2025-10-16 23:44:11.935
cmgu2gpsx01rlqlwcb25nrjed	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnhn0079qlwcpw5y5ivj	\N	1	2025-10-16 23:44:11.937
cmgu2gpsz01rnqlwcc4nioiqa	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnhn0079qlwcpw5y5ivj	\N	1	2025-10-16 23:44:11.94
cmgu2gpt201rpqlwcpgq9q9le	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gngx006pqlwc65h899fc	\N	1	2025-10-16 23:44:11.942
cmgu2gpt401rrqlwcnfykqn36	cmgu2gn4p0002qlwc80wfogfe	cmgu2gngx006pqlwc65h899fc	\N	1	2025-10-16 23:44:11.944
cmgu2gpt601rtqlwc4emy8ito	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gngx006pqlwc65h899fc	\N	-1	2025-10-16 23:44:11.946
cmgu2gpt801rvqlwc589ct51k	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gngx006pqlwc65h899fc	\N	1	2025-10-16 23:44:11.948
cmgu2gpta01rxqlwcp4v4chks	cmgu2gn500004qlwcjxvp6xez	cmgu2gngx006pqlwc65h899fc	\N	1	2025-10-16 23:44:11.951
cmgu2gptc01rzqlwcobe6vas9	cmgu2gn420000qlwcc82uc6sp	cmgu2gngx006pqlwc65h899fc	\N	-1	2025-10-16 23:44:11.953
cmgu2gpte01s1qlwc0qy9sxcp	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gngx006pqlwc65h899fc	\N	1	2025-10-16 23:44:11.955
cmgu2gpth01s3qlwcwxpctvm3	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gngx006pqlwc65h899fc	\N	-1	2025-10-16 23:44:11.957
cmgu2gptj01s5qlwcfwe4jney	cmgu2gn620009qlwcdnj97s63	cmgu2gngx006pqlwc65h899fc	\N	-1	2025-10-16 23:44:11.959
cmgu2gptl01s7qlwcs3iisxrh	cmgu2gn5x0008qlwc51j7cb44	cmgu2gngx006pqlwc65h899fc	\N	1	2025-10-16 23:44:11.961
cmgu2gptn01s9qlwccajt5f3y	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnga0069qlwcv0z1ejjv	\N	1	2025-10-16 23:44:11.964
cmgu2gptp01sbqlwccsgd7kly	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnga0069qlwcv0z1ejjv	\N	-1	2025-10-16 23:44:11.966
cmgu2gptr01sdqlwcuwco16xy	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnga0069qlwcv0z1ejjv	\N	1	2025-10-16 23:44:11.968
cmgu2gptt01sfqlwcekmw66il	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnga0069qlwcv0z1ejjv	\N	1	2025-10-16 23:44:11.97
cmgu2gptv01shqlwc8m35wpwt	cmgu2gn420000qlwcc82uc6sp	cmgu2gnga0069qlwcv0z1ejjv	\N	1	2025-10-16 23:44:11.972
cmgu2gptx01sjqlwco3vp3crq	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnga0069qlwcv0z1ejjv	\N	1	2025-10-16 23:44:11.974
cmgu2gpu001slqlwc9gcur2j7	cmgu2gn500004qlwcjxvp6xez	cmgu2gnga0069qlwcv0z1ejjv	\N	-1	2025-10-16 23:44:11.976
cmgu2gpu201snqlwcbrgrsjqh	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnga0069qlwcv0z1ejjv	\N	1	2025-10-16 23:44:11.978
cmgu2gpu401spqlwchpvx2waj	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnh5006vqlwcjzjtpsba	\N	1	2025-10-16 23:44:11.98
cmgu2gpu601srqlwcrjcbza97	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnh5006vqlwcjzjtpsba	\N	1	2025-10-16 23:44:11.982
cmgu2gpu801stqlwcn6mx9k2m	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnh5006vqlwcjzjtpsba	\N	1	2025-10-16 23:44:11.985
cmgu2gpua01svqlwcxsgw0wjy	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnh5006vqlwcjzjtpsba	\N	1	2025-10-16 23:44:11.987
cmgu2gpuc01sxqlwc00niffuh	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnh5006vqlwcjzjtpsba	\N	1	2025-10-16 23:44:11.989
cmgu2gpue01szqlwc2c75zazc	cmgu2gn620009qlwcdnj97s63	cmgu2gnh5006vqlwcjzjtpsba	\N	-1	2025-10-16 23:44:11.991
cmgu2gpug01t1qlwc702vxaym	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnmb00apqlwc1jlv03ic	\N	1	2025-10-16 23:44:11.993
cmgu2gpui01t3qlwckt7xnzu1	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnmb00apqlwc1jlv03ic	\N	1	2025-10-16 23:44:11.995
cmgu2gpuk01t5qlwc04xz1gdf	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnmb00apqlwc1jlv03ic	\N	1	2025-10-16 23:44:11.997
cmgu2gpum01t7qlwcdx8i6i7d	cmgu2gn500004qlwcjxvp6xez	cmgu2gniy0089qlwcsaw897wa	\N	1	2025-10-16 23:44:11.999
cmgu2gpuo01t9qlwci1b2mz43	cmgu2gn620009qlwcdnj97s63	cmgu2gniy0089qlwcsaw897wa	\N	1	2025-10-16 23:44:12.001
cmgu2gpuq01tbqlwchmpo7fps	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gniy0089qlwcsaw897wa	\N	1	2025-10-16 23:44:12.003
cmgu2gput01tdqlwct8uq96dg	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gniy0089qlwcsaw897wa	\N	1	2025-10-16 23:44:12.006
cmgu2gpuw01tfqlwcnjdlwlh5	cmgu2gn4p0002qlwc80wfogfe	cmgu2gniy0089qlwcsaw897wa	\N	1	2025-10-16 23:44:12.008
cmgu2gpuy01thqlwcmwcrw51u	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gniy0089qlwcsaw897wa	\N	1	2025-10-16 23:44:12.01
cmgu2gpv001tjqlwc6x106cni	cmgu2gn5x0008qlwc51j7cb44	cmgu2gniy0089qlwcsaw897wa	\N	1	2025-10-16 23:44:12.013
cmgu2gpv301tlqlwc6iv668fh	cmgu2gn420000qlwcc82uc6sp	cmgu2gniy0089qlwcsaw897wa	\N	1	2025-10-16 23:44:12.015
cmgu2gpv501tnqlwceenul2jg	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnll00a3qlwc9n91f457	\N	1	2025-10-16 23:44:12.018
cmgu2gpva01tpqlwcgqznamrq	cmgu2gn420000qlwcc82uc6sp	cmgu2gnll00a3qlwc9n91f457	\N	1	2025-10-16 23:44:12.023
cmgu2gpvd01trqlwcdfes9kls	cmgu2gn500004qlwcjxvp6xez	cmgu2gnll00a3qlwc9n91f457	\N	-1	2025-10-16 23:44:12.025
cmgu2gpvg01ttqlwc2iaa8mr9	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnll00a3qlwc9n91f457	\N	1	2025-10-16 23:44:12.028
cmgu2gpvi01tvqlwcp26bxtpc	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnll00a3qlwc9n91f457	\N	1	2025-10-16 23:44:12.03
cmgu2gpvk01txqlwcsx7qjybx	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnll00a3qlwc9n91f457	\N	1	2025-10-16 23:44:12.033
cmgu2gpvm01tzqlwc6eq7hjw4	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnll00a3qlwc9n91f457	\N	1	2025-10-16 23:44:12.035
cmgu2gpvp01u1qlwc9igucn90	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnll00a3qlwc9n91f457	\N	1	2025-10-16 23:44:12.037
cmgu2gpvr01u3qlwclujk7vxe	cmgu2gn620009qlwcdnj97s63	cmgu2gnll00a3qlwc9n91f457	\N	1	2025-10-16 23:44:12.039
cmgu2gpvt01u5qlwc9zmdd3da	cmgu2gn420000qlwcc82uc6sp	cmgu2gnhy007hqlwcoyumsrpn	\N	1	2025-10-16 23:44:12.041
cmgu2gpvw01u7qlwc6bitkaj8	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnhy007hqlwcoyumsrpn	\N	1	2025-10-16 23:44:12.045
cmgu2gpvy01u9qlwcm7wh980u	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnhy007hqlwcoyumsrpn	\N	1	2025-10-16 23:44:12.047
cmgu2gpw101ubqlwcgqr0dm05	cmgu2gn500004qlwcjxvp6xez	cmgu2gnhy007hqlwcoyumsrpn	\N	1	2025-10-16 23:44:12.049
cmgu2gpw301udqlwcbet6r79e	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnhy007hqlwcoyumsrpn	\N	1	2025-10-16 23:44:12.051
cmgu2gpw501ufqlwczqtuveim	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnhy007hqlwcoyumsrpn	\N	1	2025-10-16 23:44:12.054
cmgu2gpw801uhqlwcu8aka9ym	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnhy007hqlwcoyumsrpn	\N	1	2025-10-16 23:44:12.057
cmgu2gpwb01ujqlwcny8anmtp	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnhy007hqlwcoyumsrpn	\N	1	2025-10-16 23:44:12.059
cmgu2gpwe01ulqlwcu1m2z0gs	cmgu2gn620009qlwcdnj97s63	cmgu2gnhy007hqlwcoyumsrpn	\N	1	2025-10-16 23:44:12.062
cmgu2gpwh01unqlwckl2a82gh	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnhy007hqlwcoyumsrpn	\N	1	2025-10-16 23:44:12.065
cmgu2gpwj01upqlwc9lqms9rl	cmgu2gn4p0002qlwc80wfogfe	cmgu2gniw0087qlwc0hlk874k	\N	1	2025-10-16 23:44:12.068
cmgu2gpwl01urqlwcejsv71kj	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gniw0087qlwc0hlk874k	\N	1	2025-10-16 23:44:12.07
cmgu2gpwo01utqlwcla6yski2	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gniw0087qlwc0hlk874k	\N	-1	2025-10-16 23:44:12.072
cmgu2gpwr01uvqlwc1mzia3x0	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gniw0087qlwc0hlk874k	\N	-1	2025-10-16 23:44:12.075
cmgu2gpwt01uxqlwc9i0a5hj6	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gniw0087qlwc0hlk874k	\N	1	2025-10-16 23:44:12.077
cmgu2gpwv01uzqlwcyf3eslsj	cmgu2gn620009qlwcdnj97s63	cmgu2gniw0087qlwc0hlk874k	\N	1	2025-10-16 23:44:12.079
cmgu2gpwx01v1qlwcu9qfmpsg	cmgu2gn5x0008qlwc51j7cb44	cmgu2gniw0087qlwc0hlk874k	\N	1	2025-10-16 23:44:12.082
cmgu2gpwz01v3qlwcb0u9yvw7	cmgu2gn500004qlwcjxvp6xez	cmgu2gniw0087qlwc0hlk874k	\N	-1	2025-10-16 23:44:12.084
cmgu2gpx101v5qlwcdib8ks8t	cmgu2gn420000qlwcc82uc6sp	cmgu2gniw0087qlwc0hlk874k	\N	-1	2025-10-16 23:44:12.086
cmgu2gpx301v7qlwc1p1eo3w3	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnjd008hqlwce9ko8bra	\N	-1	2025-10-16 23:44:12.088
cmgu2gpx501v9qlwccvhgr9yk	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnjd008hqlwce9ko8bra	\N	1	2025-10-16 23:44:12.09
cmgu2gpx801vbqlwc7qqee5tq	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnjd008hqlwce9ko8bra	\N	1	2025-10-16 23:44:12.092
cmgu2gpxa01vdqlwcjypellfy	cmgu2gn500004qlwcjxvp6xez	cmgu2gnjd008hqlwce9ko8bra	\N	1	2025-10-16 23:44:12.094
cmgu2gpxc01vfqlwcpotpfjhw	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnjd008hqlwce9ko8bra	\N	-1	2025-10-16 23:44:12.096
cmgu2gpxe01vhqlwc1iufiqf1	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnjd008hqlwce9ko8bra	\N	1	2025-10-16 23:44:12.099
cmgu2gpxk01vjqlwcf1prgdnb	cmgu2gn420000qlwcc82uc6sp	cmgu2gnjd008hqlwce9ko8bra	\N	1	2025-10-16 23:44:12.104
cmgu2gpxq01vlqlwc6fiekhsu	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnjd008hqlwce9ko8bra	\N	1	2025-10-16 23:44:12.11
cmgu2gpxs01vnqlwcfodyo1c3	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnjd008hqlwce9ko8bra	\N	1	2025-10-16 23:44:12.113
cmgu2gpxw01vpqlwcgpa576ym	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnk30093qlwc9recucdk	\N	1	2025-10-16 23:44:12.116
cmgu2gpxy01vrqlwc96ppp1lk	cmgu2gn620009qlwcdnj97s63	cmgu2gnk30093qlwc9recucdk	\N	1	2025-10-16 23:44:12.118
cmgu2gpy001vtqlwcij27voy8	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnk30093qlwc9recucdk	\N	-1	2025-10-16 23:44:12.12
cmgu2gpy201vvqlwcanm1s4z6	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnk30093qlwc9recucdk	\N	1	2025-10-16 23:44:12.122
cmgu2gpy401vxqlwcoimqq5sl	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnk30093qlwc9recucdk	\N	-1	2025-10-16 23:44:12.125
cmgu2gpy601vzqlwcvdrzahgf	cmgu2gn500004qlwcjxvp6xez	cmgu2gnk30093qlwc9recucdk	\N	1	2025-10-16 23:44:12.126
cmgu2gpy801w1qlwc6wsj9o35	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnk30093qlwc9recucdk	\N	1	2025-10-16 23:44:12.129
cmgu2gpya01w3qlwc9dhktk21	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnk30093qlwc9recucdk	\N	1	2025-10-16 23:44:12.131
cmgu2gpyd01w5qlwcdmupzjvg	cmgu2gn420000qlwcc82uc6sp	cmgu2gnk30093qlwc9recucdk	\N	1	2025-10-16 23:44:12.133
cmgu2gpyf01w7qlwcb4e4joul	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnk30093qlwc9recucdk	\N	1	2025-10-16 23:44:12.135
cmgu2gpyh01w9qlwcdkyde5fi	cmgu2gn420000qlwcc82uc6sp	cmgu2gnf5005fqlwcoglbuqud	\N	1	2025-10-16 23:44:12.137
cmgu2gpyj01wbqlwc6r69k51q	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnf5005fqlwcoglbuqud	\N	1	2025-10-16 23:44:12.139
cmgu2gpyl01wdqlwcsn6gyb8b	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnf5005fqlwcoglbuqud	\N	1	2025-10-16 23:44:12.141
cmgu2gpyn01wfqlwcgqtv5vca	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnf5005fqlwcoglbuqud	\N	1	2025-10-16 23:44:12.144
cmgu2gpyp01whqlwc8tk4bnxh	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnf5005fqlwcoglbuqud	\N	1	2025-10-16 23:44:12.146
cmgu2gpys01wjqlwc19c1xf63	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnf5005fqlwcoglbuqud	\N	1	2025-10-16 23:44:12.148
cmgu2gpyu01wlqlwc61vdwl69	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnf5005fqlwcoglbuqud	\N	1	2025-10-16 23:44:12.151
cmgu2gpyw01wnqlwcn4bu1c5g	cmgu2gn500004qlwcjxvp6xez	cmgu2gnf5005fqlwcoglbuqud	\N	-1	2025-10-16 23:44:12.153
cmgu2gpyy01wpqlwc0p86r1au	cmgu2gn620009qlwcdnj97s63	cmgu2gnf5005fqlwcoglbuqud	\N	1	2025-10-16 23:44:12.154
cmgu2gpz001wrqlwcdirju78m	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnf5005fqlwcoglbuqud	\N	1	2025-10-16 23:44:12.156
cmgu2gpz201wtqlwcpn1sbo0d	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnk90097qlwc9nh7qwx4	\N	1	2025-10-16 23:44:12.158
cmgu2gpz401wvqlwcj26vqycj	cmgu2gn620009qlwcdnj97s63	cmgu2gnk90097qlwc9nh7qwx4	\N	1	2025-10-16 23:44:12.16
cmgu2gpz601wxqlwc5w7cebx9	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnk90097qlwc9nh7qwx4	\N	1	2025-10-16 23:44:12.162
cmgu2gpz801wzqlwc3dpetg33	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnk90097qlwc9nh7qwx4	\N	1	2025-10-16 23:44:12.164
cmgu2gpza01x1qlwcm7lrh77j	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnk90097qlwc9nh7qwx4	\N	1	2025-10-16 23:44:12.167
cmgu2gpzc01x3qlwcvrsglmiw	cmgu2gn500004qlwcjxvp6xez	cmgu2gnk90097qlwc9nh7qwx4	\N	-1	2025-10-16 23:44:12.169
cmgu2gpze01x5qlwclfh3sdga	cmgu2gn420000qlwcc82uc6sp	cmgu2gnk90097qlwc9nh7qwx4	\N	1	2025-10-16 23:44:12.17
cmgu2gpzg01x7qlwcb9wmrisw	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnk90097qlwc9nh7qwx4	\N	1	2025-10-16 23:44:12.173
cmgu2gpzi01x9qlwcckoi2f9e	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnk90097qlwc9nh7qwx4	\N	1	2025-10-16 23:44:12.174
cmgu2gpzk01xbqlwccpcjiqpv	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnk90097qlwc9nh7qwx4	\N	1	2025-10-16 23:44:12.176
cmgu2gpzm01xdqlwc5ksda79j	cmgu2gn620009qlwcdnj97s63	cmgu2gnjk008nqlwci580g2tw	\N	-1	2025-10-16 23:44:12.178
cmgu2gpzp01xfqlwcz8i55wpr	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnjk008nqlwci580g2tw	\N	1	2025-10-16 23:44:12.182
cmgu2gpzr01xhqlwcuzr4zxat	cmgu2gn500004qlwcjxvp6xez	cmgu2gnjk008nqlwci580g2tw	\N	-1	2025-10-16 23:44:12.184
cmgu2gpzt01xjqlwc6afsoab0	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnjk008nqlwci580g2tw	\N	1	2025-10-16 23:44:12.186
cmgu2gpzw01xlqlwcvrrdoo1x	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnfi005nqlwcnzqeyknu	\N	1	2025-10-16 23:44:12.188
cmgu2gpzy01xnqlwcrfa4n7da	cmgu2gn620009qlwcdnj97s63	cmgu2gnfi005nqlwcnzqeyknu	\N	-1	2025-10-16 23:44:12.19
cmgu2gq0001xpqlwczp62yukw	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnfi005nqlwcnzqeyknu	\N	1	2025-10-16 23:44:12.192
cmgu2gq0101xrqlwcimy5n6nv	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnfi005nqlwcnzqeyknu	\N	1	2025-10-16 23:44:12.194
cmgu2gq0301xtqlwc3py41u5r	cmgu2gn500004qlwcjxvp6xez	cmgu2gnfi005nqlwcnzqeyknu	\N	1	2025-10-16 23:44:12.196
cmgu2gq0501xvqlwcmmneim3u	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnfi005nqlwcnzqeyknu	\N	1	2025-10-16 23:44:12.198
cmgu2gq0701xxqlwcyz13jm35	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnfi005nqlwcnzqeyknu	\N	1	2025-10-16 23:44:12.2
cmgu2gq0901xzqlwckbje17vc	cmgu2gn420000qlwcc82uc6sp	cmgu2gnfi005nqlwcnzqeyknu	\N	-1	2025-10-16 23:44:12.202
cmgu2gq0b01y1qlwcwrd4k6r9	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnkg009bqlwcb1bb9okj	\N	1	2025-10-16 23:44:12.203
cmgu2gq0d01y3qlwcr0qx33my	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnkg009bqlwcb1bb9okj	\N	1	2025-10-16 23:44:12.205
cmgu2gq0f01y5qlwc8wrf7wo1	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnkg009bqlwcb1bb9okj	\N	1	2025-10-16 23:44:12.207
cmgu2gq0h01y7qlwc38yi534o	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnk60095qlwcid6g7s9i	\N	1	2025-10-16 23:44:12.209
cmgu2gq0j01y9qlwc4e61snp9	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnk60095qlwcid6g7s9i	\N	1	2025-10-16 23:44:12.211
cmgu2gq0l01ybqlwc1dczenhu	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnk60095qlwcid6g7s9i	\N	1	2025-10-16 23:44:12.213
cmgu2gq0m01ydqlwczlx33tcb	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnk60095qlwcid6g7s9i	\N	1	2025-10-16 23:44:12.215
cmgu2gq0o01yfqlwccog72y8a	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnk60095qlwcid6g7s9i	\N	1	2025-10-16 23:44:12.217
cmgu2gq0q01yhqlwc090xhl5e	cmgu2gn500004qlwcjxvp6xez	cmgu2gnit0085qlwc1j8lc8nm	\N	1	2025-10-16 23:44:12.218
cmgu2gq0s01yjqlwcsycb9u3e	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnit0085qlwc1j8lc8nm	\N	1	2025-10-16 23:44:12.22
cmgu2gq0u01ylqlwc7kdiyhux	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnit0085qlwc1j8lc8nm	\N	1	2025-10-16 23:44:12.222
cmgu2gq0w01ynqlwcxy566e92	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnit0085qlwc1j8lc8nm	\N	-1	2025-10-16 23:44:12.224
cmgu2gq0y01ypqlwc61eafrjl	cmgu2gn420000qlwcc82uc6sp	cmgu2gnit0085qlwc1j8lc8nm	\N	-1	2025-10-16 23:44:12.226
cmgu2gq1001yrqlwcgdncwoa6	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnjm008pqlwc8shv880s	\N	1	2025-10-16 23:44:12.228
cmgu2gq1101ytqlwcf0dg49yp	cmgu2gn420000qlwcc82uc6sp	cmgu2gnjm008pqlwc8shv880s	\N	-1	2025-10-16 23:44:12.23
cmgu2gq1301yvqlwcjm01lshb	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnjm008pqlwc8shv880s	\N	1	2025-10-16 23:44:12.232
cmgu2gq1501yxqlwcvbaeqzje	cmgu2gn620009qlwcdnj97s63	cmgu2gnjm008pqlwc8shv880s	\N	1	2025-10-16 23:44:12.234
cmgu2gq1701yzqlwcjbnj0ygf	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnjm008pqlwc8shv880s	\N	1	2025-10-16 23:44:12.236
cmgu2gq1901z1qlwchecyxs6q	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnf8005hqlwc31vhv72o	\N	1	2025-10-16 23:44:12.238
cmgu2gq1b01z3qlwc1zm529oa	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnf8005hqlwc31vhv72o	\N	1	2025-10-16 23:44:12.24
cmgu2gq1d01z5qlwctm7qevqn	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnf8005hqlwc31vhv72o	\N	-1	2025-10-16 23:44:12.242
cmgu2gq1f01z7qlwc4uoixatf	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnf8005hqlwc31vhv72o	\N	1	2025-10-16 23:44:12.244
cmgu2gq1h01z9qlwc4o8e2uhs	cmgu2gn620009qlwcdnj97s63	cmgu2gnf8005hqlwc31vhv72o	\N	1	2025-10-16 23:44:12.246
cmgu2gq1k01zbqlwck7bh8g0k	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnf8005hqlwc31vhv72o	\N	1	2025-10-16 23:44:12.248
cmgu2gq1m01zdqlwc04ykmny0	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnf8005hqlwc31vhv72o	\N	1	2025-10-16 23:44:12.25
cmgu2gq1o01zfqlwc2pv7faa9	cmgu2gn500004qlwcjxvp6xez	cmgu2gnf8005hqlwc31vhv72o	\N	-1	2025-10-16 23:44:12.252
cmgu2gq1p01zhqlwcwsdgkglk	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnf8005hqlwc31vhv72o	\N	-1	2025-10-16 23:44:12.254
cmgu2gq1r01zjqlwcmcweogx1	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnhd0071qlwc97sfr00k	\N	1	2025-10-16 23:44:12.256
cmgu2gq1t01zlqlwc1ulsu62e	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnhd0071qlwc97sfr00k	\N	1	2025-10-16 23:44:12.258
cmgu2gq1v01znqlwc8zaniani	cmgu2gn420000qlwcc82uc6sp	cmgu2gnhd0071qlwc97sfr00k	\N	-1	2025-10-16 23:44:12.259
cmgu2gq1x01zpqlwcd63wmnhp	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnhd0071qlwc97sfr00k	\N	1	2025-10-16 23:44:12.261
cmgu2gq2101zrqlwcvv96yqcr	cmgu2gn500004qlwcjxvp6xez	cmgu2gnhd0071qlwc97sfr00k	\N	1	2025-10-16 23:44:12.265
cmgu2gq2301ztqlwcozcpsojb	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnhd0071qlwc97sfr00k	\N	1	2025-10-16 23:44:12.267
cmgu2gq2701zvqlwctf0qfz9f	cmgu2gn420000qlwcc82uc6sp	cmgu2gnfq005tqlwc546jitoa	\N	1	2025-10-16 23:44:12.271
cmgu2gq2901zxqlwczqhi9fkq	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnfq005tqlwc546jitoa	\N	-1	2025-10-16 23:44:12.273
cmgu2gq2b01zzqlwczpslcl6j	cmgu2gn4p0002qlwc80wfogfe	cmgu2gnfq005tqlwc546jitoa	\N	1	2025-10-16 23:44:12.275
cmgu2gq2d0201qlwckltyyklg	cmgu2gn500004qlwcjxvp6xez	cmgu2gnfq005tqlwc546jitoa	\N	-1	2025-10-16 23:44:12.277
cmgu2gq2f0203qlwc6z6khipx	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnfq005tqlwc546jitoa	\N	1	2025-10-16 23:44:12.279
cmgu2gq2i0205qlwcpbm4aokx	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnfq005tqlwc546jitoa	\N	1	2025-10-16 23:44:12.282
cmgu2gq2k0207qlwc8p85yqze	cmgu2gn620009qlwcdnj97s63	cmgu2gnfq005tqlwc546jitoa	\N	1	2025-10-16 23:44:12.284
cmgu2gq2m0209qlwcbyzc631t	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnfq005tqlwc546jitoa	\N	1	2025-10-16 23:44:12.286
cmgu2gq2o020bqlwca8t9daxm	cmgu2gn4k0001qlwc2fpdaslv	cmgu2gnfq005tqlwc546jitoa	\N	1	2025-10-16 23:44:12.288
cmgu2gq2q020dqlwc4ag8c1mh	cmgu2gn5f0005qlwcdx8tb0kd	cmgu2gnhv007fqlwcof2gdbb4	\N	-1	2025-10-16 23:44:12.29
cmgu2gq2s020fqlwck570wryy	cmgu2gn420000qlwcc82uc6sp	cmgu2gnhv007fqlwcof2gdbb4	\N	1	2025-10-16 23:44:12.292
cmgu2gq2u020hqlwc6z0oqt63	cmgu2gn5x0008qlwc51j7cb44	cmgu2gnhv007fqlwcof2gdbb4	\N	-1	2025-10-16 23:44:12.294
cmgu2gq2w020jqlwcw9qiisv7	cmgu2gn5n0006qlwcqfu7g12g	cmgu2gnhv007fqlwcof2gdbb4	\N	1	2025-10-16 23:44:12.296
cmgu2gq2y020lqlwcmbtbixiy	cmgu2gn4v0003qlwcugkrmdpr	cmgu2gnhv007fqlwcof2gdbb4	\N	1	2025-10-16 23:44:12.298
cmgu2gq30020nqlwcsi08mkyc	cmgu2gn5s0007qlwcjhhzi8m9	cmgu2gnhv007fqlwcof2gdbb4	\N	1	2025-10-16 23:44:12.3
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
697ed9d4-a55e-4ea0-887c-28f2e6e7d943	e42133ff5f553b40f70d77a23fe1196bebc7e673668932d323d8ad5163532444	2025-11-19 02:22:11.615687+00	20240902000000_init		\N	2025-11-19 02:22:11.615687+00	0
\.


--
-- Data for Name: brad_waitlist; Type: TABLE DATA; Schema: public; Owner: cryb_user
--

COPY public.brad_waitlist (id, name, email, phone, interest, "submittedAt") FROM stdin;
cmjivn7nj00009gscucigsc5l	Joel Kubler	joelkubler25@gmail.com	4423390525	partner	2025-12-23 17:46:56.762
\.


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: Award Award_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Award"
    ADD CONSTRAINT "Award_pkey" PRIMARY KEY (id);


--
-- Name: Ban Ban_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Ban"
    ADD CONSTRAINT "Ban_pkey" PRIMARY KEY (id);


--
-- Name: Block Block_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Block"
    ADD CONSTRAINT "Block_pkey" PRIMARY KEY (id);


--
-- Name: Bookmark Bookmark_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Bookmark"
    ADD CONSTRAINT "Bookmark_pkey" PRIMARY KEY (id);


--
-- Name: ChannelPermission ChannelPermission_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."ChannelPermission"
    ADD CONSTRAINT "ChannelPermission_pkey" PRIMARY KEY (id);


--
-- Name: Channel Channel_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Channel"
    ADD CONSTRAINT "Channel_pkey" PRIMARY KEY (id);


--
-- Name: ChunkedUploadSession ChunkedUploadSession_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."ChunkedUploadSession"
    ADD CONSTRAINT "ChunkedUploadSession_pkey" PRIMARY KEY (id);


--
-- Name: Comment Comment_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Comment"
    ADD CONSTRAINT "Comment_pkey" PRIMARY KEY (id);


--
-- Name: CommunityBadge CommunityBadge_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."CommunityBadge"
    ADD CONSTRAINT "CommunityBadge_pkey" PRIMARY KEY (id);


--
-- Name: CommunityMember CommunityMember_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."CommunityMember"
    ADD CONSTRAINT "CommunityMember_pkey" PRIMARY KEY (id);


--
-- Name: Community Community_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Community"
    ADD CONSTRAINT "Community_pkey" PRIMARY KEY (id);


--
-- Name: CryptoPayment CryptoPayment_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."CryptoPayment"
    ADD CONSTRAINT "CryptoPayment_pkey" PRIMARY KEY (id);


--
-- Name: CryptoTip CryptoTip_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."CryptoTip"
    ADD CONSTRAINT "CryptoTip_pkey" PRIMARY KEY (id);


--
-- Name: DirectMessageParticipant DirectMessageParticipant_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."DirectMessageParticipant"
    ADD CONSTRAINT "DirectMessageParticipant_pkey" PRIMARY KEY (id);


--
-- Name: FileAccessLog FileAccessLog_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."FileAccessLog"
    ADD CONSTRAINT "FileAccessLog_pkey" PRIMARY KEY (id);


--
-- Name: FileAnalytics FileAnalytics_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."FileAnalytics"
    ADD CONSTRAINT "FileAnalytics_pkey" PRIMARY KEY (id);


--
-- Name: FilePermission FilePermission_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."FilePermission"
    ADD CONSTRAINT "FilePermission_pkey" PRIMARY KEY (id);


--
-- Name: FileVariant FileVariant_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."FileVariant"
    ADD CONSTRAINT "FileVariant_pkey" PRIMARY KEY (id);


--
-- Name: Flair Flair_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Flair"
    ADD CONSTRAINT "Flair_pkey" PRIMARY KEY (id);


--
-- Name: Follow Follow_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Follow"
    ADD CONSTRAINT "Follow_pkey" PRIMARY KEY (id);


--
-- Name: Friendship Friendship_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Friendship"
    ADD CONSTRAINT "Friendship_pkey" PRIMARY KEY (id);


--
-- Name: GovernanceProposal GovernanceProposal_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."GovernanceProposal"
    ADD CONSTRAINT "GovernanceProposal_pkey" PRIMARY KEY (id);


--
-- Name: GovernanceVote GovernanceVote_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."GovernanceVote"
    ADD CONSTRAINT "GovernanceVote_pkey" PRIMARY KEY (id);


--
-- Name: HiddenWord HiddenWord_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."HiddenWord"
    ADD CONSTRAINT "HiddenWord_pkey" PRIMARY KEY (id);


--
-- Name: Invite Invite_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Invite"
    ADD CONSTRAINT "Invite_pkey" PRIMARY KEY (id);


--
-- Name: Like Like_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Like"
    ADD CONSTRAINT "Like_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceBid MarketplaceBid_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MarketplaceBid"
    ADD CONSTRAINT "MarketplaceBid_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceListing MarketplaceListing_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MarketplaceListing"
    ADD CONSTRAINT "MarketplaceListing_pkey" PRIMARY KEY (id);


--
-- Name: MarketplaceSale MarketplaceSale_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MarketplaceSale"
    ADD CONSTRAINT "MarketplaceSale_pkey" PRIMARY KEY (id);


--
-- Name: MemberRole MemberRole_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MemberRole"
    ADD CONSTRAINT "MemberRole_pkey" PRIMARY KEY (id);


--
-- Name: MessageAnalytics MessageAnalytics_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MessageAnalytics"
    ADD CONSTRAINT "MessageAnalytics_pkey" PRIMARY KEY (id);


--
-- Name: MessageAttachment MessageAttachment_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MessageAttachment"
    ADD CONSTRAINT "MessageAttachment_pkey" PRIMARY KEY (id);


--
-- Name: MessageEmbed MessageEmbed_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MessageEmbed"
    ADD CONSTRAINT "MessageEmbed_pkey" PRIMARY KEY (id);


--
-- Name: MessageReference MessageReference_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MessageReference"
    ADD CONSTRAINT "MessageReference_pkey" PRIMARY KEY (id);


--
-- Name: Message Message_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_pkey" PRIMARY KEY (id);


--
-- Name: Moderator Moderator_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Moderator"
    ADD CONSTRAINT "Moderator_pkey" PRIMARY KEY (id);


--
-- Name: Mute Mute_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Mute"
    ADD CONSTRAINT "Mute_pkey" PRIMARY KEY (id);


--
-- Name: NFTCollection NFTCollection_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."NFTCollection"
    ADD CONSTRAINT "NFTCollection_pkey" PRIMARY KEY (id);


--
-- Name: NFTRequirement NFTRequirement_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."NFTRequirement"
    ADD CONSTRAINT "NFTRequirement_pkey" PRIMARY KEY (id);


--
-- Name: NFT NFT_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."NFT"
    ADD CONSTRAINT "NFT_pkey" PRIMARY KEY (id);


--
-- Name: NotificationPreferences NotificationPreferences_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."NotificationPreferences"
    ADD CONSTRAINT "NotificationPreferences_pkey" PRIMARY KEY (id);


--
-- Name: NotificationQueue NotificationQueue_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."NotificationQueue"
    ADD CONSTRAINT "NotificationQueue_pkey" PRIMARY KEY (id);


--
-- Name: NotificationTemplate NotificationTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."NotificationTemplate"
    ADD CONSTRAINT "NotificationTemplate_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: PollOption PollOption_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."PollOption"
    ADD CONSTRAINT "PollOption_pkey" PRIMARY KEY (id);


--
-- Name: PollVote PollVote_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."PollVote"
    ADD CONSTRAINT "PollVote_pkey" PRIMARY KEY (id);


--
-- Name: Poll Poll_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Poll"
    ADD CONSTRAINT "Poll_pkey" PRIMARY KEY (id);


--
-- Name: PostMedia PostMedia_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."PostMedia"
    ADD CONSTRAINT "PostMedia_pkey" PRIMARY KEY (id);


--
-- Name: Post Post_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Post"
    ADD CONSTRAINT "Post_pkey" PRIMARY KEY (id);


--
-- Name: PushDevice PushDevice_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."PushDevice"
    ADD CONSTRAINT "PushDevice_pkey" PRIMARY KEY (id);


--
-- Name: PushNotificationDelivery PushNotificationDelivery_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."PushNotificationDelivery"
    ADD CONSTRAINT "PushNotificationDelivery_pkey" PRIMARY KEY (id);


--
-- Name: Reaction Reaction_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Reaction"
    ADD CONSTRAINT "Reaction_pkey" PRIMARY KEY (id);


--
-- Name: Report Report_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_pkey" PRIMARY KEY (id);


--
-- Name: Repost Repost_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Repost"
    ADD CONSTRAINT "Repost_pkey" PRIMARY KEY (id);


--
-- Name: Role Role_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_pkey" PRIMARY KEY (id);


--
-- Name: SavedPost SavedPost_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."SavedPost"
    ADD CONSTRAINT "SavedPost_pkey" PRIMARY KEY (id);


--
-- Name: SecurityLog SecurityLog_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."SecurityLog"
    ADD CONSTRAINT "SecurityLog_pkey" PRIMARY KEY (id);


--
-- Name: ServerAnalytics ServerAnalytics_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."ServerAnalytics"
    ADD CONSTRAINT "ServerAnalytics_pkey" PRIMARY KEY (id);


--
-- Name: ServerEmoji ServerEmoji_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."ServerEmoji"
    ADD CONSTRAINT "ServerEmoji_pkey" PRIMARY KEY (id);


--
-- Name: ServerMember ServerMember_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."ServerMember"
    ADD CONSTRAINT "ServerMember_pkey" PRIMARY KEY (id);


--
-- Name: ServerSticker ServerSticker_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."ServerSticker"
    ADD CONSTRAINT "ServerSticker_pkey" PRIMARY KEY (id);


--
-- Name: Server Server_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Server"
    ADD CONSTRAINT "Server_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: StakingPool StakingPool_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."StakingPool"
    ADD CONSTRAINT "StakingPool_pkey" PRIMARY KEY (id);


--
-- Name: StakingReward StakingReward_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."StakingReward"
    ADD CONSTRAINT "StakingReward_pkey" PRIMARY KEY (id);


--
-- Name: Thread Thread_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Thread"
    ADD CONSTRAINT "Thread_pkey" PRIMARY KEY (id);


--
-- Name: TokenGatingRule TokenGatingRule_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."TokenGatingRule"
    ADD CONSTRAINT "TokenGatingRule_pkey" PRIMARY KEY (id);


--
-- Name: TokenRequirement TokenRequirement_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."TokenRequirement"
    ADD CONSTRAINT "TokenRequirement_pkey" PRIMARY KEY (id);


--
-- Name: Token Token_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Token"
    ADD CONSTRAINT "Token_pkey" PRIMARY KEY (id);


--
-- Name: TranscodingJob TranscodingJob_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."TranscodingJob"
    ADD CONSTRAINT "TranscodingJob_pkey" PRIMARY KEY (id);


--
-- Name: UploadChunk UploadChunk_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UploadChunk"
    ADD CONSTRAINT "UploadChunk_pkey" PRIMARY KEY (id);


--
-- Name: UploadedFile UploadedFile_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UploadedFile"
    ADD CONSTRAINT "UploadedFile_pkey" PRIMARY KEY (id);


--
-- Name: UserActivity UserActivity_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UserActivity"
    ADD CONSTRAINT "UserActivity_pkey" PRIMARY KEY (id);


--
-- Name: UserBadge UserBadge_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UserBadge"
    ADD CONSTRAINT "UserBadge_pkey" PRIMARY KEY (id);


--
-- Name: UserNFT UserNFT_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UserNFT"
    ADD CONSTRAINT "UserNFT_pkey" PRIMARY KEY (id);


--
-- Name: UserPresence UserPresence_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UserPresence"
    ADD CONSTRAINT "UserPresence_pkey" PRIMARY KEY (id);


--
-- Name: UserProfilePicture UserProfilePicture_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UserProfilePicture"
    ADD CONSTRAINT "UserProfilePicture_pkey" PRIMARY KEY (id);


--
-- Name: UserStake UserStake_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UserStake"
    ADD CONSTRAINT "UserStake_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: VoiceAnalytics VoiceAnalytics_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."VoiceAnalytics"
    ADD CONSTRAINT "VoiceAnalytics_pkey" PRIMARY KEY (id);


--
-- Name: VoiceState VoiceState_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."VoiceState"
    ADD CONSTRAINT "VoiceState_pkey" PRIMARY KEY (id);


--
-- Name: Vote Vote_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Vote"
    ADD CONSTRAINT "Vote_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: brad_waitlist brad_waitlist_email_key; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public.brad_waitlist
    ADD CONSTRAINT brad_waitlist_email_key UNIQUE (email);


--
-- Name: brad_waitlist brad_waitlist_pkey; Type: CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public.brad_waitlist
    ADD CONSTRAINT brad_waitlist_pkey PRIMARY KEY (id);


--
-- Name: AuditLog_actionType_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "AuditLog_actionType_idx" ON public."AuditLog" USING btree ("actionType");


--
-- Name: AuditLog_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "AuditLog_createdAt_idx" ON public."AuditLog" USING btree ("createdAt");


--
-- Name: AuditLog_serverId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "AuditLog_serverId_idx" ON public."AuditLog" USING btree ("serverId");


--
-- Name: Award_commentId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Award_commentId_idx" ON public."Award" USING btree ("commentId");


--
-- Name: Award_giverId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Award_giverId_idx" ON public."Award" USING btree ("giverId");


--
-- Name: Award_postId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Award_postId_idx" ON public."Award" USING btree ("postId");


--
-- Name: Award_receiverId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Award_receiverId_idx" ON public."Award" USING btree ("receiverId");


--
-- Name: Ban_serverId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Ban_serverId_idx" ON public."Ban" USING btree ("serverId");


--
-- Name: Ban_serverId_userId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "Ban_serverId_userId_key" ON public."Ban" USING btree ("serverId", "userId");


--
-- Name: Block_blockedId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Block_blockedId_idx" ON public."Block" USING btree ("blockedId");


--
-- Name: Block_blockerId_blockedId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "Block_blockerId_blockedId_key" ON public."Block" USING btree ("blockerId", "blockedId");


--
-- Name: Block_blockerId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Block_blockerId_idx" ON public."Block" USING btree ("blockerId");


--
-- Name: Bookmark_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Bookmark_createdAt_idx" ON public."Bookmark" USING btree ("createdAt");


--
-- Name: Bookmark_postId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Bookmark_postId_idx" ON public."Bookmark" USING btree ("postId");


--
-- Name: Bookmark_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Bookmark_userId_idx" ON public."Bookmark" USING btree ("userId");


--
-- Name: Bookmark_userId_postId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "Bookmark_userId_postId_key" ON public."Bookmark" USING btree ("userId", "postId");


--
-- Name: ChannelPermission_channelId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "ChannelPermission_channelId_idx" ON public."ChannelPermission" USING btree ("channelId");


--
-- Name: ChannelPermission_roleId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "ChannelPermission_roleId_idx" ON public."ChannelPermission" USING btree ("roleId");


--
-- Name: Channel_isPrivate_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Channel_isPrivate_idx" ON public."Channel" USING btree ("isPrivate");


--
-- Name: Channel_name_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Channel_name_idx" ON public."Channel" USING btree (name);


--
-- Name: Channel_parentId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Channel_parentId_idx" ON public."Channel" USING btree ("parentId");


--
-- Name: Channel_parentId_position_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Channel_parentId_position_idx" ON public."Channel" USING btree ("parentId", "position");


--
-- Name: Channel_serverId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Channel_serverId_idx" ON public."Channel" USING btree ("serverId");


--
-- Name: Channel_serverId_type_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Channel_serverId_type_idx" ON public."Channel" USING btree ("serverId", type);


--
-- Name: Channel_type_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Channel_type_idx" ON public."Channel" USING btree (type);


--
-- Name: ChunkedUploadSession_expiresAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "ChunkedUploadSession_expiresAt_idx" ON public."ChunkedUploadSession" USING btree ("expiresAt");


--
-- Name: ChunkedUploadSession_lastActivity_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "ChunkedUploadSession_lastActivity_idx" ON public."ChunkedUploadSession" USING btree ("lastActivity");


--
-- Name: ChunkedUploadSession_status_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "ChunkedUploadSession_status_idx" ON public."ChunkedUploadSession" USING btree (status);


--
-- Name: ChunkedUploadSession_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "ChunkedUploadSession_userId_idx" ON public."ChunkedUploadSession" USING btree ("userId");


--
-- Name: Comment_postId_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Comment_postId_createdAt_idx" ON public."Comment" USING btree ("postId", "createdAt");


--
-- Name: Comment_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Comment_userId_idx" ON public."Comment" USING btree ("userId");


--
-- Name: CommunityBadge_collectionId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "CommunityBadge_collectionId_idx" ON public."CommunityBadge" USING btree ("collectionId");


--
-- Name: CommunityBadge_communityId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "CommunityBadge_communityId_idx" ON public."CommunityBadge" USING btree ("communityId");


--
-- Name: CommunityBadge_isActive_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "CommunityBadge_isActive_idx" ON public."CommunityBadge" USING btree ("isActive");


--
-- Name: CommunityBadge_serverId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "CommunityBadge_serverId_idx" ON public."CommunityBadge" USING btree ("serverId");


--
-- Name: CommunityMember_communityId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "CommunityMember_communityId_idx" ON public."CommunityMember" USING btree ("communityId");


--
-- Name: CommunityMember_communityId_userId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "CommunityMember_communityId_userId_key" ON public."CommunityMember" USING btree ("communityId", "userId");


--
-- Name: CommunityMember_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "CommunityMember_userId_idx" ON public."CommunityMember" USING btree ("userId");


--
-- Name: Community_name_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Community_name_idx" ON public."Community" USING btree (name);


--
-- Name: Community_name_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "Community_name_key" ON public."Community" USING btree (name);


--
-- Name: CryptoPayment_externalId_provider_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "CryptoPayment_externalId_provider_key" ON public."CryptoPayment" USING btree ("externalId", provider);


--
-- Name: CryptoPayment_provider_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "CryptoPayment_provider_idx" ON public."CryptoPayment" USING btree (provider);


--
-- Name: CryptoPayment_status_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "CryptoPayment_status_idx" ON public."CryptoPayment" USING btree (status);


--
-- Name: CryptoPayment_txHash_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "CryptoPayment_txHash_idx" ON public."CryptoPayment" USING btree ("txHash");


--
-- Name: CryptoPayment_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "CryptoPayment_userId_idx" ON public."CryptoPayment" USING btree ("userId");


--
-- Name: CryptoTip_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "CryptoTip_createdAt_idx" ON public."CryptoTip" USING btree ("createdAt");


--
-- Name: CryptoTip_recipientId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "CryptoTip_recipientId_idx" ON public."CryptoTip" USING btree ("recipientId");


--
-- Name: CryptoTip_senderId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "CryptoTip_senderId_idx" ON public."CryptoTip" USING btree ("senderId");


--
-- Name: CryptoTip_status_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "CryptoTip_status_idx" ON public."CryptoTip" USING btree (status);


--
-- Name: DirectMessageParticipant_channelId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "DirectMessageParticipant_channelId_idx" ON public."DirectMessageParticipant" USING btree ("channelId");


--
-- Name: DirectMessageParticipant_channelId_userId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "DirectMessageParticipant_channelId_userId_key" ON public."DirectMessageParticipant" USING btree ("channelId", "userId");


--
-- Name: DirectMessageParticipant_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "DirectMessageParticipant_userId_idx" ON public."DirectMessageParticipant" USING btree ("userId");


--
-- Name: FileAccessLog_accessedAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "FileAccessLog_accessedAt_idx" ON public."FileAccessLog" USING btree ("accessedAt");


--
-- Name: FileAccessLog_fileId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "FileAccessLog_fileId_idx" ON public."FileAccessLog" USING btree ("fileId");


--
-- Name: FileAccessLog_ipAddress_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "FileAccessLog_ipAddress_idx" ON public."FileAccessLog" USING btree ("ipAddress");


--
-- Name: FileAccessLog_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "FileAccessLog_userId_idx" ON public."FileAccessLog" USING btree ("userId");


--
-- Name: FileAnalytics_downloadCount_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "FileAnalytics_downloadCount_idx" ON public."FileAnalytics" USING btree ("downloadCount");


--
-- Name: FileAnalytics_fileId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "FileAnalytics_fileId_key" ON public."FileAnalytics" USING btree ("fileId");


--
-- Name: FileAnalytics_viewCount_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "FileAnalytics_viewCount_idx" ON public."FileAnalytics" USING btree ("viewCount");


--
-- Name: FilePermission_fileId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "FilePermission_fileId_key" ON public."FilePermission" USING btree ("fileId");


--
-- Name: FilePermission_isPublic_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "FilePermission_isPublic_idx" ON public."FilePermission" USING btree ("isPublic");


--
-- Name: FileVariant_fileId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "FileVariant_fileId_idx" ON public."FileVariant" USING btree ("fileId");


--
-- Name: FileVariant_type_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "FileVariant_type_idx" ON public."FileVariant" USING btree (type);


--
-- Name: Flair_communityId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Flair_communityId_idx" ON public."Flair" USING btree ("communityId");


--
-- Name: Follow_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Follow_createdAt_idx" ON public."Follow" USING btree ("createdAt");


--
-- Name: Follow_followerId_followingId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "Follow_followerId_followingId_key" ON public."Follow" USING btree ("followerId", "followingId");


--
-- Name: Follow_followerId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Follow_followerId_idx" ON public."Follow" USING btree ("followerId");


--
-- Name: Follow_followingId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Follow_followingId_idx" ON public."Follow" USING btree ("followingId");


--
-- Name: Friendship_initiatorId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Friendship_initiatorId_idx" ON public."Friendship" USING btree ("initiatorId");


--
-- Name: Friendship_initiatorId_receiverId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "Friendship_initiatorId_receiverId_key" ON public."Friendship" USING btree ("initiatorId", "receiverId");


--
-- Name: Friendship_receiverId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Friendship_receiverId_idx" ON public."Friendship" USING btree ("receiverId");


--
-- Name: Friendship_status_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Friendship_status_idx" ON public."Friendship" USING btree (status);


--
-- Name: GovernanceProposal_category_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "GovernanceProposal_category_idx" ON public."GovernanceProposal" USING btree (category);


--
-- Name: GovernanceProposal_proposerId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "GovernanceProposal_proposerId_idx" ON public."GovernanceProposal" USING btree ("proposerId");


--
-- Name: GovernanceProposal_status_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "GovernanceProposal_status_idx" ON public."GovernanceProposal" USING btree (status);


--
-- Name: GovernanceProposal_votingEndTime_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "GovernanceProposal_votingEndTime_idx" ON public."GovernanceProposal" USING btree ("votingEndTime");


--
-- Name: GovernanceProposal_votingStartTime_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "GovernanceProposal_votingStartTime_idx" ON public."GovernanceProposal" USING btree ("votingStartTime");


--
-- Name: GovernanceVote_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "GovernanceVote_createdAt_idx" ON public."GovernanceVote" USING btree ("createdAt");


--
-- Name: GovernanceVote_proposalId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "GovernanceVote_proposalId_idx" ON public."GovernanceVote" USING btree ("proposalId");


--
-- Name: GovernanceVote_proposalId_voterId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "GovernanceVote_proposalId_voterId_key" ON public."GovernanceVote" USING btree ("proposalId", "voterId");


--
-- Name: GovernanceVote_voteType_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "GovernanceVote_voteType_idx" ON public."GovernanceVote" USING btree ("voteType");


--
-- Name: GovernanceVote_voterId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "GovernanceVote_voterId_idx" ON public."GovernanceVote" USING btree ("voterId");


--
-- Name: HiddenWord_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "HiddenWord_userId_idx" ON public."HiddenWord" USING btree ("userId");


--
-- Name: Invite_code_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Invite_code_idx" ON public."Invite" USING btree (code);


--
-- Name: Invite_code_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "Invite_code_key" ON public."Invite" USING btree (code);


--
-- Name: Invite_serverId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Invite_serverId_idx" ON public."Invite" USING btree ("serverId");


--
-- Name: Like_commentId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Like_commentId_idx" ON public."Like" USING btree ("commentId");


--
-- Name: Like_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Like_createdAt_idx" ON public."Like" USING btree ("createdAt");


--
-- Name: Like_postId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Like_postId_idx" ON public."Like" USING btree ("postId");


--
-- Name: Like_userId_commentId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "Like_userId_commentId_key" ON public."Like" USING btree ("userId", "commentId");


--
-- Name: Like_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Like_userId_idx" ON public."Like" USING btree ("userId");


--
-- Name: Like_userId_postId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "Like_userId_postId_key" ON public."Like" USING btree ("userId", "postId");


--
-- Name: MarketplaceBid_amount_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MarketplaceBid_amount_idx" ON public."MarketplaceBid" USING btree (amount);


--
-- Name: MarketplaceBid_bidderId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MarketplaceBid_bidderId_idx" ON public."MarketplaceBid" USING btree ("bidderId");


--
-- Name: MarketplaceBid_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MarketplaceBid_createdAt_idx" ON public."MarketplaceBid" USING btree ("createdAt");


--
-- Name: MarketplaceBid_listingId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MarketplaceBid_listingId_idx" ON public."MarketplaceBid" USING btree ("listingId");


--
-- Name: MarketplaceBid_status_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MarketplaceBid_status_idx" ON public."MarketplaceBid" USING btree (status);


--
-- Name: MarketplaceListing_collectionId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MarketplaceListing_collectionId_idx" ON public."MarketplaceListing" USING btree ("collectionId");


--
-- Name: MarketplaceListing_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MarketplaceListing_createdAt_idx" ON public."MarketplaceListing" USING btree ("createdAt");


--
-- Name: MarketplaceListing_listingType_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MarketplaceListing_listingType_idx" ON public."MarketplaceListing" USING btree ("listingType");


--
-- Name: MarketplaceListing_nftId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MarketplaceListing_nftId_idx" ON public."MarketplaceListing" USING btree ("nftId");


--
-- Name: MarketplaceListing_price_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MarketplaceListing_price_idx" ON public."MarketplaceListing" USING btree (price);


--
-- Name: MarketplaceListing_sellerId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MarketplaceListing_sellerId_idx" ON public."MarketplaceListing" USING btree ("sellerId");


--
-- Name: MarketplaceListing_status_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MarketplaceListing_status_idx" ON public."MarketplaceListing" USING btree (status);


--
-- Name: MarketplaceSale_buyerId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MarketplaceSale_buyerId_idx" ON public."MarketplaceSale" USING btree ("buyerId");


--
-- Name: MarketplaceSale_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MarketplaceSale_createdAt_idx" ON public."MarketplaceSale" USING btree ("createdAt");


--
-- Name: MarketplaceSale_sellerId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MarketplaceSale_sellerId_idx" ON public."MarketplaceSale" USING btree ("sellerId");


--
-- Name: MarketplaceSale_status_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MarketplaceSale_status_idx" ON public."MarketplaceSale" USING btree (status);


--
-- Name: MarketplaceSale_txHash_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MarketplaceSale_txHash_idx" ON public."MarketplaceSale" USING btree ("txHash");


--
-- Name: MemberRole_roleId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MemberRole_roleId_idx" ON public."MemberRole" USING btree ("roleId");


--
-- Name: MemberRole_serverId_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MemberRole_serverId_userId_idx" ON public."MemberRole" USING btree ("serverId", "userId");


--
-- Name: MemberRole_serverId_userId_roleId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "MemberRole_serverId_userId_roleId_key" ON public."MemberRole" USING btree ("serverId", "userId", "roleId");


--
-- Name: MessageAnalytics_channelId_timestamp_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MessageAnalytics_channelId_timestamp_idx" ON public."MessageAnalytics" USING btree ("channelId", "timestamp");


--
-- Name: MessageAnalytics_serverId_timestamp_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MessageAnalytics_serverId_timestamp_idx" ON public."MessageAnalytics" USING btree ("serverId", "timestamp");


--
-- Name: MessageAnalytics_timestamp_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MessageAnalytics_timestamp_idx" ON public."MessageAnalytics" USING btree ("timestamp");


--
-- Name: MessageAnalytics_userId_timestamp_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MessageAnalytics_userId_timestamp_idx" ON public."MessageAnalytics" USING btree ("userId", "timestamp");


--
-- Name: MessageAttachment_messageId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MessageAttachment_messageId_idx" ON public."MessageAttachment" USING btree ("messageId");


--
-- Name: MessageEmbed_messageId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MessageEmbed_messageId_idx" ON public."MessageEmbed" USING btree ("messageId");


--
-- Name: MessageReference_messageId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MessageReference_messageId_idx" ON public."MessageReference" USING btree ("messageId");


--
-- Name: MessageReference_referencedMessageId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "MessageReference_referencedMessageId_idx" ON public."MessageReference" USING btree ("referencedMessageId");


--
-- Name: Message_channelId_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Message_channelId_createdAt_idx" ON public."Message" USING btree ("channelId", "createdAt");


--
-- Name: Message_channelId_timestamp_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Message_channelId_timestamp_idx" ON public."Message" USING btree ("channelId", "timestamp");


--
-- Name: Message_editedTimestamp_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Message_editedTimestamp_idx" ON public."Message" USING btree ("editedTimestamp");


--
-- Name: Message_replyToId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Message_replyToId_idx" ON public."Message" USING btree ("replyToId");


--
-- Name: Message_threadId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Message_threadId_idx" ON public."Message" USING btree ("threadId");


--
-- Name: Message_timestamp_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Message_timestamp_idx" ON public."Message" USING btree ("timestamp");


--
-- Name: Message_type_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Message_type_idx" ON public."Message" USING btree (type);


--
-- Name: Message_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Message_userId_idx" ON public."Message" USING btree ("userId");


--
-- Name: Message_userId_timestamp_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Message_userId_timestamp_idx" ON public."Message" USING btree ("userId", "timestamp");


--
-- Name: Moderator_communityId_userId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "Moderator_communityId_userId_key" ON public."Moderator" USING btree ("communityId", "userId");


--
-- Name: Mute_mutedId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Mute_mutedId_idx" ON public."Mute" USING btree ("mutedId");


--
-- Name: Mute_muterId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Mute_muterId_idx" ON public."Mute" USING btree ("muterId");


--
-- Name: Mute_muterId_mutedId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "Mute_muterId_mutedId_key" ON public."Mute" USING btree ("muterId", "mutedId");


--
-- Name: NFTCollection_chain_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "NFTCollection_chain_idx" ON public."NFTCollection" USING btree (chain);


--
-- Name: NFTCollection_contractAddress_chain_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "NFTCollection_contractAddress_chain_key" ON public."NFTCollection" USING btree ("contractAddress", chain);


--
-- Name: NFTCollection_contractAddress_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "NFTCollection_contractAddress_idx" ON public."NFTCollection" USING btree ("contractAddress");


--
-- Name: NFTCollection_verified_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "NFTCollection_verified_idx" ON public."NFTCollection" USING btree (verified);


--
-- Name: NFTRequirement_collectionId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "NFTRequirement_collectionId_idx" ON public."NFTRequirement" USING btree ("collectionId");


--
-- Name: NFTRequirement_ruleId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "NFTRequirement_ruleId_idx" ON public."NFTRequirement" USING btree ("ruleId");


--
-- Name: NFT_collectionId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "NFT_collectionId_idx" ON public."NFT" USING btree ("collectionId");


--
-- Name: NFT_collectionId_tokenId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "NFT_collectionId_tokenId_key" ON public."NFT" USING btree ("collectionId", "tokenId");


--
-- Name: NFT_ownerAddress_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "NFT_ownerAddress_idx" ON public."NFT" USING btree ("ownerAddress");


--
-- Name: NFT_rarity_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "NFT_rarity_idx" ON public."NFT" USING btree (rarity);


--
-- Name: NotificationPreferences_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "NotificationPreferences_userId_idx" ON public."NotificationPreferences" USING btree ("userId");


--
-- Name: NotificationPreferences_userId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "NotificationPreferences_userId_key" ON public."NotificationPreferences" USING btree ("userId");


--
-- Name: NotificationQueue_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "NotificationQueue_createdAt_idx" ON public."NotificationQueue" USING btree ("createdAt");


--
-- Name: NotificationQueue_priority_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "NotificationQueue_priority_idx" ON public."NotificationQueue" USING btree (priority);


--
-- Name: NotificationQueue_scheduledAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "NotificationQueue_scheduledAt_idx" ON public."NotificationQueue" USING btree ("scheduledAt");


--
-- Name: NotificationQueue_status_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "NotificationQueue_status_idx" ON public."NotificationQueue" USING btree (status);


--
-- Name: NotificationQueue_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "NotificationQueue_userId_idx" ON public."NotificationQueue" USING btree ("userId");


--
-- Name: NotificationTemplate_isActive_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "NotificationTemplate_isActive_idx" ON public."NotificationTemplate" USING btree ("isActive");


--
-- Name: NotificationTemplate_type_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "NotificationTemplate_type_idx" ON public."NotificationTemplate" USING btree (type);


--
-- Name: NotificationTemplate_type_name_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "NotificationTemplate_type_name_key" ON public."NotificationTemplate" USING btree (type, name);


--
-- Name: Notification_userId_isRead_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Notification_userId_isRead_idx" ON public."Notification" USING btree ("userId", "isRead");


--
-- Name: PollOption_pollId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "PollOption_pollId_idx" ON public."PollOption" USING btree ("pollId");


--
-- Name: PollVote_optionId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "PollVote_optionId_idx" ON public."PollVote" USING btree ("optionId");


--
-- Name: PollVote_pollId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "PollVote_pollId_idx" ON public."PollVote" USING btree ("pollId");


--
-- Name: PollVote_pollId_userId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "PollVote_pollId_userId_key" ON public."PollVote" USING btree ("pollId", "userId");


--
-- Name: PollVote_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "PollVote_userId_idx" ON public."PollVote" USING btree ("userId");


--
-- Name: Poll_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Poll_createdAt_idx" ON public."Poll" USING btree ("createdAt");


--
-- Name: Poll_endsAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Poll_endsAt_idx" ON public."Poll" USING btree ("endsAt");


--
-- Name: Poll_postId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "Poll_postId_key" ON public."Poll" USING btree ("postId");


--
-- Name: PostMedia_postId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "PostMedia_postId_idx" ON public."PostMedia" USING btree ("postId");


--
-- Name: PostMedia_type_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "PostMedia_type_idx" ON public."PostMedia" USING btree (type);


--
-- Name: Post_communityId_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Post_communityId_createdAt_idx" ON public."Post" USING btree ("communityId", "createdAt");


--
-- Name: Post_score_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Post_score_idx" ON public."Post" USING btree (score);


--
-- Name: Post_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Post_userId_idx" ON public."Post" USING btree ("userId");


--
-- Name: PushDevice_deviceToken_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "PushDevice_deviceToken_idx" ON public."PushDevice" USING btree ("deviceToken");


--
-- Name: PushDevice_deviceToken_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "PushDevice_deviceToken_key" ON public."PushDevice" USING btree ("deviceToken");


--
-- Name: PushDevice_isActive_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "PushDevice_isActive_idx" ON public."PushDevice" USING btree ("isActive");


--
-- Name: PushDevice_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "PushDevice_userId_idx" ON public."PushDevice" USING btree ("userId");


--
-- Name: PushNotificationDelivery_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "PushNotificationDelivery_createdAt_idx" ON public."PushNotificationDelivery" USING btree ("createdAt");


--
-- Name: PushNotificationDelivery_deviceId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "PushNotificationDelivery_deviceId_idx" ON public."PushNotificationDelivery" USING btree ("deviceId");


--
-- Name: PushNotificationDelivery_provider_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "PushNotificationDelivery_provider_idx" ON public."PushNotificationDelivery" USING btree (provider);


--
-- Name: PushNotificationDelivery_status_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "PushNotificationDelivery_status_idx" ON public."PushNotificationDelivery" USING btree (status);


--
-- Name: PushNotificationDelivery_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "PushNotificationDelivery_userId_idx" ON public."PushNotificationDelivery" USING btree ("userId");


--
-- Name: Reaction_messageId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Reaction_messageId_idx" ON public."Reaction" USING btree ("messageId");


--
-- Name: Reaction_messageId_userId_emoji_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "Reaction_messageId_userId_emoji_key" ON public."Reaction" USING btree ("messageId", "userId", emoji);


--
-- Name: Report_commentId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Report_commentId_idx" ON public."Report" USING btree ("commentId");


--
-- Name: Report_postId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Report_postId_idx" ON public."Report" USING btree ("postId");


--
-- Name: Report_reporterId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Report_reporterId_idx" ON public."Report" USING btree ("reporterId");


--
-- Name: Report_status_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Report_status_idx" ON public."Report" USING btree (status);


--
-- Name: Repost_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Repost_createdAt_idx" ON public."Repost" USING btree ("createdAt");


--
-- Name: Repost_postId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Repost_postId_idx" ON public."Repost" USING btree ("postId");


--
-- Name: Repost_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Repost_userId_idx" ON public."Repost" USING btree ("userId");


--
-- Name: Repost_userId_postId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "Repost_userId_postId_key" ON public."Repost" USING btree ("userId", "postId");


--
-- Name: Role_serverId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Role_serverId_idx" ON public."Role" USING btree ("serverId");


--
-- Name: Role_serverId_name_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "Role_serverId_name_key" ON public."Role" USING btree ("serverId", name);


--
-- Name: SavedPost_postId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "SavedPost_postId_idx" ON public."SavedPost" USING btree ("postId");


--
-- Name: SavedPost_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "SavedPost_userId_idx" ON public."SavedPost" USING btree ("userId");


--
-- Name: SavedPost_userId_postId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "SavedPost_userId_postId_key" ON public."SavedPost" USING btree ("userId", "postId");


--
-- Name: SecurityLog_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "SecurityLog_createdAt_idx" ON public."SecurityLog" USING btree ("createdAt");


--
-- Name: SecurityLog_ipAddress_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "SecurityLog_ipAddress_idx" ON public."SecurityLog" USING btree ("ipAddress");


--
-- Name: SecurityLog_riskScore_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "SecurityLog_riskScore_idx" ON public."SecurityLog" USING btree ("riskScore");


--
-- Name: SecurityLog_type_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "SecurityLog_type_idx" ON public."SecurityLog" USING btree (type);


--
-- Name: SecurityLog_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "SecurityLog_userId_idx" ON public."SecurityLog" USING btree ("userId");


--
-- Name: ServerAnalytics_serverId_timestamp_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "ServerAnalytics_serverId_timestamp_idx" ON public."ServerAnalytics" USING btree ("serverId", "timestamp");


--
-- Name: ServerAnalytics_timestamp_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "ServerAnalytics_timestamp_idx" ON public."ServerAnalytics" USING btree ("timestamp");


--
-- Name: ServerEmoji_serverId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "ServerEmoji_serverId_idx" ON public."ServerEmoji" USING btree ("serverId");


--
-- Name: ServerEmoji_serverId_name_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "ServerEmoji_serverId_name_key" ON public."ServerEmoji" USING btree ("serverId", name);


--
-- Name: ServerMember_joinedAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "ServerMember_joinedAt_idx" ON public."ServerMember" USING btree ("joinedAt");


--
-- Name: ServerMember_serverId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "ServerMember_serverId_idx" ON public."ServerMember" USING btree ("serverId");


--
-- Name: ServerMember_serverId_userId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "ServerMember_serverId_userId_key" ON public."ServerMember" USING btree ("serverId", "userId");


--
-- Name: ServerMember_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "ServerMember_userId_idx" ON public."ServerMember" USING btree ("userId");


--
-- Name: ServerSticker_serverId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "ServerSticker_serverId_idx" ON public."ServerSticker" USING btree ("serverId");


--
-- Name: ServerSticker_type_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "ServerSticker_type_idx" ON public."ServerSticker" USING btree (type);


--
-- Name: Server_approximateMemberCount_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Server_approximateMemberCount_idx" ON public."Server" USING btree ("approximateMemberCount");


--
-- Name: Server_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Server_createdAt_idx" ON public."Server" USING btree ("createdAt");


--
-- Name: Server_isPublic_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Server_isPublic_idx" ON public."Server" USING btree ("isPublic");


--
-- Name: Server_name_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Server_name_idx" ON public."Server" USING btree (name);


--
-- Name: Server_ownerId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Server_ownerId_idx" ON public."Server" USING btree ("ownerId");


--
-- Name: Server_tokenGated_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Server_tokenGated_idx" ON public."Server" USING btree ("tokenGated");


--
-- Name: Server_vanityUrlCode_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Server_vanityUrlCode_idx" ON public."Server" USING btree ("vanityUrlCode");


--
-- Name: Session_expiresAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Session_expiresAt_idx" ON public."Session" USING btree ("expiresAt");


--
-- Name: Session_refreshToken_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Session_refreshToken_idx" ON public."Session" USING btree ("refreshToken");


--
-- Name: Session_refreshToken_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "Session_refreshToken_key" ON public."Session" USING btree ("refreshToken");


--
-- Name: Session_token_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Session_token_idx" ON public."Session" USING btree (token);


--
-- Name: Session_token_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "Session_token_key" ON public."Session" USING btree (token);


--
-- Name: Session_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Session_userId_idx" ON public."Session" USING btree ("userId");


--
-- Name: StakingPool_apr_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "StakingPool_apr_idx" ON public."StakingPool" USING btree (apr);


--
-- Name: StakingPool_chain_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "StakingPool_chain_idx" ON public."StakingPool" USING btree (chain);


--
-- Name: StakingPool_isActive_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "StakingPool_isActive_idx" ON public."StakingPool" USING btree ("isActive");


--
-- Name: StakingPool_tokenAddress_chain_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "StakingPool_tokenAddress_chain_key" ON public."StakingPool" USING btree ("tokenAddress", chain);


--
-- Name: StakingPool_tokenAddress_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "StakingPool_tokenAddress_idx" ON public."StakingPool" USING btree ("tokenAddress");


--
-- Name: StakingReward_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "StakingReward_createdAt_idx" ON public."StakingReward" USING btree ("createdAt");


--
-- Name: StakingReward_poolId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "StakingReward_poolId_idx" ON public."StakingReward" USING btree ("poolId");


--
-- Name: StakingReward_stakeId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "StakingReward_stakeId_idx" ON public."StakingReward" USING btree ("stakeId");


--
-- Name: StakingReward_status_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "StakingReward_status_idx" ON public."StakingReward" USING btree (status);


--
-- Name: StakingReward_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "StakingReward_userId_idx" ON public."StakingReward" USING btree ("userId");


--
-- Name: Thread_channelId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Thread_channelId_idx" ON public."Thread" USING btree ("channelId");


--
-- Name: Thread_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Thread_userId_idx" ON public."Thread" USING btree ("userId");


--
-- Name: TokenGatingRule_channelId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "TokenGatingRule_channelId_idx" ON public."TokenGatingRule" USING btree ("channelId");


--
-- Name: TokenGatingRule_communityId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "TokenGatingRule_communityId_idx" ON public."TokenGatingRule" USING btree ("communityId");


--
-- Name: TokenGatingRule_isActive_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "TokenGatingRule_isActive_idx" ON public."TokenGatingRule" USING btree ("isActive");


--
-- Name: TokenGatingRule_ruleType_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "TokenGatingRule_ruleType_idx" ON public."TokenGatingRule" USING btree ("ruleType");


--
-- Name: TokenGatingRule_serverId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "TokenGatingRule_serverId_idx" ON public."TokenGatingRule" USING btree ("serverId");


--
-- Name: TokenRequirement_ruleId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "TokenRequirement_ruleId_idx" ON public."TokenRequirement" USING btree ("ruleId");


--
-- Name: TokenRequirement_tokenAddress_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "TokenRequirement_tokenAddress_idx" ON public."TokenRequirement" USING btree ("tokenAddress");


--
-- Name: Token_userId_address_chain_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "Token_userId_address_chain_key" ON public."Token" USING btree ("userId", address, chain);


--
-- Name: Token_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Token_userId_idx" ON public."Token" USING btree ("userId");


--
-- Name: TranscodingJob_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "TranscodingJob_createdAt_idx" ON public."TranscodingJob" USING btree ("createdAt");


--
-- Name: TranscodingJob_fileId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "TranscodingJob_fileId_idx" ON public."TranscodingJob" USING btree ("fileId");


--
-- Name: TranscodingJob_priority_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "TranscodingJob_priority_idx" ON public."TranscodingJob" USING btree (priority);


--
-- Name: TranscodingJob_status_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "TranscodingJob_status_idx" ON public."TranscodingJob" USING btree (status);


--
-- Name: TranscodingJob_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "TranscodingJob_userId_idx" ON public."TranscodingJob" USING btree ("userId");


--
-- Name: UploadChunk_sessionId_chunkIndex_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "UploadChunk_sessionId_chunkIndex_key" ON public."UploadChunk" USING btree ("sessionId", "chunkIndex");


--
-- Name: UploadChunk_sessionId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UploadChunk_sessionId_idx" ON public."UploadChunk" USING btree ("sessionId");


--
-- Name: UploadedFile_bucket_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UploadedFile_bucket_idx" ON public."UploadedFile" USING btree (bucket);


--
-- Name: UploadedFile_channelId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UploadedFile_channelId_idx" ON public."UploadedFile" USING btree ("channelId");


--
-- Name: UploadedFile_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UploadedFile_createdAt_idx" ON public."UploadedFile" USING btree ("createdAt");


--
-- Name: UploadedFile_expiresAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UploadedFile_expiresAt_idx" ON public."UploadedFile" USING btree ("expiresAt");


--
-- Name: UploadedFile_filename_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "UploadedFile_filename_key" ON public."UploadedFile" USING btree (filename);


--
-- Name: UploadedFile_hash_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UploadedFile_hash_idx" ON public."UploadedFile" USING btree (hash);


--
-- Name: UploadedFile_hash_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "UploadedFile_hash_key" ON public."UploadedFile" USING btree (hash);


--
-- Name: UploadedFile_messageId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UploadedFile_messageId_idx" ON public."UploadedFile" USING btree ("messageId");


--
-- Name: UploadedFile_mimeType_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UploadedFile_mimeType_idx" ON public."UploadedFile" USING btree ("mimeType");


--
-- Name: UploadedFile_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UploadedFile_userId_idx" ON public."UploadedFile" USING btree ("userId");


--
-- Name: UserActivity_type_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UserActivity_type_idx" ON public."UserActivity" USING btree (type);


--
-- Name: UserActivity_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UserActivity_userId_idx" ON public."UserActivity" USING btree ("userId");


--
-- Name: UserBadge_badgeId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UserBadge_badgeId_idx" ON public."UserBadge" USING btree ("badgeId");


--
-- Name: UserBadge_userId_badgeId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "UserBadge_userId_badgeId_key" ON public."UserBadge" USING btree ("userId", "badgeId");


--
-- Name: UserBadge_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UserBadge_userId_idx" ON public."UserBadge" USING btree ("userId");


--
-- Name: UserNFT_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UserNFT_userId_idx" ON public."UserNFT" USING btree ("userId");


--
-- Name: UserNFT_userId_nftId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "UserNFT_userId_nftId_key" ON public."UserNFT" USING btree ("userId", "nftId");


--
-- Name: UserNFT_verified_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UserNFT_verified_idx" ON public."UserNFT" USING btree (verified);


--
-- Name: UserPresence_status_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UserPresence_status_idx" ON public."UserPresence" USING btree (status);


--
-- Name: UserPresence_userId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "UserPresence_userId_key" ON public."UserPresence" USING btree ("userId");


--
-- Name: UserProfilePicture_nftId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UserProfilePicture_nftId_idx" ON public."UserProfilePicture" USING btree ("nftId");


--
-- Name: UserProfilePicture_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UserProfilePicture_userId_idx" ON public."UserProfilePicture" USING btree ("userId");


--
-- Name: UserProfilePicture_userId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "UserProfilePicture_userId_key" ON public."UserProfilePicture" USING btree ("userId");


--
-- Name: UserStake_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UserStake_createdAt_idx" ON public."UserStake" USING btree ("createdAt");


--
-- Name: UserStake_poolId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UserStake_poolId_idx" ON public."UserStake" USING btree ("poolId");


--
-- Name: UserStake_status_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UserStake_status_idx" ON public."UserStake" USING btree (status);


--
-- Name: UserStake_userId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "UserStake_userId_idx" ON public."UserStake" USING btree ("userId");


--
-- Name: User_bannedAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "User_bannedAt_idx" ON public."User" USING btree ("bannedAt");


--
-- Name: User_createdAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "User_createdAt_idx" ON public."User" USING btree ("createdAt");


--
-- Name: User_discord_id_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "User_discord_id_key" ON public."User" USING btree (discord_id);


--
-- Name: User_email_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "User_email_idx" ON public."User" USING btree (email);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_github_id_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "User_github_id_key" ON public."User" USING btree (github_id);


--
-- Name: User_google_id_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "User_google_id_key" ON public."User" USING btree (google_id);


--
-- Name: User_isVerified_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "User_isVerified_idx" ON public."User" USING btree ("isVerified");


--
-- Name: User_lastSeenAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "User_lastSeenAt_idx" ON public."User" USING btree ("lastSeenAt");


--
-- Name: User_username_discriminator_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "User_username_discriminator_key" ON public."User" USING btree (username, discriminator);


--
-- Name: User_username_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "User_username_idx" ON public."User" USING btree (username);


--
-- Name: User_username_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "User_username_key" ON public."User" USING btree (username);


--
-- Name: User_walletAddress_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "User_walletAddress_idx" ON public."User" USING btree ("walletAddress");


--
-- Name: User_walletAddress_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "User_walletAddress_key" ON public."User" USING btree ("walletAddress");


--
-- Name: VoiceAnalytics_channelId_timestamp_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "VoiceAnalytics_channelId_timestamp_idx" ON public."VoiceAnalytics" USING btree ("channelId", "timestamp");


--
-- Name: VoiceAnalytics_serverId_timestamp_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "VoiceAnalytics_serverId_timestamp_idx" ON public."VoiceAnalytics" USING btree ("serverId", "timestamp");


--
-- Name: VoiceAnalytics_timestamp_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "VoiceAnalytics_timestamp_idx" ON public."VoiceAnalytics" USING btree ("timestamp");


--
-- Name: VoiceAnalytics_userId_timestamp_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "VoiceAnalytics_userId_timestamp_idx" ON public."VoiceAnalytics" USING btree ("userId", "timestamp");


--
-- Name: VoiceState_channelId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "VoiceState_channelId_idx" ON public."VoiceState" USING btree ("channelId");


--
-- Name: VoiceState_sessionId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "VoiceState_sessionId_idx" ON public."VoiceState" USING btree ("sessionId");


--
-- Name: VoiceState_userId_serverId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "VoiceState_userId_serverId_key" ON public."VoiceState" USING btree ("userId", "serverId");


--
-- Name: Vote_commentId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Vote_commentId_idx" ON public."Vote" USING btree ("commentId");


--
-- Name: Vote_postId_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "Vote_postId_idx" ON public."Vote" USING btree ("postId");


--
-- Name: Vote_userId_commentId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "Vote_userId_commentId_key" ON public."Vote" USING btree ("userId", "commentId");


--
-- Name: Vote_userId_postId_key; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE UNIQUE INDEX "Vote_userId_postId_key" ON public."Vote" USING btree ("userId", "postId");


--
-- Name: brad_waitlist_interest_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX brad_waitlist_interest_idx ON public.brad_waitlist USING btree (interest);


--
-- Name: brad_waitlist_submittedAt_idx; Type: INDEX; Schema: public; Owner: cryb_user
--

CREATE INDEX "brad_waitlist_submittedAt_idx" ON public.brad_waitlist USING btree ("submittedAt");


--
-- Name: AuditLog AuditLog_serverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES public."Server"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Award Award_commentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Award"
    ADD CONSTRAINT "Award_commentId_fkey" FOREIGN KEY ("commentId") REFERENCES public."Comment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Award Award_giverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Award"
    ADD CONSTRAINT "Award_giverId_fkey" FOREIGN KEY ("giverId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Award Award_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Award"
    ADD CONSTRAINT "Award_postId_fkey" FOREIGN KEY ("postId") REFERENCES public."Post"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Award Award_receiverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Award"
    ADD CONSTRAINT "Award_receiverId_fkey" FOREIGN KEY ("receiverId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Ban Ban_serverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Ban"
    ADD CONSTRAINT "Ban_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES public."Server"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Block Block_blockedId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Block"
    ADD CONSTRAINT "Block_blockedId_fkey" FOREIGN KEY ("blockedId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Block Block_blockerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Block"
    ADD CONSTRAINT "Block_blockerId_fkey" FOREIGN KEY ("blockerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Bookmark Bookmark_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Bookmark"
    ADD CONSTRAINT "Bookmark_postId_fkey" FOREIGN KEY ("postId") REFERENCES public."Post"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Bookmark Bookmark_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Bookmark"
    ADD CONSTRAINT "Bookmark_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChannelPermission ChannelPermission_channelId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."ChannelPermission"
    ADD CONSTRAINT "ChannelPermission_channelId_fkey" FOREIGN KEY ("channelId") REFERENCES public."Channel"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChannelPermission ChannelPermission_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."ChannelPermission"
    ADD CONSTRAINT "ChannelPermission_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Channel Channel_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Channel"
    ADD CONSTRAINT "Channel_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."Channel"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Channel Channel_serverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Channel"
    ADD CONSTRAINT "Channel_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES public."Server"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChunkedUploadSession ChunkedUploadSession_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."ChunkedUploadSession"
    ADD CONSTRAINT "ChunkedUploadSession_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Comment Comment_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Comment"
    ADD CONSTRAINT "Comment_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."Comment"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Comment Comment_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Comment"
    ADD CONSTRAINT "Comment_postId_fkey" FOREIGN KEY ("postId") REFERENCES public."Post"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Comment Comment_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Comment"
    ADD CONSTRAINT "Comment_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CommunityBadge CommunityBadge_collectionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."CommunityBadge"
    ADD CONSTRAINT "CommunityBadge_collectionId_fkey" FOREIGN KEY ("collectionId") REFERENCES public."NFTCollection"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CommunityBadge CommunityBadge_communityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."CommunityBadge"
    ADD CONSTRAINT "CommunityBadge_communityId_fkey" FOREIGN KEY ("communityId") REFERENCES public."Community"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CommunityBadge CommunityBadge_serverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."CommunityBadge"
    ADD CONSTRAINT "CommunityBadge_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES public."Server"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CommunityMember CommunityMember_communityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."CommunityMember"
    ADD CONSTRAINT "CommunityMember_communityId_fkey" FOREIGN KEY ("communityId") REFERENCES public."Community"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CommunityMember CommunityMember_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."CommunityMember"
    ADD CONSTRAINT "CommunityMember_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CryptoPayment CryptoPayment_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."CryptoPayment"
    ADD CONSTRAINT "CryptoPayment_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CryptoTip CryptoTip_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."CryptoTip"
    ADD CONSTRAINT "CryptoTip_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public."CryptoPayment"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CryptoTip CryptoTip_recipientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."CryptoTip"
    ADD CONSTRAINT "CryptoTip_recipientId_fkey" FOREIGN KEY ("recipientId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CryptoTip CryptoTip_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."CryptoTip"
    ADD CONSTRAINT "CryptoTip_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DirectMessageParticipant DirectMessageParticipant_channelId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."DirectMessageParticipant"
    ADD CONSTRAINT "DirectMessageParticipant_channelId_fkey" FOREIGN KEY ("channelId") REFERENCES public."Channel"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DirectMessageParticipant DirectMessageParticipant_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."DirectMessageParticipant"
    ADD CONSTRAINT "DirectMessageParticipant_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: FileAccessLog FileAccessLog_fileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."FileAccessLog"
    ADD CONSTRAINT "FileAccessLog_fileId_fkey" FOREIGN KEY ("fileId") REFERENCES public."UploadedFile"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: FileAccessLog FileAccessLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."FileAccessLog"
    ADD CONSTRAINT "FileAccessLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: FileAnalytics FileAnalytics_fileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."FileAnalytics"
    ADD CONSTRAINT "FileAnalytics_fileId_fkey" FOREIGN KEY ("fileId") REFERENCES public."UploadedFile"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: FilePermission FilePermission_fileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."FilePermission"
    ADD CONSTRAINT "FilePermission_fileId_fkey" FOREIGN KEY ("fileId") REFERENCES public."UploadedFile"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: FileVariant FileVariant_fileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."FileVariant"
    ADD CONSTRAINT "FileVariant_fileId_fkey" FOREIGN KEY ("fileId") REFERENCES public."UploadedFile"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Flair Flair_communityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Flair"
    ADD CONSTRAINT "Flair_communityId_fkey" FOREIGN KEY ("communityId") REFERENCES public."Community"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Follow Follow_followerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Follow"
    ADD CONSTRAINT "Follow_followerId_fkey" FOREIGN KEY ("followerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Follow Follow_followingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Follow"
    ADD CONSTRAINT "Follow_followingId_fkey" FOREIGN KEY ("followingId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Friendship Friendship_initiatorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Friendship"
    ADD CONSTRAINT "Friendship_initiatorId_fkey" FOREIGN KEY ("initiatorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Friendship Friendship_receiverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Friendship"
    ADD CONSTRAINT "Friendship_receiverId_fkey" FOREIGN KEY ("receiverId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: GovernanceProposal GovernanceProposal_proposerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."GovernanceProposal"
    ADD CONSTRAINT "GovernanceProposal_proposerId_fkey" FOREIGN KEY ("proposerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: GovernanceVote GovernanceVote_proposalId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."GovernanceVote"
    ADD CONSTRAINT "GovernanceVote_proposalId_fkey" FOREIGN KEY ("proposalId") REFERENCES public."GovernanceProposal"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: GovernanceVote GovernanceVote_voterId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."GovernanceVote"
    ADD CONSTRAINT "GovernanceVote_voterId_fkey" FOREIGN KEY ("voterId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: HiddenWord HiddenWord_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."HiddenWord"
    ADD CONSTRAINT "HiddenWord_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Invite Invite_serverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Invite"
    ADD CONSTRAINT "Invite_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES public."Server"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Like Like_commentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Like"
    ADD CONSTRAINT "Like_commentId_fkey" FOREIGN KEY ("commentId") REFERENCES public."Comment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Like Like_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Like"
    ADD CONSTRAINT "Like_postId_fkey" FOREIGN KEY ("postId") REFERENCES public."Post"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Like Like_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Like"
    ADD CONSTRAINT "Like_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MarketplaceBid MarketplaceBid_bidderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MarketplaceBid"
    ADD CONSTRAINT "MarketplaceBid_bidderId_fkey" FOREIGN KEY ("bidderId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MarketplaceBid MarketplaceBid_listingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MarketplaceBid"
    ADD CONSTRAINT "MarketplaceBid_listingId_fkey" FOREIGN KEY ("listingId") REFERENCES public."MarketplaceListing"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MarketplaceListing MarketplaceListing_collectionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MarketplaceListing"
    ADD CONSTRAINT "MarketplaceListing_collectionId_fkey" FOREIGN KEY ("collectionId") REFERENCES public."NFTCollection"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MarketplaceListing MarketplaceListing_nftId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MarketplaceListing"
    ADD CONSTRAINT "MarketplaceListing_nftId_fkey" FOREIGN KEY ("nftId") REFERENCES public."NFT"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MarketplaceListing MarketplaceListing_sellerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MarketplaceListing"
    ADD CONSTRAINT "MarketplaceListing_sellerId_fkey" FOREIGN KEY ("sellerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MarketplaceSale MarketplaceSale_buyerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MarketplaceSale"
    ADD CONSTRAINT "MarketplaceSale_buyerId_fkey" FOREIGN KEY ("buyerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MarketplaceSale MarketplaceSale_listingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MarketplaceSale"
    ADD CONSTRAINT "MarketplaceSale_listingId_fkey" FOREIGN KEY ("listingId") REFERENCES public."MarketplaceListing"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MarketplaceSale MarketplaceSale_sellerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MarketplaceSale"
    ADD CONSTRAINT "MarketplaceSale_sellerId_fkey" FOREIGN KEY ("sellerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MemberRole MemberRole_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MemberRole"
    ADD CONSTRAINT "MemberRole_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MemberRole MemberRole_serverId_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MemberRole"
    ADD CONSTRAINT "MemberRole_serverId_userId_fkey" FOREIGN KEY ("serverId", "userId") REFERENCES public."ServerMember"("serverId", "userId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MessageAttachment MessageAttachment_messageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MessageAttachment"
    ADD CONSTRAINT "MessageAttachment_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES public."Message"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MessageEmbed MessageEmbed_messageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MessageEmbed"
    ADD CONSTRAINT "MessageEmbed_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES public."Message"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MessageReference MessageReference_messageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MessageReference"
    ADD CONSTRAINT "MessageReference_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES public."Message"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MessageReference MessageReference_referencedMessageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."MessageReference"
    ADD CONSTRAINT "MessageReference_referencedMessageId_fkey" FOREIGN KEY ("referencedMessageId") REFERENCES public."Message"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Message Message_channelId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_channelId_fkey" FOREIGN KEY ("channelId") REFERENCES public."Channel"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Message Message_replyToId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_replyToId_fkey" FOREIGN KEY ("replyToId") REFERENCES public."Message"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Message Message_threadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_threadId_fkey" FOREIGN KEY ("threadId") REFERENCES public."Thread"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Message Message_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Moderator Moderator_communityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Moderator"
    ADD CONSTRAINT "Moderator_communityId_fkey" FOREIGN KEY ("communityId") REFERENCES public."Community"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Moderator Moderator_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Moderator"
    ADD CONSTRAINT "Moderator_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Mute Mute_mutedId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Mute"
    ADD CONSTRAINT "Mute_mutedId_fkey" FOREIGN KEY ("mutedId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Mute Mute_muterId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Mute"
    ADD CONSTRAINT "Mute_muterId_fkey" FOREIGN KEY ("muterId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: NFTRequirement NFTRequirement_collectionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."NFTRequirement"
    ADD CONSTRAINT "NFTRequirement_collectionId_fkey" FOREIGN KEY ("collectionId") REFERENCES public."NFTCollection"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: NFTRequirement NFTRequirement_ruleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."NFTRequirement"
    ADD CONSTRAINT "NFTRequirement_ruleId_fkey" FOREIGN KEY ("ruleId") REFERENCES public."TokenGatingRule"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: NFT NFT_collectionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."NFT"
    ADD CONSTRAINT "NFT_collectionId_fkey" FOREIGN KEY ("collectionId") REFERENCES public."NFTCollection"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: NotificationPreferences NotificationPreferences_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."NotificationPreferences"
    ADD CONSTRAINT "NotificationPreferences_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Notification Notification_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PollOption PollOption_pollId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."PollOption"
    ADD CONSTRAINT "PollOption_pollId_fkey" FOREIGN KEY ("pollId") REFERENCES public."Poll"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PollVote PollVote_optionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."PollVote"
    ADD CONSTRAINT "PollVote_optionId_fkey" FOREIGN KEY ("optionId") REFERENCES public."PollOption"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PollVote PollVote_pollId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."PollVote"
    ADD CONSTRAINT "PollVote_pollId_fkey" FOREIGN KEY ("pollId") REFERENCES public."Poll"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PollVote PollVote_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."PollVote"
    ADD CONSTRAINT "PollVote_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Poll Poll_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Poll"
    ADD CONSTRAINT "Poll_postId_fkey" FOREIGN KEY ("postId") REFERENCES public."Post"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PostMedia PostMedia_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."PostMedia"
    ADD CONSTRAINT "PostMedia_postId_fkey" FOREIGN KEY ("postId") REFERENCES public."Post"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Post Post_communityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Post"
    ADD CONSTRAINT "Post_communityId_fkey" FOREIGN KEY ("communityId") REFERENCES public."Community"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Post Post_quotedPostId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Post"
    ADD CONSTRAINT "Post_quotedPostId_fkey" FOREIGN KEY ("quotedPostId") REFERENCES public."Post"(id);


--
-- Name: Post Post_repostOfId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Post"
    ADD CONSTRAINT "Post_repostOfId_fkey" FOREIGN KEY ("repostOfId") REFERENCES public."Post"(id);


--
-- Name: Post Post_threadRootId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Post"
    ADD CONSTRAINT "Post_threadRootId_fkey" FOREIGN KEY ("threadRootId") REFERENCES public."Post"(id);


--
-- Name: Post Post_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Post"
    ADD CONSTRAINT "Post_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PushDevice PushDevice_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."PushDevice"
    ADD CONSTRAINT "PushDevice_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PushNotificationDelivery PushNotificationDelivery_deviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."PushNotificationDelivery"
    ADD CONSTRAINT "PushNotificationDelivery_deviceId_fkey" FOREIGN KEY ("deviceId") REFERENCES public."PushDevice"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PushNotificationDelivery PushNotificationDelivery_notificationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."PushNotificationDelivery"
    ADD CONSTRAINT "PushNotificationDelivery_notificationId_fkey" FOREIGN KEY ("notificationId") REFERENCES public."Notification"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PushNotificationDelivery PushNotificationDelivery_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."PushNotificationDelivery"
    ADD CONSTRAINT "PushNotificationDelivery_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public."NotificationTemplate"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PushNotificationDelivery PushNotificationDelivery_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."PushNotificationDelivery"
    ADD CONSTRAINT "PushNotificationDelivery_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Reaction Reaction_messageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Reaction"
    ADD CONSTRAINT "Reaction_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES public."Message"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Reaction Reaction_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Reaction"
    ADD CONSTRAINT "Reaction_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Report Report_commentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_commentId_fkey" FOREIGN KEY ("commentId") REFERENCES public."Comment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Report Report_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_postId_fkey" FOREIGN KEY ("postId") REFERENCES public."Post"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Report Report_reporterId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_reporterId_fkey" FOREIGN KEY ("reporterId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Repost Repost_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Repost"
    ADD CONSTRAINT "Repost_postId_fkey" FOREIGN KEY ("postId") REFERENCES public."Post"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Repost Repost_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Repost"
    ADD CONSTRAINT "Repost_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Role Role_serverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES public."Server"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SavedPost SavedPost_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."SavedPost"
    ADD CONSTRAINT "SavedPost_postId_fkey" FOREIGN KEY ("postId") REFERENCES public."Post"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SavedPost SavedPost_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."SavedPost"
    ADD CONSTRAINT "SavedPost_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SecurityLog SecurityLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."SecurityLog"
    ADD CONSTRAINT "SecurityLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ServerAnalytics ServerAnalytics_serverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."ServerAnalytics"
    ADD CONSTRAINT "ServerAnalytics_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES public."Server"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServerEmoji ServerEmoji_serverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."ServerEmoji"
    ADD CONSTRAINT "ServerEmoji_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES public."Server"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServerMember ServerMember_serverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."ServerMember"
    ADD CONSTRAINT "ServerMember_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES public."Server"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServerMember ServerMember_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."ServerMember"
    ADD CONSTRAINT "ServerMember_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ServerSticker ServerSticker_serverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."ServerSticker"
    ADD CONSTRAINT "ServerSticker_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES public."Server"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Server Server_ownerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Server"
    ADD CONSTRAINT "Server_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: StakingReward StakingReward_poolId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."StakingReward"
    ADD CONSTRAINT "StakingReward_poolId_fkey" FOREIGN KEY ("poolId") REFERENCES public."StakingPool"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: StakingReward StakingReward_stakeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."StakingReward"
    ADD CONSTRAINT "StakingReward_stakeId_fkey" FOREIGN KEY ("stakeId") REFERENCES public."UserStake"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: StakingReward StakingReward_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."StakingReward"
    ADD CONSTRAINT "StakingReward_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Thread Thread_channelId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Thread"
    ADD CONSTRAINT "Thread_channelId_fkey" FOREIGN KEY ("channelId") REFERENCES public."Channel"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Thread Thread_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Thread"
    ADD CONSTRAINT "Thread_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TokenGatingRule TokenGatingRule_channelId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."TokenGatingRule"
    ADD CONSTRAINT "TokenGatingRule_channelId_fkey" FOREIGN KEY ("channelId") REFERENCES public."Channel"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TokenGatingRule TokenGatingRule_communityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."TokenGatingRule"
    ADD CONSTRAINT "TokenGatingRule_communityId_fkey" FOREIGN KEY ("communityId") REFERENCES public."Community"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TokenGatingRule TokenGatingRule_serverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."TokenGatingRule"
    ADD CONSTRAINT "TokenGatingRule_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES public."Server"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TokenRequirement TokenRequirement_ruleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."TokenRequirement"
    ADD CONSTRAINT "TokenRequirement_ruleId_fkey" FOREIGN KEY ("ruleId") REFERENCES public."TokenGatingRule"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Token Token_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Token"
    ADD CONSTRAINT "Token_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TranscodingJob TranscodingJob_fileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."TranscodingJob"
    ADD CONSTRAINT "TranscodingJob_fileId_fkey" FOREIGN KEY ("fileId") REFERENCES public."UploadedFile"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TranscodingJob TranscodingJob_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."TranscodingJob"
    ADD CONSTRAINT "TranscodingJob_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UploadChunk UploadChunk_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UploadChunk"
    ADD CONSTRAINT "UploadChunk_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public."ChunkedUploadSession"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UploadedFile UploadedFile_channelId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UploadedFile"
    ADD CONSTRAINT "UploadedFile_channelId_fkey" FOREIGN KEY ("channelId") REFERENCES public."Channel"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: UploadedFile UploadedFile_messageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UploadedFile"
    ADD CONSTRAINT "UploadedFile_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES public."Message"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: UploadedFile UploadedFile_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UploadedFile"
    ADD CONSTRAINT "UploadedFile_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserActivity UserActivity_presenceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UserActivity"
    ADD CONSTRAINT "UserActivity_presenceId_fkey" FOREIGN KEY ("presenceId") REFERENCES public."UserPresence"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserActivity UserActivity_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UserActivity"
    ADD CONSTRAINT "UserActivity_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserBadge UserBadge_badgeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UserBadge"
    ADD CONSTRAINT "UserBadge_badgeId_fkey" FOREIGN KEY ("badgeId") REFERENCES public."CommunityBadge"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserBadge UserBadge_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UserBadge"
    ADD CONSTRAINT "UserBadge_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserNFT UserNFT_nftId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UserNFT"
    ADD CONSTRAINT "UserNFT_nftId_fkey" FOREIGN KEY ("nftId") REFERENCES public."NFT"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserNFT UserNFT_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UserNFT"
    ADD CONSTRAINT "UserNFT_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserPresence UserPresence_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UserPresence"
    ADD CONSTRAINT "UserPresence_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserProfilePicture UserProfilePicture_nftId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UserProfilePicture"
    ADD CONSTRAINT "UserProfilePicture_nftId_fkey" FOREIGN KEY ("nftId") REFERENCES public."NFT"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserProfilePicture UserProfilePicture_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UserProfilePicture"
    ADD CONSTRAINT "UserProfilePicture_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserStake UserStake_poolId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UserStake"
    ADD CONSTRAINT "UserStake_poolId_fkey" FOREIGN KEY ("poolId") REFERENCES public."StakingPool"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserStake UserStake_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."UserStake"
    ADD CONSTRAINT "UserStake_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: VoiceState VoiceState_channelId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."VoiceState"
    ADD CONSTRAINT "VoiceState_channelId_fkey" FOREIGN KEY ("channelId") REFERENCES public."Channel"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: VoiceState VoiceState_serverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."VoiceState"
    ADD CONSTRAINT "VoiceState_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES public."Server"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: VoiceState VoiceState_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."VoiceState"
    ADD CONSTRAINT "VoiceState_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Vote Vote_commentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Vote"
    ADD CONSTRAINT "Vote_commentId_fkey" FOREIGN KEY ("commentId") REFERENCES public."Comment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Vote Vote_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Vote"
    ADD CONSTRAINT "Vote_postId_fkey" FOREIGN KEY ("postId") REFERENCES public."Post"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Vote Vote_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cryb_user
--

ALTER TABLE ONLY public."Vote"
    ADD CONSTRAINT "Vote_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: cryb_user
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cryb_user
--

ALTER DEFAULT PRIVILEGES FOR ROLE cryb_user IN SCHEMA public GRANT ALL ON SEQUENCES  TO cryb_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cryb_user
--

ALTER DEFAULT PRIVILEGES FOR ROLE cryb_user IN SCHEMA public GRANT ALL ON TABLES  TO cryb_user;


--
-- PostgreSQL database dump complete
--

